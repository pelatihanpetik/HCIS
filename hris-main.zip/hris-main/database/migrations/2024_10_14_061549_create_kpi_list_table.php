<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('kpi_list', function (Blueprint $table) {
            $table->id();
            $table->foreignId('kpi_id')->constrained('kpi')->cascadeOnDelete();
            $table->foreignId('kpi_group_id')->constrained('kpi_group')->noActionOnDelete();
            $table->string('teks');
            $table->json('kriteria');
            $table->float('bobot');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('kpi_list');
    }
};
