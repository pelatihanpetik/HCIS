<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('kpi_pegawai', function (Blueprint $table) {
            $table->id();
            $table->foreignId('kpi_id')->constrained('kpi')->cascadeOnDelete();
            $table->foreignId('pegawai_id')->constrained('pegawai')->cascadeOnDelete();
            $table->text('perbaikan')->nullable();
            $table->integer('perbaikan_id')->nullable();
            $table->text('rekomendasi_akhir')->nullable();
            $table->integer('rekomendasi_akhir_id')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('kpi_pegawai');
    }
};
