<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('jabatan', function (Blueprint $table) {
            $table->id();
            $table->foreignId('divisi_id')->nullable()->constrained('divisi')->noActionOnDelete();
            $table->foreignId('jenis_jabatan_id')->constrained('jenis_jabatan')->noActionOnDelete();
            $table->string('nama', 125);
            $table->tinyInteger('level');
            $table->foreignId('parent_id')->nullable()->constrained('jabatan')->cascadeOnDelete();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('jabatan');
    }
};
