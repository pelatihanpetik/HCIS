<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class JabatanSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('divisi')->upsert([
            ['id' => 1, 'nama' => 'RIK'],
            ['id' => 2, 'nama' => 'SDM dan Umum'],
            ['id' => 3, 'nama' => 'Kemandirian'],
            ['id' => 4, 'nama' => 'SUH'],
        ], ['id'], ['nama']);

        DB::table('jenis_jabatan')->upsert([
            ['id' => 1, 'nama' => 'Direktur', 'level' => 1],
            ['id' => 2, 'nama' => 'Kepala Divisi', 'level' => 2],
            ['id' => 3, 'nama' => 'Staf', 'level' => 3],
        ], ['id'], ['nama', 'level']);

        DB::table('jabatan')->upsert([
            [
                'id' => 1,
                'divisi_id' => null,
                'jenis_jabatan_id' => 1,
                'nama' => 'Direktur Utama',
                'level' => 1,
                'parent_id' => null,
            ],
            [
                'id' => 2,
                'divisi_id' => 1,
                'jenis_jabatan_id' => 2,
                'nama' => 'Kepala Divisi RIK',
                'level' => 2,
                'parent_id' => 1,
            ],
            [
                'id' => 3,
                'divisi_id' => 2,
                'jenis_jabatan_id' => 2,
                'nama' => 'Kepala Divisi SDM dan Umum',
                'level' => 2,
                'parent_id' => 1,
            ],
            [
                'id' => 4,
                'divisi_id' => 3,
                'jenis_jabatan_id' => 2,
                'nama' => 'Kepala Divisi Kemandirian',
                'level' => 2,
                'parent_id' => 1,
            ],
            [
                'id' => 5,
                'divisi_id' => 4,
                'jenis_jabatan_id' => 2,
                'nama' => 'Kepala Divisi SUH',
                'level' => 2,
                'parent_id' => 1,
            ],
            [
                'id' => 6,
                'divisi_id' => 1,
                'jenis_jabatan_id' => 3,
                'nama' => 'Pengajar',
                'level' => 3,
                'parent_id' => 2,
            ],
            [
                'id' => 7,
                'divisi_id' => 2,
                'jenis_jabatan_id' => 3,
                'nama' => 'Umum',
                'level' => 3,
                'parent_id' => 3,
            ],
            [
                'id' => 8,
                'divisi_id' => 2,
                'jenis_jabatan_id' => 3,
                'nama' => 'Keuangan',
                'level' => 3,
                'parent_id' => 3,
            ],
            [
                'id' => 9,
                'divisi_id' => 2,
                'jenis_jabatan_id' => 3,
                'nama' => 'Publikasi',
                'level' => 3,
                'parent_id' => 3,
            ],
            [
                'id' => 10,
                'divisi_id' => 3,
                'jenis_jabatan_id' => 3,
                'nama' => 'IT Support',
                'level' => 3,
                'parent_id' => 4,
            ],
            [
                'id' => 11,
                'divisi_id' => 3,
                'jenis_jabatan_id' => 3,
                'nama' => 'IT Programmer',
                'level' => 3,
                'parent_id' => 4,
            ],
            [
                'id' => 12,
                'divisi_id' => 4,
                'jenis_jabatan_id' => 3,
                'nama' => 'Musyrif',
                'level' => 3,
                'parent_id' => 5,
            ],
        ], ['id'], ['divisi_id', 'jenis_jabatan_id', 'nama', 'level', 'parent_id']);
    }
}
