<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class RekomendasiSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('rekomendasi')->upsert([
            [
                'id' => 1,
                'jenis' => 'perbaikan',
                'keterangan' => 'Training'
            ],
            [
                'id' => 2,
                'jenis' => 'perbaikan',
                'keterangan' => 'Penugasan'
            ],
            [
                'id' => 3,
                'jenis' => 'perbaikan',
                'keterangan' => 'Magang'
            ],
            [
                'id' => 4,
                'jenis' => 'perbaikan',
                'keterangan' => 'Lainnya'
            ],
            [
                'id' => 5,
                'jenis' => 'akhir',
                'keterangan' => 'Putus / selesai kontrak'
            ],
            [
                'id' => 6,
                'jenis' => 'akhir',
                'keterangan' => 'Perpanjang Kontrak'
            ],
            [
                'id' => 7,
                'jenis' => 'akhir',
                'keterangan' => 'Diangkat menjadi karyawan tetap'
            ],
            [
                'id' => 8,
                'jenis' => 'akhir',
                'keterangan' => 'Tetap di Divisi saat ini'
            ],
            [
                'id' => 9,
                'jenis' => 'akhir',
                'keterangan' => 'Mutasi ke Divisi lain'
            ],
            [
                'id' => 10,
                'jenis' => 'akhir',
                'keterangan' => 'Promosi naik Jabatan'
            ],
            [
                'id' => 11,
                'jenis' => 'akhir',
                'keterangan' => 'Demosi'
            ]
        ], ['id'], ['jenis', 'keterangan']);
    }
}
