<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class KpiSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('kpi_group')->upsert([
            ['id' => 1, 'nama' => 'Penilaian Aspek Hasil Kerja', 'bobot' => 80],
            ['id' => 2, 'nama' => 'Penilaian Aspek Kompetensi', 'bobot' => 20],
        ], ['id'], ['nama', 'bobot']);
    }
}
