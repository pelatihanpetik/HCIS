<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class JenisBerkasSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('jenis_berkas')->upsert([
            ['id' => 1, 'nama' => 'KTP'],
            ['id' => 2, 'nama' => 'KK'],
            ['id' => 3, 'nama' => 'Ijazah'],
            ['id' => 4, 'nama' => 'Transkrip Nilai'],
            ['id' => 5, 'nama' => 'SKCK'],
            ['id' => 6, 'nama' => 'Surat Keterangan Pengalaman Kerja'],
        ], ['id'], ['nama']);
    }
}
