<?php

namespace App\Policies;

use App\Models\Pegawai;
use App\Models\User;

class PegawaiPolicy
{
    public function view(User $user, Pegawai $pegawai): bool
    {
        return match ($user->role) {
            'admin' => true,
            'karyawan' => $user->id === $pegawai->id,
            default => false,
        };
    }

    public function timesheet(User $user, Pegawai $pegawai): bool
    {
        if ($user->role === 'admin') {
            return true;
        }
        $posisi = $user->posisi->first();
        if ($posisi->level == 1) {
            return true;
        }
        if ($posisi->level == 2) {
            $role = $pegawai->posisi->first();
            if ($role->level == 3) {
                return $posisi->divisi_id === $role->divisi_id;
            }
            return true;
        }
        if ($posisi->level == 3) {
            return $user->id === $pegawai->id;
        }
        return false;
    }
}
