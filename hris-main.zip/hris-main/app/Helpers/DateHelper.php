<?php

namespace App\Helpers;

use DateInterval;
use DatePeriod;
use DateTime;

class DateHelper
{
    public static function countWeekDays(string $month): int
    {
        $start = new DateTime("$month-01");
        if ($month == date('Y-m')) {
            $end = new DateTime();
        } else {
            $end = new DateTime($start->format('Y-m-t'));
            $end->modify('+1 day');
        }


        $period = new DatePeriod($start, new DateInterval('P1D'), $end);

        $weekdays = 0;
        foreach ($period as $date) {
            if ($date->format('N') < 6) { // 1 (Mon) to 5 (Fri)
                $weekdays++;
            }
        }
        return $weekdays;
    }
}
