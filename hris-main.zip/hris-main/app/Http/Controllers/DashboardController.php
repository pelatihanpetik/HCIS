<?php

namespace App\Http\Controllers;

use App\Models\KpiPegawai;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class DashboardController extends Controller
{
    public function index(Request $request)
    {
        if (Auth::user()->role == 'karyawan') {
            $posisi = Auth::user()->posisi->first();
            if ($posisi->level == 2) {
                return to_route('dashboard.show', $posisi->divisi_id);
            }
            if ($posisi->level == 3) {
                return $this->list();
            }
        }
        $jabatan = DB::table('jabatan')
            ->selectRaw('jabatan.id, MIN(jabatan.nama) as nama, sum(kpi_list_detail.bobot) as bobot_tercapai, MIN(jabatan.level) as level, COUNT(DISTINCT kpi_pegawai.pegawai_id) as pegawai')
            ->join('kpi', 'jabatan.id', '=', 'kpi.jabatan_id')
            ->join('kpi_list', 'kpi.id', '=', 'kpi_list.kpi_id')
            ->join('kpi_pegawai', 'kpi_pegawai.kpi_id', '=', 'kpi.id')
            ->leftJoin('kpi_list_detail', function ($join) {
                $join->on('kpi_list.id', '=', 'kpi_list_detail.kpi_list_id')
                    ->on('kpi_list_detail.pegawai_id', '=', 'kpi_pegawai.pegawai_id');
            })
            ->where('kpi.is_active', 1)
            ->where('jabatan.level', 1)
            ->groupBy('jabatan.id')
            ->get();
        $divisi = DB::table('divisi')
            ->selectRaw('divisi.id, MIN(divisi.nama) as nama, sum(kpi_list_detail.bobot) as bobot_tercapai, MIN(jabatan.level) as level, COUNT(DISTINCT kpi_pegawai.pegawai_id) as pegawai')
            ->join('jabatan', 'divisi.id', '=', 'jabatan.divisi_id')
            ->join('kpi', 'jabatan.id', '=', 'kpi.jabatan_id')
            ->join('kpi_list', 'kpi.id', '=', 'kpi_list.kpi_id')
            ->join('kpi_pegawai', 'kpi_pegawai.kpi_id', '=', 'kpi.id')
            ->leftJoin('kpi_list_detail', function ($join) {
                $join->on('kpi_list.id', '=', 'kpi_list_detail.kpi_list_id')
                    ->on('kpi_list_detail.pegawai_id', '=', 'kpi_pegawai.pegawai_id');
            })
            ->where('kpi.is_active', 1)
            ->groupBy('divisi.id')
            ->get();
        $divisi = $jabatan->merge($divisi);
        if ($divisi->isEmpty()) {
            return view('dashboard.index');
        }
        $lembaga = [
            'bobot' => 100,
            'bobot_tercapai' => $divisi->sum('bobot_tercapai') / $divisi->sum('pegawai'),
        ];
        return view('dashboard.index', compact('divisi', 'lembaga'));
    }

    public function show($id)
    {
        $progress = KpiPegawai::with('pegawai:id,nama', 'kpi')
            ->withSum('lists', 'bobot')
            ->whereHas('kpi', function ($query) {
                $query->where('is_active', 1);
            })
            ->whereHas('kpi.jabatan', function ($query) use ($id) {
                $query->where('divisi_id', $id);
            })
            ->get();
        $posisi = Auth::user()->posisi->first();
        return view('dashboard.show', compact('progress', 'posisi'));
    }

    public function list()
    {
        $progress = KpiPegawai::with('pegawai:id,nama', 'kpi')
            ->withSum('lists', 'bobot')
            ->whereHas('kpi', function ($query) {
                $query->where('is_active', 1);
            })
            ->where('pegawai_id', Auth::id())
            ->get();
        $posisi = Auth::user()->posisi->first();
        return view('dashboard.show', compact('progress', 'posisi'));
    }
}
