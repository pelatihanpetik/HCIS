<?php

namespace App\Http\Controllers;

use App\Helpers\DateHelper;
use App\Models\Pegawai;
use App\Models\Timesheet;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Gate;
use RealRashid\SweetAlert\Facades\Alert;

class TimesheetController extends Controller
{
    public function index(Request $request)
    {
        $timesheets = Timesheet::filter([
            'user' => Auth::id(),
            'month' => $request->input('month', date('Y-m')),
        ])
            ->orderBy('date')
            ->get()
            ->groupBy('date');
        return view('timesheet.index', compact('timesheets'));
    }

    public function create()
    {
        return view('timesheet.create');
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'task' => 'required|string|max:255',
            'project' => 'required|string|max:255',
            'date' => 'required|date',
            'duration' => 'required|integer|min:1',
            'trouble' => 'nullable|string|max:255',
            'solution' => 'nullable|string|max:255',
        ]);

        $request->user()->timesheets()->create($validated);

        Alert::success('Success', 'Timesheet created successfully.');
        return to_route('timesheet.index');
    }

    public function edit(Timesheet $timesheet)
    {
        return view('timesheet.edit', compact('timesheet'));
    }

    public function update(Request $request, Timesheet $timesheet)
    {
        Gate::authorize('update', $timesheet);
        $validated = $request->validate([
            'task' => 'required|string|max:255',
            'project' => 'required|string|max:255',
            'date' => 'required|date',
            'duration' => 'required|integer|min:1',
            'trouble' => 'nullable|string|max:255',
            'solution' => 'nullable|string|max:255',
        ]);

        $timesheet->update($validated);

        Alert::success('Success', 'Timesheet updated successfully.');
        return to_route('timesheet.index');
    }

    public function destroy(Timesheet $timesheet)
    {
        Gate::authorize('delete', $timesheet);
        $timesheet->delete();
        Alert::success('Success', 'Timesheet deleted successfully.');
        return to_route('timesheet.index');
    }

    public function report(Request $request)
    {
        $month = $request->input('month', date('Y-m'));
        $report = Pegawai::select('id', 'nama')->withCount(['timesheets as timesheet_count' => function ($query) use ($month) {
            $query->select(DB::raw('COUNT(DISTINCT date)'))
                ->filter([
                    'month' => $month,
                ]);
        }])
            ->orderBy('nama')
            ->get();
        $weekdays = DateHelper::countWeekDays($month);
        return view('timesheet.report', compact('report', 'month', 'weekdays'));
    }

    public function reportDetail(string $id, Request $request)
    {
        $pegawai = Pegawai::select('id')->findOrFail($id);
        Gate::authorize('timesheet', $pegawai);
        $timesheets = Timesheet::filter([
            'user' => $id,
            'month' => $request->input('month', date('Y-m')),
        ])
            ->orderBy('date')
            ->get();
        $timesheets = $timesheets->groupBy('date');
        return view('timesheet.index', compact('timesheets'));
    }
}
