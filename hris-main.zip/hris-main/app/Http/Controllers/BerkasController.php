<?php

namespace App\Http\Controllers;

use App\Models\Berkas;
use App\Models\JenisBerkas;
use App\Models\Pegawai;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use RealRashid\SweetAlert\Facades\Alert;

class BerkasController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Pegawai $pegawai)
    {
        $tab = 'berkas';
        return view('berkas.index', compact('pegawai', 'tab'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create(Pegawai $pegawai)
    {
        $tab = 'berkas';
        $jenis = JenisBerkas::all();
        return view('berkas.create', compact('pegawai', 'tab', 'jenis'));
    }

    public function edit(Pegawai $pegawai, Berkas $berkas)
    {
        $tab = 'berkas';
        $jenis = JenisBerkas::all();
        return view('berkas.edit', compact('pegawai', 'tab', 'jenis', 'berkas'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request, Pegawai $pegawai)
    {
        $request->validate([
            'jenis' => 'required',
            'nama' => 'required',
            'file' => 'required|file|mimes:pdf,png,jpg,jpeg|max:2048'
        ]);

        $jenis = JenisBerkas::findOrFail($request->jenis);
        $file = $request->file('file')->store('berkas');

        try {
            $pegawai->berkas()->create([
                'jenis_berkas_id' => $jenis->id,
                'jenis' => $jenis->nama,
                'nama' => $request->nama,
                'file' => $file
            ]);
            Alert::success('Berhasil', 'Berkas berhasil ditambahkan');
            return to_route('berkas.index', $pegawai->id);
        } catch (\Throwable $th) {
            Storage::delete($file);
            Alert::error('Error', 'Server error, coba beberapa saat lagi');
            return back()->withInput();
        }
    }
    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Pegawai $pegawai, Berkas $berkas)
    {
        $request->validate([
            'jenis' => 'required',
            'nama' => 'required',
            'file' => 'nullable|file|mimes:pdf,png,jpg,jpeg|max:2048'
        ]);

        if ($request->hasFile('file')) {
            Storage::delete($berkas->file);
            $berkas->file = $request->file('file')->store('berkas');
        }
        if ($berkas->jenis_berkas_id != $request->jenis) {
            $jenis = JenisBerkas::findOrFail($request->jenis);
            $berkas->jenis_berkas_id = $jenis->id;
            $berkas->jenis = $jenis->nama;
        }
        try {
            $berkas->nama = $request->nama;
            $berkas->save();
            Alert::success('Berhasil', 'Berkas berhasil diubah');
            return to_route('berkas.index', $pegawai);
        } catch (\Throwable $th) {
            if (isset($file)) {
                Storage::delete($file);
            }
            Alert::error('Error', 'Server error, coba beberapa saat lagi');
            return back()->withInput();
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Pegawai $pegawai, Berkas $berkas)
    {
        try {
            Storage::delete($berkas->file);
            $berkas->delete();
            Alert::success('Berhasil', 'Berkas berhasil dihapus');
            return to_route('berkas.index', $pegawai);
        } catch (\Throwable $th) {
            Alert::error('Error', 'Server error, coba beberapa saat lagi');
            return back();
        }
    }
}
