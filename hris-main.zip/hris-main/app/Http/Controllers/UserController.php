<?php

namespace App\Http\Controllers;

use App\Models\Role;
use App\Models\User;
use Illuminate\Http\Request;
use RealRashid\SweetAlert\Facades\Alert;

class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $users = User::paginate(10);
        return view('user.index', compact('users'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('user.create', [
            'roles' => Role::all()
        ]);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'nama' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users',
            'password' => 'required|string|min:5',
            'roles' => 'required|array',
            'roles.*' => 'exists:roles,simbol'
        ]);
        $validated['password'] = bcrypt($validated['password']);
        $validated['email_verified_at'] = now();
        $validated['role'] = $validated['roles'][0];
        try {
            $user = User::create($validated);
            $user->roles()->attach($validated['roles']);
            Alert::success('Berhasil', 'User berhasil ditambahkan');
            return to_route('user.index');
        } catch (\Throwable $th) {
            Alert::error('Error', "Server error, coba beberapa saat lagi");
            return back()->withInput();
        }
    }
    /**
     * Show the form for editing the specified resource.
     */
    public function edit(User $user)
    {
        $roles = Role::all();
        return view('user.edit', compact('user', 'roles'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, User $user)
    {
        $validated = $request->validate([
            'nama' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users,email,' . $user->id,
            'roles' => 'required|array',
            'roles.*' => 'exists:roles,simbol'
        ]);

        $validated['role'] = $validated['roles'][0];
        try {
            $user->update($validated);
            $user->roles()->sync($validated['roles']);
            Alert::success('Berhasil', 'User berhasil diupdate');
            return to_route('user.index');
        } catch (\Throwable $th) {
            Alert::error('Error', "Server error, coba beberapa saat lagi");
            return back()->withInput();
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        try {
            User::destroy($id);
            Alert::success('Berhasil', 'User berhasil dihapus');
            return to_route('user.index');
        } catch (\Throwable $th) {
            Alert::error('Error', "Server error, coba beberapa saat lagi");
            return back();
        }
    }

    public function changeRole(string $role, Request $request)
    {
        $user = $request->user();
        if ($role === $user->role) {
            Alert::error('Error', 'Saat ini anda sudah memilih role ini');
            return back();
        }
        if (!$user->hasRole($role)) {
            Alert::error('Error', 'Anda tidak memiliki akses');
            return back();
        }

        try {
            $user->update(['role' => $role]);
            Alert::success('Berhasil', 'Role berhasil diubah');
            return back();
        } catch (\Throwable $th) {
            Alert::error('Error', "Server error, coba beberapa saat lagi");
            return back();
        }
    }
}
