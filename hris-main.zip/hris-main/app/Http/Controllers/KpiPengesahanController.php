<?php

namespace App\Http\Controllers;

use App\Models\Jabatan;
use App\Models\Kpi;
use App\Models\KpiPengesahan;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use RealRashid\SweetAlert\Facades\Alert;

class KpiPengesahanController extends Controller
{
    public function index(Kpi $kpi)
    {
        $tab = 'pengesahan';
        $kpi->load(['pengesahan' => function ($query) {
            $query->whereNull('pegawai_id');
        }]);
        return view('kpi-pengesahan.list', compact('kpi', 'tab'));
    }

    public function create(Kpi $kpi)
    {
        $tab = 'pengesahan';
        $jabatan = Jabatan::with('divisi', 'jenis')->get();
        return view('kpi-pengesahan.create', compact('kpi', 'tab', 'jabatan'));
    }

    public function store(Request $request, Kpi $kpi)
    {
        $request->validate([
            'jabatan' => 'required|exists:jabatan,id',
        ]);

        $check = KpiPengesahan::where('kpi_id', $kpi->id)
            ->where('jabatan_id', $request->jabatan)
            ->count();
        if ($check > 0) {
            Alert::error('Gagal', 'Data sudah ada');
            return back()->withInput();
        }

        $jabatan = DB::table('jabatan')
            ->select('jabatan.nama as jabatan', 'users.nama', 'users.id')
            ->join('posisi', 'posisi.jabatan_id', 'jabatan.id')
            ->join('users', 'users.id', 'posisi.user_id')
            ->where('jabatan.id', $request->jabatan)
            ->first();
        if (!$jabatan) {
            Alert::error('Gagal', 'Posisi jabatan belum ditentukan');
            return back()->withInput();
        }
        try {
            $kpi->pengesahan()->create([
                'jabatan_id' => $request->jabatan,
                'jabatan' => $jabatan->jabatan,
                'nama' => $jabatan->nama,
                'user_id' => $jabatan->id,
            ]);
            Alert::success('Berhasil', 'Data berhasil disimpan');
            return to_route('kpi.pengesahan.index', $kpi->id);
        } catch (\Throwable $th) {
            Alert::error('Gagal', 'Data gagal disimpan');
            return back()->withInput();
        }
    }

    public function edit(Kpi $kpi, KpiPengesahan $pengesahan)
    {
        $tab = 'pengesahan';
        $jabatan = Jabatan::with('divisi', 'jenis')->get();
        return view('kpi-pengesahan.edit', compact('kpi', 'tab', 'pengesahan', 'jabatan'));
    }

    public function update(Kpi $kpi, KpiPengesahan $pengesahan, Request $request)
    {
        $request->validate([
            'jabatan' => 'required|exists:jabatan,id',
            'nama' => 'required',
        ]);

        $check = KpiPengesahan::where('kpi_id', $kpi->id)
            ->where('id', '!=', $pengesahan->id)
            ->where('jabatan_id', $request->jabatan)
            ->count();
        if ($check > 0) {
            Alert::error('Gagal', 'Data sudah ada');
            return back()->withInput();
        }

        $jabatan = DB::table('jabatan')
            ->select('jabatan.nama as jabatan', 'users.nama', 'users.id')
            ->join('posisi', 'posisi.jabatan_id', 'jabatan.id')
            ->join('users', 'users.id', 'posisi.user_id')
            ->where('jabatan.id', $request->jabatan)
            ->first();
        if (!$jabatan) {
            Alert::error('Gagal', 'Posisi jabatan belum ditentukan');
            return back()->withInput();
        }
        try {
            $pengesahan->update([
                'jabatan_id' => $request->jabatan,
                'jabatan' => $jabatan->jabatan,
                'nama' => $pengesahan->user_id == $jabatan->id ? $request->nama : $jabatan->nama,
                'user_id' => $jabatan->id,
            ]);
            Alert::success('Berhasil', 'Data berhasil disimpan');
            return to_route('kpi.pengesahan.index', $kpi->id);
        } catch (\Throwable $th) {
            Alert::error('Gagal', 'Data gagal disimpan');
            return back()->withInput();
        }
    }

    public function destroy(string $kpi, KpiPengesahan $pengesahan)
    {
        try {
            $pengesahan->delete();
            Alert::success('Berhasil', 'Data berhasil dihapus');
            return to_route('kpi.pengesahan.index', $kpi);
        } catch (\Throwable $th) {
            Alert::error('Gagal', 'Data gagal dihapus');
            return back();
        }
    }
}
