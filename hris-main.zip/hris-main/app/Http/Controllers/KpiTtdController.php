<?php

namespace App\Http\Controllers;

use App\Models\KpiPegawai;
use App\Models\KpiPengesahan;
use Illuminate\Http\Request;
use RealRashid\SweetAlert\Facades\Alert;

class KpiTtdController extends Controller
{
    public function index(string $id, string $pegawai)
    {
        $kpiPegawai = KpiPegawai::where('pegawai_id', $pegawai)
            ->where('kpi_id', $id)
            ->firstOrFail();
        $kpi = $kpiPegawai->kpi;
        $tab = 'preview';
        $pengesahanCount = KpiPengesahan::where('kpi_id', $id)
            ->where('pegawai_id', $pegawai)
            ->count();
        if ($pengesahanCount == 0) {
            $list = KpiPengesahan::where('kpi_id', $id)
                ->whereNull('pegawai_id')
                ->get();
            $data = $list->map(function ($item) use ($pegawai) {
                return [
                    "kpi_id" => $item->kpi_id,
                    "jabatan_id" => $item->jabatan_id,
                    "pegawai_id" => $pegawai,
                    "jabatan" => $item->jabatan,
                    "nama" => $item->nama,
                    "user_id" => $item->user_id,
                ];
            });
            KpiPengesahan::insert($data->toArray());
        }
        $pengesahan = KpiPengesahan::where('kpi_id', $id)
            ->where('pegawai_id', $pegawai)
            ->get();
        return view('kpi.ttd', compact('kpi', 'tab', 'kpiPegawai', 'pengesahan'));
    }

    public function update(Request $request, string $id, KpiPengesahan $ttd)
    {
        $validated = $request->validate([
            "nama" => "required",
            "jabatan" => "required",
            "tanggal" => "required|date",
            "ttd" => "required|image|max:2048",
        ]);

        try {
            $ttd->update([
                "nama" => $validated["nama"],
                "jabatan" => $validated["jabatan"],
                "tanggal" => $validated["tanggal"],
                "ttd" => $request->file("ttd")->store("ttd"),
            ]);
            Alert::success('Berhasil', 'Data berhasil disimpan');
            return to_route('kpi.ttd.index', [$id, $ttd->pegawai_id]);
        } catch (\Throwable $th) {
            Alert::error('Gagal', 'Data gagal disimpan');
            return back()->withInput();
        }
    }
}
