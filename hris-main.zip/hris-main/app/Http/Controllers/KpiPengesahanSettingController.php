<?php

namespace App\Http\Controllers;

use App\Models\Jabatan;
use App\Models\KpiPengesahanSetting;
use App\Models\Posisi;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use RealRashid\SweetAlert\Facades\Alert;

class KpiPengesahanSettingController extends Controller
{
    public function index()
    {
        $pengesahan = KpiPengesahanSetting::all();
        $jenis = Jabatan::get();
        return view('kpi-pengesahan.index', compact('pengesahan', 'jenis'));
    }

    public function edit(KpiPengesahanSetting $pengesahan)
    {
        $jabatan = Jabatan::get();
        $jenis = Jabatan::get();
        return view('kpi-pengesahan.setting', compact('jabatan', 'pengesahan', 'jenis'));
    }

    public function store(Request $request)
    {
        $request->validate([
            "jenis" => "required|exists:jabatan,id"
        ]);

        $posisi = Posisi::with('jabatan', 'pegawai:id,nama')
            ->where('jabatan_id', $request->jenis)
            ->first();

        KpiPengesahanSetting::create([
            'jabatan_id' => $request->jenis,
            'jabatan' => $posisi->jabatan->nama,
            'user_id' => $posisi->pegawai->id ?? null,
            'nama' => $posisi->pegawai->nama ?? null
        ]);
        Alert::success('Berhasil', 'Data berhasil disimpan');
        return to_route('pengesahan.index');
    }

    public function update(Request $request, KpiPengesahanSetting $pengesahan)
    {
        $request->validate([
            "jenis" => "required|exists:jabatan,id",
            'jabatan' => 'required|string',
            'nama' => 'required|string'
        ]);

        if ($pengesahan->jabatan_id != $request->jenis) {
            $posisi = Posisi::with('jabatan', 'pegawai:id,nama')
                ->where('jabatan_id', $request->jenis)
                ->first();
            $pengesahan->update([
                'jabatan_id' => $request->jenis,
                'jabatan' => $posisi->jabatan->nama,
                'user_id' => $posisi->pegawai->id ?? null,
                'nama' => $posisi->pegawai->nama ?? null
            ]);
        } else {
            $pengesahan->update([
                'jabatan' => $request->jabatan,
                'nama' => $request->nama
            ]);
        }

        Alert::success('Berhasil', 'Data berhasil disimpan');
        return to_route('pengesahan.index');
    }

    public function destroy(KpiPengesahanSetting $pengesahan)
    {
        $pengesahan->delete();
        Alert::success('Berhasil', 'Data berhasil dihapus');
        return to_route('pengesahan.index');
    }
}
