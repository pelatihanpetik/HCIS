<?php

namespace App\Http\Controllers;

use App\Models\JenisJabatan;
use Illuminate\Http\Request;
use RealRashid\SweetAlert\Facades\Alert;

class JenisJabatanController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        return view('jenis-jabatan.index', [
            'jenis' => JenisJabatan::all()
        ]);
    }
    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'nama' => 'required|string|max:255|unique:jenis_jabatan,nama',
            'level' => 'required|integer|min:1'
        ]);

        try {
            JenisJabatan::create($validated);
            Alert::success('Berhasil', 'Jenis jabatan berhasil ditambahkan');
            return to_route('jenis-jabatan.index');
        } catch (\Throwable $th) {
            Alert::error('Error', 'Server error, coba beberapa saat lagi');
            return back()->withInput();
        }
    }
    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, JenisJabatan $jenis)
    {
        $validated = $request->validate([
            'nama' => 'required|string|max:255|unique:jenis_jabatan,nama,' . $jenis->id,
            'level' => 'required|integer|min:1'
        ]);

        try {
            $jenis->update($validated);
            Alert::success('Berhasil', 'Jenis jabatan berhasil diubah');
            return to_route('jenis-jabatan.index');
        } catch (\Throwable $th) {
            Alert::error('Error', 'Server error, coba beberapa saat lagi');
            return back()->withInput();
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(JenisJabatan $jenis)
    {
        try {
            $jenis->delete();
            Alert::success('Berhasil', 'Jenis jabatan berhasil dihapus');
            return to_route('jenis-jabatan.index');
        } catch (\Throwable $th) {
            Alert::error('Error', 'Server error, coba beberapa saat lagi');
            return back();
        }
    }
}
