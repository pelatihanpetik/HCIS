<?php

namespace App\Http\Controllers;

use App\Models\Pegawai;
use App\Models\Pendidikan;
use App\Models\TingkatPendidikan;
use Illuminate\Http\Request;
use RealRashid\SweetAlert\Facades\Alert;

class PendidikanController extends Controller
{
    public function index(Pegawai $pegawai)
    {
        $tab = 'pendidikan';
        return view('pendidikan.index', compact('pegawai', 'tab'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create(Pegawai $pegawai)
    {
        $tab = 'pendidikan';
        $tingkat = TingkatPendidikan::get();
        return view('pendidikan.create', compact('pegawai', 'tab', 'tingkat'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request, Pegawai $pegawai)
    {
        $validated = $request->validate([
            "tingkat" => "required|in:" . implode(',', TingkatPendidikan::get()),
            "sekolah" => "required|string",
            "jurusan" => "nullable|string",
            "tanggal_mulai" => "required|date",
            "tanggal_selesai" => "nullable|date",
        ]);

        try {
            $pegawai->pendidikan()->create($validated);
            Alert::success('Berhasil', 'Pendidikan berhasil ditambahkan');
            return to_route('pendidikan.index', $pegawai->id);
        } catch (\Throwable $th) {
            Alert::error('Error', 'Server error, coba beberapa saat lagi');
            return back()->withInput();
        }
    }

    public function edit(Pegawai $pegawai, Pendidikan $pendidikan)
    {
        $tab = 'pendidikan';
        $tingkat = TingkatPendidikan::get();
        return view('pendidikan.edit', compact('pegawai', 'tab', 'pendidikan', 'tingkat'));
    }
    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Pegawai $pegawai, Pendidikan $pendidikan)
    {
        $validated = $request->validate([
            "tingkat" => "required|in:" . implode(',', TingkatPendidikan::get()),
            "sekolah" => "required|string",
            "jurusan" => "nullable|string",
            "tanggal_mulai" => "required|date",
            "tanggal_selesai" => "nullable|date",
        ]);

        try {
            $pendidikan->update($validated);
            Alert::success('Berhasil', 'Pendidikan berhasil diubah');
            return to_route('pendidikan.index', $pegawai);
        } catch (\Throwable $th) {
            Alert::error('Error', 'Server error, coba beberapa saat lagi');
            return back()->withInput();
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Pegawai $pegawai, Pendidikan $pendidikan)
    {
        try {
            $pendidikan->delete();
            Alert::success('Berhasil', 'Pendidikan berhasil dihapus');
            return to_route('pendidikan.index', $pegawai);
        } catch (\Throwable $th) {
            Alert::error('Error', 'Server error, coba beberapa saat lagi');
            return back();
        }
    }
}
