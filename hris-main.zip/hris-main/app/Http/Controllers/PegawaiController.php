<?php

namespace App\Http\Controllers;

use App\Models\Agama;
use App\Models\Jabatan;
use App\Models\Pegawai;
use App\Models\StatusKawin;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use RealRashid\SweetAlert\Facades\Alert;

class PegawaiController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $pegawai = Pegawai::paginate(10);
        return view('pegawai.index', compact('pegawai'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('pegawai.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'nama' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users',
            'password' => 'required|string|min:5',
            'jk' => 'required|string|in:L,P',
        ]);
        $validated['password'] = bcrypt($validated['password']);
        $validated['email_verified_at'] = now();
        try {
            DB::beginTransaction();
            $user = User::create($validated);
            $user->pegawai()->create([
                'jenis_kelamin' => $validated['jk'],
                'nama' => $validated['nama'],
            ]);
            $user->roles()->attach("karyawan");
            DB::commit();
            Alert::success('Berhasil', 'Pegawai berhasil ditambahkan');
            return to_route('pegawai.edit', $user->id);
        } catch (\Throwable $th) {
            DB::rollBack();
            Alert::error('Error', "Server error, coba beberapa saat lagi");
            return back()->withInput();
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(Pegawai $pegawai)
    {
        $tab = 'biodata';
        $pegawai->load('posisi');
        $jabatan = Jabatan::with('jenis', 'divisi')->get();
        return view('pegawai.show', compact('pegawai', 'tab', 'jabatan'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Pegawai $pegawai)
    {
        $agama = Agama::get();
        $kawin = StatusKawin::get();
        return view('pegawai.edit', compact('pegawai', 'agama', 'kawin'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Pegawai $pegawai)
    {
        $validated = $request->validate([
            "nama" => "required|string|max:100",
            "jenis_kelamin" => "required|string|in:L,P",
            "tempat_lahir" => 'nullable|string|max:100',
            "tanggal_lahir" => 'nullable|date|before:today',
            "no_hp" => 'nullable|numeric|digits_between:10,15',
            "email" => "required|string|email|max:255|unique:users,email," . $pegawai->user->id,
            "nik" => 'nullable|numeric|digits:16|unique:pegawai,nik,' . $pegawai->id,
            "nomor_kk" => 'nullable|numeric|digits:16',
            "npwp" => 'nullable|numeric|max_digits:20|unique:pegawai,npwp,' . $pegawai->id,
            "nomor_anggota_bpjs" => 'nullable|numeric|max_digits:20|unique:pegawai,nomor_anggota_bpjs,' . $pegawai->id,
            "agama" => 'nullable|string',
            "status_kawin" => 'nullable|string',
        ]);

        try {
            DB::beginTransaction();
            $pegawai->update(collect($validated)->except('email')->toArray());
            $pegawai->user->update([
                'nama' => $validated['nama'],
                'email' => $validated['email'],
            ]);
            DB::commit();
            Alert::success('Berhasil', 'Pegawai berhasil diupdate');
            return to_route('pegawai.edit', $pegawai->id);
        } catch (\Throwable $th) {
            DB::rollBack();
            Alert::error('Error', "Server error, coba beberapa saat lagi");
            return back()->withInput();
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        try {
            Pegawai::destroy($id);
            Alert::success('Berhasil', 'Pegawai berhasil dihapus');
            return to_route('user.index');
        } catch (\Throwable $th) {
            Alert::error('Error', "Server error, coba beberapa saat lagi");
            return back();
        }
    }
}
