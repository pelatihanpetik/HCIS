<?php

namespace App\Http\Controllers;

use App\Models\Pegawai;
use App\Models\Pelatihan;
use Illuminate\Http\Request;
use RealRashid\SweetAlert\Facades\Alert;

class PelatihanController extends Controller
{
    public function index(Pegawai $pegawai)
    {
        $tab = 'pelatihan';
        return view('pelatihan.index', compact('pegawai', 'tab'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create(Pegawai $pegawai)
    {
        $tab = 'pelatihan';
        return view('pelatihan.create', compact('pegawai', 'tab'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request, Pegawai $pegawai)
    {
        $validated = $request->validate([
            "nama" => "required|string",
            "penyelenggara" => "required|string",
            "sertifikat" => "nullable|string",
            "tanggal_mulai" => "required|date",
            "tanggal_selesai" => "nullable|date",
        ]);

        try {
            $pegawai->pelatihan()->create($validated);
            Alert::success('Berhasil', 'Pelatihan berhasil ditambahkan');
            return to_route('pelatihan.index', $pegawai->id);
        } catch (\Throwable $th) {
            Alert::error('Error', 'Server error, coba beberapa saat lagi');
            return back()->withInput();
        }
    }

    public function edit(Pegawai $pegawai, Pelatihan $pelatihan)
    {
        $tab = 'pelatihan';
        return view('pelatihan.edit', compact('pegawai', 'tab', 'pelatihan'));
    }
    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Pegawai $pegawai, Pelatihan $pelatihan)
    {
        $validated = $request->validate([
            "nama" => "required|string",
            "penyelenggara" => "required|string",
            "sertifikat" => "nullable|string",
            "tanggal_mulai" => "required|date",
            "tanggal_selesai" => "nullable|date",
        ]);

        try {
            $pelatihan->update($validated);
            Alert::success('Berhasil', 'Pelatihan berhasil diubah');
            return to_route('pelatihan.index', $pegawai);
        } catch (\Throwable $th) {
            Alert::error('Error', 'Server error, coba beberapa saat lagi');
            return back()->withInput();
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Pegawai $pegawai, Pelatihan $pelatihan)
    {
        try {
            $pelatihan->delete();
            Alert::success('Berhasil', 'Pelatihan berhasil dihapus');
            return to_route('pelatihan.index', $pegawai);
        } catch (\Throwable $th) {
            Alert::error('Error', 'Server error, coba beberapa saat lagi');
            return back();
        }
    }
}
