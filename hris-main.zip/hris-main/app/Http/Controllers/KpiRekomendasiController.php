<?php

namespace App\Http\Controllers;

use App\Models\Kpi;
use App\Models\KpiPegawai;
use App\Models\Rekomendasi;
use Illuminate\Http\Request;
use RealRashid\SweetAlert\Facades\Alert;

class KpiRekomendasiController extends Controller
{
    public function index(string $id, string $pegawai)
    {
        $kpiPegawai = KpiPegawai::where('pegawai_id', $pegawai)
            ->where('kpi_id', $id)
            ->firstOrFail();
        $kpi = $kpiPegawai->kpi;
        $tab = 'preview';
        $rekomendasi = Rekomendasi::orderBy('id')->get();
        return view('kpi.rekomendasi', compact('kpi', 'tab', 'kpiPegawai', 'rekomendasi'));
    }

    public function update(Request $request, string $id, string $pegawai)
    {
        $validated = $request->validate([
            "perbaikan_id" => "required|exists:rekomendasi,id",
            "perbaikan" => "required",
            "rekomendasi_akhir_id" => "required|exists:rekomendasi,id",
            "rekomendasi_akhir" => "required",
        ]);
        $kpi = KpiPegawai::where('pegawai_id', $pegawai)
            ->where('kpi_id', $id)
            ->firstOrFail();
        try {
            $kpi->update($validated);
            Alert::success('Berhasil', 'Data berhasil disimpan');
            return to_route('kpi.show', $id);
        } catch (\Throwable $th) {
            Alert::error('Gagal', 'Data gagal disimpan');
            return back();
        }
    }
}
