<?php

namespace App\Http\Controllers;

use App\Models\Divisi;
use Illuminate\Http\Request;
use RealRashid\SweetAlert\Facades\Alert;

class DivisiController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        return view('divisi.index', [
            'divisi' => Divisi::all()
        ]);
    }
    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'nama' => 'required|string|max:255|unique:divisi,nama'
        ]);

        try {
            Divisi::create([
                'nama' => $request->nama
            ]);
            Alert::success('Berhasil', 'Divisi berhasil ditambahkan');
            return to_route('divisi.index');
        } catch (\Throwable $th) {
            Alert::error('Error', 'Server error, coba beberapa saat lagi');
            return back()->withInput();
        }
    }
    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Divisi $divisi)
    {
        $request->validate([
            'nama' => 'required|string|max:255|unique:divisi,nama,' . $divisi->id
        ]);

        try {
            $divisi->update([
                'nama' => $request->nama
            ]);
            Alert::success('Berhasil', 'Divisi berhasil diubah');
            return to_route('divisi.index');
        } catch (\Throwable $th) {
            Alert::error('Error', 'Server error, coba beberapa saat lagi');
            return back()->withInput();
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Divisi $divisi)
    {
        try {
            $divisi->delete();
            Alert::success('Berhasil', 'Divisi berhasil dihapus');
            return to_route('divisi.index');
        } catch (\Throwable $th) {
            Alert::error('Error', 'Server error, coba beberapa saat lagi');
            return back();
        }
    }
}
