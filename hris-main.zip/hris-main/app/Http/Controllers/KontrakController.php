<?php

namespace App\Http\Controllers;

use App\Models\Pegawai;
use App\Models\SuratKontrak;
use Illuminate\Http\Request;
use RealRashid\SweetAlert\Facades\Alert;

class KontrakController extends Controller
{
    public function index(Pegawai $pegawai)
    {
        $tab = 'kontrak';
        return view('kontrak.index', compact('pegawai', 'tab'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create(Pegawai $pegawai)
    {
        $tab = 'kontrak';
        return view('kontrak.create', compact('pegawai', 'tab'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request, Pegawai $pegawai)
    {
        $validated = $request->validate([
            "nomor" => "required|string|unique:surat_kontrak,nomor",
            "tanggal_dari" => "required|date",
            "tanggal_sampai" => "nullable|date",
            "hal" => "required|string",
            "penghasilan" => "required|numeric|min:1000",
        ]);

        try {
            $pegawai->kontrak()->create($validated);
            Alert::success('Berhasil', 'Surat kontrak berhasil ditambahkan');
            return to_route('kontrak.index', $pegawai->id);
        } catch (\Throwable $th) {
            Alert::error('Error', 'Server error, coba beberapa saat lagi');
            return back()->withInput();
        }
    }

    public function edit(Pegawai $pegawai, SuratKontrak $kontrak)
    {
        $tab = 'kontrak';
        return view('kontrak.edit', compact('pegawai', 'tab', 'kontrak'));
    }
    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Pegawai $pegawai, SuratKontrak $kontrak)
    {
        $validated = $request->validate([
            "nomor" => "required|string|unique:surat_kontrak,nomor," . $kontrak->id,
            "tanggal_dari" => "required|date",
            "tanggal_sampai" => "nullable|date",
            "hal" => "required|string",
            "penghasilan" => "required|numeric|min:1000",
        ]);

        try {
            $kontrak->update($validated);
            Alert::success('Berhasil', 'Surat kontrak berhasil diubah');
            return to_route('kontrak.index', $pegawai);
        } catch (\Throwable $th) {
            Alert::error('Error', 'Server error, coba beberapa saat lagi');
            return back()->withInput();
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Pegawai $pegawai, SuratKontrak $kontrak)
    {
        try {
            $kontrak->delete();
            Alert::success('Berhasil', 'Surat kontrak berhasil dihapus');
            return to_route('kontrak.index', $pegawai);
        } catch (\Throwable $th) {
            Alert::error('Error', 'Server error, coba beberapa saat lagi');
            return back();
        }
    }
}
