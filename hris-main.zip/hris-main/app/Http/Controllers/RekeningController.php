<?php

namespace App\Http\Controllers;

use App\Models\NomorRekening;
use App\Models\Pegawai;
use Illuminate\Http\Request;
use RealRashid\SweetAlert\Facades\Alert;

class RekeningController extends Controller
{
    public function store(Request $request, Pegawai $pegawai)
    {
        $validated = $request->validate([
            'nomor' => 'required|string',
            'bank' => 'required|string',
            'nama' => 'required|string',
        ]);

        try {
            $pegawai->rekening()->create($validated);
            Alert::success('Berhasil', 'Nomor rekening berhasil ditambahkan');
            return to_route('kontrak.index', $pegawai->id);
        } catch (\Throwable $th) {
            Alert::error('Error', 'Server error, coba beberapa saat lagi');
            return back()->withInput();
        }
    }

    public function update(Request $request, Pegawai $pegawai, NomorRekening $rekening)
    {
        $validated = $request->validate([
            'nomor' => 'required|string',
            'bank' => 'required|string',
            'nama' => 'required|string',
        ]);

        try {
            $rekening->update($validated);
            Alert::success('Berhasil', 'Surat kontrak berhasil diubah');
            return to_route('kontrak.index', $pegawai);
        } catch (\Throwable $th) {
            Alert::error('Error', 'Server error, coba beberapa saat lagi');
            return back()->withInput();
        }
    }

    public function destroy(Pegawai $pegawai, NomorRekening $rekening)
    {
        try {
            $rekening->delete();
            Alert::success('Berhasil', 'Surat kontrak berhasil dihapus');
            return to_route('kontrak.index', $pegawai);
        } catch (\Throwable $th) {
            Alert::error('Error', 'Server error, coba beberapa saat lagi');
            return back();
        }
    }
}
