<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class FileController extends Controller
{
    public function index(Request $request)
    {
        try {
            return response()->file(storage_path('app/' . $request->path));
        } catch (\Throwable $th) {
            abort(404);
        }
    }
}
