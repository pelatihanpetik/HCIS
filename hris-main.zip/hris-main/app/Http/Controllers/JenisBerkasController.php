<?php

namespace App\Http\Controllers;

use App\Models\JenisBerkas;
use Illuminate\Http\Request;
use RealRashid\SweetAlert\Facades\Alert;

class JenisBerkasController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        return view('jenis-berkas.index', [
            'jenis' => JenisBerkas::all()
        ]);
    }
    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'nama' => 'required|string|max:255|unique:jenis_berkas,nama'
        ]);

        try {
            JenisBerkas::create([
                'nama' => $request->nama
            ]);
            Alert::success('Berhasil', 'Jenis berkas berhasil ditambahkan');
            return to_route('jenis-file.index');
        } catch (\Throwable $th) {
            Alert::error('Error', 'Server error, coba beberapa saat lagi');
            return back()->withInput();
        }
    }
    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, JenisBerkas $jenis)
    {
        $request->validate([
            'nama' => 'required|string|max:255|unique:jenis_berkas,nama,' . $jenis->id
        ]);

        try {
            $jenis->update([
                'nama' => $request->nama
            ]);
            Alert::success('Berhasil', 'Jenis berkas berhasil diubah');
            return to_route('jenis-file.index');
        } catch (\Throwable $th) {
            Alert::error('Error', 'Server error, coba beberapa saat lagi');
            return back()->withInput();
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(JenisBerkas $jenis)
    {
        try {
            $jenis->delete();
            Alert::success('Berhasil', 'Jenis berkas berhasil dihapus');
            return to_route('jenis-file.index');
        } catch (\Throwable $th) {
            Alert::error('Error', 'Server error, coba beberapa saat lagi');
            return back();
        }
    }
}
