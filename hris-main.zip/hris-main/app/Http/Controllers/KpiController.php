<?php

namespace App\Http\Controllers;

use App\Models\Jabatan;
use App\Models\Kpi;
use App\Models\KpiGroup;
use App\Models\KpiPegawai;
use App\Models\KpiPengesahanSetting;
use App\Models\Pegawai;
use App\Models\Posisi;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use RealRashid\SweetAlert\Facades\Alert;

class KpiController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $posisi = Auth::user()->posisi()->orderBy('level', 'asc')->first();
        if ($posisi->level > 2) {
            return to_route('kpi-pegawai.index');
        }
        if (Auth::user()->role == 'admin' || $posisi->level == 1) {
            $kpi = Kpi::orderBy('is_active', 'desc')->paginate(10);
            return view('kpi.index', compact('kpi'));
        }
        $kpi = Kpi::orderBy('is_active', 'desc')
            ->level($posisi->level, $posisi->divisi_id, $posisi->pivot->jabatan_id)
            ->paginate(10);
        return view('kpi.index', compact('kpi'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $posisi = Auth::user()->posisi()->orderBy('level', 'asc')->first();
        $jabatan = Jabatan::with('divisi', 'jenis')
            ->where('level', '>=', $posisi->level)
            ->where('divisi_id', $posisi->divisi_id)
            ->get();
        return view('kpi.create', compact('jabatan'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'nama' => 'required',
            'jabatan' => 'required|array',
            'jabatan.*' => 'required|exists:jabatan,id',
        ]);
        $jabatan = Jabatan::with('divisi', 'jenis')
            ->whereIn('id', $validated['jabatan'])
            ->get();
        $pengesahan =  KpiPengesahanSetting::all();
        $pengesahanDefault = $pengesahan->map(function ($item) {
            return [
                'user_id' => $item->user_id,
                'jabatan' => $item->jabatan,
                'nama' => $item->nama,
                'jabatan_id' => $item->jabatan_id,
            ];
        });
        try {
            DB::beginTransaction();
            foreach ($jabatan as $item) {
                $kpi = Kpi::create([
                    'nama' => $validated['nama'],
                    'jabatan_id' => $item->id,
                    'jabatan' => $item->nama,
                    'divisi' => $item->divisi->nama ?? null,
                    'is_active' => false,
                ]);
                $posisi = Posisi::where('jabatan_id', $item->id)->get();
                if ($posisi->isNotEmpty()) {
                    foreach ($posisi as $val) {
                        $kpi->pengesahan()->createMany(
                            $pengesahanDefault->map(function ($item) use ($val) {
                                return [
                                    'user_id' => $item['user_id'],
                                    'pegawai_id' => $val->user_id,
                                    'jabatan' => $item['jabatan'],
                                    'nama' => $item['nama'],
                                    'jabatan_id' => $item['jabatan_id'],
                                ];
                            })->toArray()
                        );
                    }
                    $kpi->pegawai()->attach($posisi->pluck('user_id'));
                }
                $kpi->pengesahan()->createMany($pengesahanDefault);
            }
            DB::commit();
            Alert::success('Berhasil', 'Data berhasil disimpan');
            return to_route('kpi.index');
        } catch (\Throwable $th) {
            Alert::error('Gagal', 'Data gagal disimpan');
            return back()->withInput();
        }
    }

    public function duplicate(Kpi $kpi)
    {
        $jabatan = Jabatan::with('divisi', 'jenis')
            ->where('id', $kpi->jabatan_id)
            ->first();
        try {
            DB::beginTransaction();
            $newKpi = Kpi::create([
                'nama' => 'Copy of ' . $kpi->nama,
                'jabatan_id' => $jabatan->id,
                'jabatan' => $jabatan->nama,
                'divisi' => $jabatan->divisi->nama ?? null,
                'is_active' => false,
            ]);
            $posisi = Posisi::where('jabatan_id', $jabatan->id)->get();
            if ($posisi->isNotEmpty()) {
                foreach ($posisi as $val) {
                    $kpi->pengesahan()->createMany(
                        $kpi->pengesahan->map(function ($item) use ($val) {
                            return [
                                'user_id' => $item['user_id'],
                                'pegawai_id' => $val->user_id,
                                'jabatan' => $item['jabatan'],
                                'nama' => $item['nama'],
                                'jabatan_id' => $item['jabatan_id'],
                            ];
                        })->toArray()
                    );
                }
                $newKpi->pegawai()->attach($posisi->pluck('user_id'));
            }
            $newKpi->pengesahan()->createMany(
                $kpi->pengesahan->map(function ($item) {
                    return [
                        'user_id' => $item->user_id,
                        'jabatan' => $item->jabatan,
                        'nama' => $item->nama,
                        'jabatan_id' => $item->jabatan_id,
                    ];
                })->toArray()
            );
            $newKpi->lists()->createMany(
                $kpi->lists->map(function ($item) {
                    return [
                        'kpi_group_id' => $item->kpi_group_id,
                        'teks' => $item->teks,
                        'kriteria' => $item->kriteria,
                        'bobot' => $item->bobot,
                    ];
                })->toArray()
            );
            DB::commit();
            Alert::success('Berhasil', 'Data berhasil disimpan');
            return to_route('kpi.index');
        } catch (\Throwable $th) {
            Alert::error('Gagal', 'Data gagal disimpan');
            return back()->withInput();
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(Kpi $kpi)
    {
        $tab = 'preview';
        $kpi->load('details', 'details.pegawai:id,nama', 'details.prb', 'details.akhir');
        $pegawai = Pegawai::select('id', 'nama')
            ->whereNotIn('id', $kpi->details->pluck('pegawai_id'))
            ->get();
        return view('kpi.show', compact('kpi', 'tab', 'pegawai'));
    }

    public function detail(string $id, string $pegawai)
    {
        $kpiPegawai = KpiPegawai::where('pegawai_id', $pegawai)
            ->where('kpi_id', $id)
            ->with('pegawai:id,nama')
            ->firstOrFail();
        $lists = KpiGroup::with(
            ['lists' => function ($query) use ($id) {
                $query->where('kpi_id', $id);
            }],
            ['lists.pegawai' => function ($query) use ($pegawai) {
                $query->where('pegawai_id', $pegawai);
            }]
        )->get();
        $tab = 'preview';
        $kpi = $kpiPegawai->kpi;
        $kpi->load(['pengesahan' => function ($query) use ($pegawai) {
            $query->where('pegawai_id', $pegawai);
        }]);
        return view('kpi.detail', compact('kpi', 'lists', 'tab', 'kpiPegawai'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Kpi $kpi)
    {
        return view('kpi.edit', compact('kpi'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Kpi $kpi)
    {
        $request->validate([
            'nama' => 'required',
            'status' => 'required|boolean',
        ]);
        try {
            DB::beginTransaction();
            $kpi->update([
                'nama' => $request->nama,
                'is_active' => $request->status,
            ]);
            if ($request->boolean('status')) {
                Kpi::where('id', '!=', $kpi->id)
                    ->where('jabatan_id', $kpi->jabatan_id)
                    ->update(['is_active' => false]);
            }
            DB::commit();
            Alert::success('Berhasil', 'Data berhasil diubah');
            return to_route('kpi.index');
        } catch (\Throwable $th) {
            DB::rollBack();
            Alert::error('Gagal', 'Data gagal diubah');
            return back()->withInput();
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Kpi $kpi)
    {
        try {
            $kpi->delete();
            Alert::success('Berhasil', 'Data berhasil dihapus');
            return to_route('kpi.index');
        } catch (\Throwable $th) {
            Alert::error('Gagal', 'Data gagal dihapus');
            return back();
        }
    }

    public function addPegawai(Kpi $kpi, Request $request)
    {
        $request->validate([
            'pegawai' => 'required|exists:pegawai,id',
        ]);

        try {
            $kpi->pegawai()->attach($request->pegawai);
            Alert::success('Berhasil', 'Data berhasil disimpan');
            return back();
        } catch (\Throwable $th) {
            Alert::error('Gagal', 'Data gagal disimpan');
            return back();
        }
    }

    public function removePegawai(Kpi $kpi, string $pegawai)
    {
        try {
            DB::beginTransaction();
            $kpi->pegawai()->detach($pegawai);
            DB::table('kpi_list_detail')
                ->join('kpi_list', 'kpi_list.id', '=', 'kpi_list_detail.kpi_list_id')
                ->where('kpi_list.kpi_id', $kpi->id)
                ->where('kpi_list_detail.pegawai_id', $pegawai)
                ->delete();
            DB::commit();
            Alert::success('Berhasil', 'Data berhasil dihapus');
            return back();
        } catch (\Throwable $th) {
            Alert::error('Gagal', 'Data gagal dihapus');
            return back();
        }
    }
}
