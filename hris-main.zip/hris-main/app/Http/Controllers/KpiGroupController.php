<?php

namespace App\Http\Controllers;

use App\Models\KpiGroup;
use Illuminate\Http\Request;
use RealRashid\SweetAlert\Facades\Alert;

class KpiGroupController extends Controller
{
    public function index()
    {
        $group = KpiGroup::all();
        return view('kpi-group.index', compact('group'));
    }

    public function create()
    {
        return view('kpi-group.create');
    }

    public function store(Request $request)
    {
        $maxBobot = 100 - KpiGroup::sum('bobot');
        $validated = $request->validate([
            'nama' => 'required',
            'bobot' => "required|numeric|max:$maxBobot|min:1"
        ]);

        try {
            KpiGroup::create($validated);
            Alert::success('Berhasil', 'Data berhasil disimpan');
            return to_route('kpi-group.index');
        } catch (\Exception $e) {
            Alert::error('Gagal', 'Data gagal disimpan');
            return back()->withInput();
        }
    }

    public function edit(KpiGroup $group)
    {
        return view('kpi-group.edit', compact('group'));
    }

    public function update(KpiGroup $group)
    {
        $maxBobot = 100 - KpiGroup::where('id', '!=', $group->id)->sum('bobot');
        $validated = request()->validate([
            'nama' => 'required',
            'bobot' => "required|numeric|max:$maxBobot|min:1"
        ]);

        try {
            $group->update($validated);
            Alert::success('Berhasil', 'Data berhasil diubah');
            return to_route('kpi-group.index');
        } catch (\Exception $e) {
            Alert::error('Gagal', 'Data gagal diubah');
            return back()->withInput();
        }
    }

    public function destroy(KpiGroup $group)
    {
        try {
            $group->delete();
            Alert::success('Berhasil', 'Data berhasil dihapus');
            return to_route('kpi-group.index');
        } catch (\Exception $e) {
            Alert::error('Gagal', 'Data gagal dihapus');
            return back();
        }
    }
}
