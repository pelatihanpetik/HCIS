<?php

namespace App\Http\Controllers;

use App\Models\Pegawai;
use App\Models\Posisi;
use Illuminate\Http\Request;
use RealRashid\SweetAlert\Facades\Alert;

class PosisiController extends Controller
{
    public function store(Request $request, Pegawai $pegawai)
    {
        $request->validate([
            'posisi' => 'required|exists:jabatan,id'
        ]);

        try {
            $pegawai->posisi()->attach($request->posisi);
            Alert::success('Berhasil', 'Berkas berhasil ditambahkan');
            return to_route('pegawai.show', $pegawai->id);
        } catch (\Throwable $th) {
            Alert::error('Error', 'Server error, coba beberapa saat lagi');
            return back()->withInput();
        }
    }

    public function update(Request $request, Pegawai $pegawai, string $posisi)
    {
        $request->validate([
            'posisi' => 'required|exists:jabatan,id'
        ]);

        try {
            $pegawai->posisi()->updateExistingPivot($posisi, ['jabatan_id' => $request->posisi]);
            Alert::success('Berhasil', 'Berkas berhasil disimpan');
            return to_route('pegawai.show', $pegawai->id);
        } catch (\Throwable $th) {
            Alert::error('Error', 'Server error, coba beberapa saat lagi');
            return back()->withInput();
        }
    }

    public function destroy(Pegawai $pegawai, string $posisi)
    {
        try {
            $pegawai->posisi()->detach($posisi);
            Alert::success('Berhasil', 'Berkas berhasil dihapus');
            return to_route('pegawai.show', $pegawai->id);
        } catch (\Throwable $th) {
            Alert::error('Error', 'Server error, coba beberapa saat lagi');
            return back();
        }
    }
}
