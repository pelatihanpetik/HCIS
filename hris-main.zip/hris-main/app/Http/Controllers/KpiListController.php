<?php

namespace App\Http\Controllers;

use App\Models\Kpi;
use App\Models\KpiGroup;
use App\Models\KpiList;
use Illuminate\Http\Request;
use RealRashid\SweetAlert\Facades\Alert;

class KpiListController extends Controller
{
    public function index(Kpi $kpi)
    {
        $tab = 'list';
        $lists = $kpi->lists()->with('group')->get()->groupBy('group.nama');
        return view('kpi-list.index', compact('kpi', 'tab', 'lists'));
    }

    public function create(Kpi $kpi)
    {
        $tab = 'list';
        $point = ['1', '2', '3', '4', '5'];
        $group = KpiGroup::all();
        return view('kpi-list.create', compact('kpi', 'tab', 'point', 'group'));
    }

    public function store(Request $request, Kpi $kpi)
    {
        $group = KpiGroup::findOrFail($request->group);
        $sumBobot = KpiList::where('kpi_group_id', $group->id)->sum('bobot');
        $validated = $request->validate([
            'group' => 'required',
            'teks' => 'required',
            'kriteria' => 'required|array',
            'kriteria.*' => 'required',
            'bobot' => 'required|numeric|min:1|max:' . ($group->bobot - $sumBobot),
        ]);
        $kriteria = [];
        foreach ($validated['kriteria'] as $key => $value) {
            $kriteria[$key + 1] = $value;
        }

        try {
            $kpi->lists()->create([
                'kpi_group_id' => $group->id,
                'teks' => $validated['teks'],
                'kriteria' => $kriteria,
                'bobot' => $validated['bobot'],
            ]);
            Alert::success('Berhasil', 'Data berhasil disimpan');
            return to_route('kpi.list.index', $kpi->id);
        } catch (\Throwable $th) {
            Alert::error('Gagal', 'Data gagal disimpan');
            return back()->withInput();
        }
    }

    public function edit(Kpi $kpi, KpiList $list)
    {
        $tab = 'list';
        $group = KpiGroup::all();
        return view('kpi-list.edit', compact('kpi', 'tab', 'group', 'list'));
    }

    public function update(Kpi $kpi, KpiList $list, Request $request)
    {
        $group = KpiGroup::findOrFail($request->group);
        $sumBobot = KpiList::where('kpi_group_id', $group->id)
            ->where('id', '!=', $list->id)
            ->sum('bobot');
        $validated = $request->validate([
            'group' => 'required',
            'teks' => 'required',
            'kriteria' => 'required|array',
            'kriteria.*' => 'required',
            'bobot' => 'required|numeric|min:1|max:' . ($group->bobot - $sumBobot),
        ]);
        $kriteria = [];
        foreach ($validated['kriteria'] as $key => $value) {
            $kriteria[$key + 1] = $value;
        }

        try {
            $list->update([
                'kpi_group_id' => $group->id,
                'teks' => $validated['teks'],
                'kriteria' => $kriteria,
                'bobot' => $validated['bobot'],
            ]);
            Alert::success('Berhasil', 'Data berhasil disimpan');
            return to_route('kpi.list.index', $kpi->id);
        } catch (\Throwable $th) {
            Alert::error('Gagal', 'Data gagal disimpan');
            return back()->withInput();
        }
    }

    public function destroy(string $kpi, KpiList $list)
    {
        try {
            $list->delete();
            Alert::success('Berhasil', 'Data berhasil dihapus');
            return to_route('kpi.list.index', $kpi);
        } catch (\Throwable $th) {
            Alert::error('Gagal', 'Data gagal dihapus');
            return back();
        }
    }
}
