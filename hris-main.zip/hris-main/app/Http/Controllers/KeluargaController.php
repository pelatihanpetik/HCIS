<?php

namespace App\Http\Controllers;

use App\Models\Agama;
use App\Models\Keluarga;
use App\Models\Pegawai;
use App\Models\StatusKeluarga;
use Illuminate\Http\Request;
use RealRashid\SweetAlert\Facades\Alert;

class KeluargaController extends Controller
{
    public function index(Pegawai $pegawai)
    {
        $tab = 'keluarga';
        return view('keluarga.index', compact('pegawai', 'tab'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create(Pegawai $pegawai)
    {
        $tab = 'keluarga';
        $agama = Agama::get();
        $status = StatusKeluarga::get();
        return view('keluarga.create', compact('pegawai', 'tab', 'agama', 'status'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request, Pegawai $pegawai)
    {
        $validated = $request->validate([
            "nik" => "nullable|numeric|digits:16",
            "nama" => "required|string",
            "tempat_lahir" => "nullable|string",
            "tanggal_lahir" => "nullable|date",
            "agama" => "nullable|string",
            "status" => "required|in:" . implode(',', StatusKeluarga::get()),
            "jenis_kelamin" => "required|in:L,P",
        ]);

        try {
            $pegawai->keluarga()->create($validated);
            Alert::success('Berhasil', 'Keluarga berhasil ditambahkan');
            return to_route('keluarga.index', $pegawai->id);
        } catch (\Throwable $th) {
            Alert::error('Error', 'Server error, coba beberapa saat lagi');
            return back()->withInput();
        }
    }

    public function edit(Pegawai $pegawai, Keluarga $keluarga)
    {
        $tab = 'keluarga';
        $agama = Agama::get();
        $status = StatusKeluarga::get();
        return view('keluarga.edit', compact('pegawai', 'tab', 'keluarga', 'agama', 'status'));
    }
    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Pegawai $pegawai, Keluarga $keluarga)
    {
        $validated = $request->validate([
            "nik" => "nullable|numeric|digits:16",
            "nama" => "required|string",
            "tempat_lahir" => "nullable|string",
            "tanggal_lahir" => "nullable|date",
            "agama" => "nullable|string",
            "status" => "required|in:" . implode(',', StatusKeluarga::get()),
            "jenis_kelamin" => "required|in:L,P",
        ]);

        try {
            $keluarga->update($validated);
            Alert::success('Berhasil', 'Keluarga berhasil diubah');
            return to_route('keluarga.index', $pegawai);
        } catch (\Throwable $th) {
            Alert::error('Error', 'Server error, coba beberapa saat lagi');
            return back()->withInput();
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Pegawai $pegawai, Keluarga $keluarga)
    {
        try {
            $keluarga->delete();
            Alert::success('Berhasil', 'Keluarga berhasil dihapus');
            return to_route('keluarga.index', $pegawai);
        } catch (\Throwable $th) {
            Alert::error('Error', 'Server error, coba beberapa saat lagi');
            return back();
        }
    }
}
