<?php

namespace App\Http\Controllers;

use App\Models\Alamat;
use App\Models\Pegawai;
use App\Models\Wilayah;
use Illuminate\Http\Request;
use RealRashid\SweetAlert\Facades\Alert;

class AlamatController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Pegawai $pegawai)
    {
        $tab = 'alamat';
        return view('alamat.index', compact('pegawai', 'tab'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create(Pegawai $pegawai)
    {
        $tab = 'alamat';
        $provinsi = Wilayah::selectRaw('DISTINCT(provinsi) as nama')->get();
        return view('alamat.create', compact('pegawai', 'tab', 'provinsi'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Pegawai $pegawai, Request $request)
    {
        $validated = $request->validate([
            "label" => "required|string|max:255",
            "provinsi" => "required|string",
            "kab_kota" => "required|string",
            "kecamatan" => "required|string",
            "kel_desa" => "required|string",
            "rt_rw" => "nullable|string|max:100",
            "kode_pos" => "nullable|numeric",
            "faks" => 'nullable|string|max:100',
            "jalan" => 'nullable|string',
        ]);

        try {
            $pegawai->alamat()->create($validated);
            Alert::success('Berhasil', 'Alamat berhasil ditambahkan');
            return to_route('alamat.index', $pegawai->id);
        } catch (\Throwable $th) {
            Alert::error('Error', 'Server error, coba beberapa saat lagi');
            return back()->withInput();
        }
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Pegawai $pegawai, Alamat $alamat)
    {
        $tab = 'alamat';
        $provinsi = Wilayah::selectRaw('DISTINCT(provinsi) as nama')->get();
        return view('alamat.edit', compact('pegawai', 'tab', 'provinsi', 'alamat'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Pegawai $pegawai, Alamat $alamat)
    {
        $validated = $request->validate([
            "label" => "required|string|max:255",
            "provinsi" => "required|string",
            "kab_kota" => "required|string",
            "kecamatan" => "required|string",
            "kel_desa" => "required|string",
            "rt_rw" => "nullable|string|max:100",
            "kode_pos" => "nullable|numeric",
            "faks" => 'nullable|string|max:100',
            "jalan" => 'nullable|string',
        ]);

        try {
            $alamat->update($validated);
            Alert::success('Berhasil', 'Alamat berhasil disimpan');
            return to_route('alamat.index', $pegawai);
        } catch (\Throwable $th) {
            Alert::error('Error', 'Server error, coba beberapa saat lagi');
            return back()->withInput();
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Pegawai $pegawai, string $id)
    {
        try {
            Alamat::where('id', $id)
                ->delete();
            Alert::success('Berhasil', 'Alamat berhasil dihapus');
            return to_route('alamat.index', $pegawai);
        } catch (\Throwable $th) {
            Alert::error('Error', 'Server error, coba beberapa saat lagi');
            return back();
        }
    }
}
