<?php

namespace App\Http\Controllers;

use App\Models\Divisi;
use App\Models\Jabatan;
use App\Models\JenisJabatan;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;
use RealRashid\SweetAlert\Facades\Alert;

class JabatanController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        return view('jabatan.index', [
            'jabatan' => Jabatan::with('jenis:id,nama', 'divisi:id,nama')->get()
        ]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('jabatan.create', [
            'jenis' => JenisJabatan::all(),
            'divisi' => Divisi::all()
        ]);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            "jenis" => "required",
            "divisi" => 'nullable|exists:divisi,id',
            "nama" => "required|string|max:255",
        ]);
        $jenis = JenisJabatan::findOrFail($request->jenis);
        if ($jenis->level > 1 && !$request->divisi) {
            throw ValidationException::withMessages([
                'divisi' => 'Divisi harus diisi untuk jabatan ini'
            ]);
        }
        if ($jenis->level > 2) {
            $parent = Jabatan::where('divisi_id', $request->divisi)
                ->where('level', $jenis->level - 1)
                ->first();
        } elseif ($jenis->level == 2) {
            $parent = Jabatan::where('level', 1)
                ->first();
        } else {
            $parent = null;
        }
        try {
            Jabatan::create([
                'jenis_jabatan_id' => $jenis->id,
                'divisi_id' => $request->divisi,
                'parent_id' => $parent->id ?? null,
                'nama' => $request->nama,
                'level' => $jenis->level,
            ]);
            Alert::success('Berhasil', 'Jabatan berhasil ditambahkan');
            return to_route('jabatan.index');
        } catch (\Throwable $th) {
            Alert::error('Error', 'Server error, coba beberapa saat lagi');
            return back()->withInput();
        }
    }
    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Jabatan $jabatan)
    {
        return view('jabatan.edit', [
            'jabatan' => $jabatan,
            'divisi' => Divisi::all()
        ]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Jabatan $jabatan)
    {
        $request->validate([
            "divisi" => 'nullable|exists:divisi,id',
            "nama" => "required|string|max:255",
        ]);
        $jenis = JenisJabatan::findOrFail($jabatan->jenis_jabatan_id);
        if ($jenis->level > 1 && !$request->divisi) {
            throw ValidationException::withMessages([
                'divisi' => 'Divisi harus diisi untuk jabatan ini'
            ]);
        }
        if ($jenis->level > 2) {
            $parent = Jabatan::where('divisi_id', $request->divisi)
                ->where('level', $jenis->level - 1)
                ->first();
        } elseif ($jenis->level == 2) {
            $parent = Jabatan::where('level', 1)
                ->first();
        } else {
            $parent = null;
        }
        try {
            $jabatan->update([
                'jenis_jabatan_id' => $jenis->id,
                'divisi_id' => $request->divisi,
                'parent_id' => $parent->id ?? null,
                'nama' => $request->nama,
                'level' => $jenis->level,
            ]);
            Alert::success('Berhasil', 'Jabatan berhasil diubah!');
            return to_route('jabatan.index');
        } catch (\Throwable $th) {
            Alert::error('Error', 'Server error, coba beberapa saat lagi');
            return back()->withInput();
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Jabatan $jabatan)
    {
        try {
            $jabatan->delete();
            Alert::success('Berhasil', 'Jabatan berhasil dihapus');
            return to_route('jabatan.index');
        } catch (\Throwable $th) {
            Alert::error('Error', 'Server error, coba beberapa saat lagi');
            return back();
        }
    }
}
