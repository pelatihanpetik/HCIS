<?php

namespace App\Http\Controllers;

use App\Models\KpiGroup;
use App\Models\KpiPegawai;
use App\Models\KpiPengesahan;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use RealRashid\SweetAlert\Facades\Alert;

class KpiPegawaiController extends Controller
{
    public function index()
    {
        $kpi = KpiPegawai::with('kpi', 'prb', 'akhir')
            ->withSum('lists', 'bobot')
            ->where('pegawai_id', Auth::user()->id)
            ->get();
        return view('kpi-pegawai.index', compact('kpi'));
    }

    public function create(string $id)
    {
        $kpi = KpiPegawai::with('kpi:id,nama,divisi,jabatan')
            ->where('pegawai_id', Auth::user()->id)
            ->where('kpi_id', $id)
            ->withCount('lists')
            ->firstOrFail();

        $lists = KpiGroup::with(
            ['lists' => function ($query) use ($kpi) {
                $query->where('kpi_id', $kpi->kpi_id);
            }],
            ['lists.pegawai' => function ($query) {
                $query->where('pegawai_id', Auth::user()->id);
            }]
        )->get();

        if ($kpi->lists_count == 0) {
            $list = [];
            foreach ($lists as $item) {
                foreach ($item->lists as $val) {
                    $list[] = [
                        'pegawai_id' => Auth::user()->id,
                        'kpi_list_id' => $val->id,
                        'bobot' => 0,
                        'nilai' => 0,
                    ];
                }
            }
            $kpi->lists()->createMany($list);
        }

        return view('kpi-pegawai.isi', compact('kpi', 'lists'));
    }

    public function store(Request $request, string $id)
    {
        $kpi = KpiPegawai::where('pegawai_id', Auth::user()->id)
            ->where('kpi_id', $id)
            ->with('lists', 'lists.list:id,bobot')
            ->firstOrFail();
        $rules = [];
        $data = [];
        foreach ($kpi->lists as $item) {
            $rules["nilai_{$item->list->id}"] = 'required|numeric|min:1|max:5';
            $row = [
                'id' => $item->id,
                'kpi_list_id' => $item->list->id,
                'pegawai_id' => Auth::user()->id,
                'nilai' => (int)$request["nilai_{$item->id}"],
            ];
            $row['bobot'] = $item->list->bobot * ($row['nilai'] / 4);
            $data[] = $row;
        }

        try {
            DB::table('kpi_list_detail')->upsert($data, ['id'], ['nilai', 'bobot']);
            Alert::success('Berhasil', 'Data berhasil disimpan');
            return to_route('kpi-pegawai.create', $id);
        } catch (\Throwable $th) {
            Alert::error('Gagal', 'Data gagal disimpan');
            return back()->withInput();
        }
    }

    public function show(string $id)
    {
        $kpi = KpiPegawai::where('pegawai_id', Auth::user()->id)
            ->where('kpi_id', $id)
            ->firstOrFail();
        $lists = KpiGroup::with(
            ['lists' => function ($query) use ($kpi) {
                $query->where('kpi_id', $kpi->kpi_id);
            }],
            ['lists.pegawai' => function ($query) {
                $query->where('pegawai_id', Auth::user()->id);
            }]
        )->get();

        $pengesahan = KpiPengesahan::where('kpi_id', $id)
            ->where('pegawai_id', Auth::user()->id)
            ->get();
        return view('kpi-pegawai.show', compact('kpi', 'lists', 'pengesahan'));
    }
}
