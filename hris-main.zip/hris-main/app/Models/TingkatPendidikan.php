<?php

namespace App\Models;

class TingkatPendidikan
{
    public static function get()
    {
        return [
            'SD',
            'SMP',
            'SMA',
            'D3',
            'S1',
            'S2',
            'S3',
        ];
    }
}
