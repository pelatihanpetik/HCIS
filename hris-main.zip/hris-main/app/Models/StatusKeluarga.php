<?php

namespace App\Models;

class StatusKeluarga
{
    public static function get()
    {
        return [
            'Anak',
            'Istri',
            'Suami',
            'Ayah',
            'Ibu',
        ];
    }
}
