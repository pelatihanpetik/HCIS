<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class KpiPegawai extends Model
{
    use HasFactory;
    protected $table = 'kpi_pegawai';
    protected $guarded = ['id'];
    public $timestamps = false;

    public function kpi()
    {
        return $this->belongsTo(Kpi::class);
    }

    public function pegawai()
    {
        return $this->belongsTo(Pegawai::class);
    }

    public function lists(): HasMany
    {
        return $this->hasMany(KpiListDetail::class, 'pegawai_id', 'pegawai_id');
    }

    public function prb()
    {
        return $this->belongsTo(Rekomendasi::class, 'perbaikan_id');
    }

    public function akhir()
    {
        return $this->belongsTo(Rekomendasi::class, 'rekomendasi_akhir_id');
    }
}
