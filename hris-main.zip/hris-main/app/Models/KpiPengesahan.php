<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class KpiPengesahan extends Model
{
    use HasFactory;
    protected $table = 'kpi_pengesahan';
    protected $guarded = ['id', 'created_at', 'updated_at'];

    public function kpi()
    {
        return $this->belongsTo(Kpi::class);
    }

    public function casts(): array
    {
        return [
            'tanggal' => 'date',
        ];
    }
}
