<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Jabatan extends Model
{
    use HasFactory;
    protected $table = 'jabatan';
    protected $fillable = ['nama', 'jenis_jabatan_id', 'divisi_id', 'level', 'parent_id'];
    public $timestamps = false;

    public function jenis()
    {
        return $this->belongsTo(JenisJabatan::class, 'jenis_jabatan_id', 'id');
    }

    public function divisi()
    {
        return $this->belongsTo(Divisi::class, 'divisi_id', 'id');
    }
}
