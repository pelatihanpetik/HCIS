<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Kpi extends Model
{
    use HasFactory;
    protected $table = 'kpi';
    protected $guarded = ['id'];
    public $timestamps = false;

    public function lists(): HasMany
    {
        return $this->hasMany(KpiList::class);
    }

    public function pegawai(): BelongsToMany
    {
        return $this->belongsToMany(Pegawai::class, 'kpi_pegawai', 'kpi_id', 'pegawai_id');
    }

    public function pengesahan(): HasMany
    {
        return $this->hasMany(KpiPengesahan::class, 'kpi_id', 'id');
    }

    public function details(): HasMany
    {
        return $this->hasMany(KpiPegawai::class, 'kpi_id', 'id');
    }

    public function jabatan(): BelongsTo
    {
        return $this->belongsTo(Jabatan::class, 'jabatan_id', 'id');
    }

    public function scopeLevel(Builder $query, string $level, string $divisi, string $jabatanId): void
    {
        $jabatan = Jabatan::select('id')
            ->where('level', '>', $level)
            ->where('divisi_id', $divisi)
            ->get();
        $query->whereIn('jabatan_id', $jabatan->pluck('id')->push($jabatanId));
    }
}
