<?php

namespace App\Models;

class StatusKawin
{
    public static function get()
    {
        return [
            'K' => 'Kawin',
            'J' => 'Janda',
            'D' => 'Duda',
            'BK' => 'Belum Kawin',
        ];
    }
}
