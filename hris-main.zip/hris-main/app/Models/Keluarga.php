<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Keluarga extends Model
{
    use HasFactory;
    protected $table = 'keluarga';
    protected $guarded = ['id', 'user_id'];
    public $timestamps = false;

    protected function casts(): array
    {
        return [
            'tanggal_lahir' => 'date',
        ];
    }
}
