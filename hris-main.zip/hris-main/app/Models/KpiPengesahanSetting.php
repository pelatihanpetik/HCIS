<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class KpiPengesahanSetting extends Model
{
    use HasFactory;
    protected $table = 'kpi_pengesahan_setting';
    protected $guarded = ['id'];
    public $timestamps = false;

    public function jabatan()
    {
        return $this->belongsTo(Jabatan::class);
    }
}
