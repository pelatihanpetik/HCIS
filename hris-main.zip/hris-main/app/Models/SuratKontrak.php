<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SuratKontrak extends Model
{
    use HasFactory;
    protected $table = 'surat_kontrak';
    protected $guarded = ['id', 'user_id'];
    public $timestamps = false;

    protected function casts(): array
    {
        return [
            'tanggal_dari' => 'date',
            'tanggal_sampai' => 'date',
        ];
    }
}
