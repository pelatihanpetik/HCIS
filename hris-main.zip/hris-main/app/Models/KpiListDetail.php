<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class KpiListDetail extends Model
{
    use HasFactory;
    protected $table = 'kpi_list_detail';
    protected $guarded = ['id'];
    public $timestamps = false;

    public function list()
    {
        return $this->belongsTo(KpiList::class, 'kpi_list_id', 'id');
    }
}
