<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class KpiGroup extends Model
{
    use HasFactory;
    protected $table = 'kpi_group';
    protected $guarded = ['id'];
    public $timestamps = false;

    public function lists()
    {
        return $this->hasMany(KpiList::class, 'kpi_group_id');
    }
}
