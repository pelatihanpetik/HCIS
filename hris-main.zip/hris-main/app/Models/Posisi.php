<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Posisi extends Model
{
    use HasFactory;
    protected $table = 'posisi';
    protected $fillable = ['jabatan_id', 'user_id'];
    public $timestamps = false;

    public function jabatan()
    {
        return $this->belongsTo(Jabatan::class, 'jabatan_id', 'id');
    }

    public function pegawai()
    {
        return $this->belongsTo(Pegawai::class, 'user_id', 'id');
    }
}
