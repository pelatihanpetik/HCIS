<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Pegawai extends Model
{
    use HasFactory;
    protected $table = 'pegawai';
    protected $guarded = [];

    protected function casts(): array
    {
        return [
            'tanggal_lahir' => 'date',
        ];
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class, 'id', 'id');
    }

    public function alamat(): HasMany
    {
        return $this->hasMany(Alamat::class, 'user_id', 'id');
    }

    public function berkas(): HasMany
    {
        return $this->hasMany(Berkas::class, 'user_id', 'id');
    }

    public function posisi(): BelongsToMany
    {
        return $this->belongsToMany(Jabatan::class, 'posisi', 'user_id', 'jabatan_id');
    }

    public function kontrak(): HasMany
    {
        return $this->hasMany(SuratKontrak::class, 'user_id', 'id');
    }

    public function rekening(): HasMany
    {
        return $this->hasMany(NomorRekening::class, 'user_id', 'id');
    }

    public function keluarga(): HasMany
    {
        return $this->hasMany(Keluarga::class, 'user_id', 'id');
    }

    public function pendidikan(): HasMany
    {
        return $this->hasMany(Pendidikan::class, 'user_id', 'id');
    }

    public function pelatihan(): HasMany
    {
        return $this->hasMany(Pelatihan::class, 'user_id', 'id');
    }

    public function timesheets(): HasMany
    {
        return $this->hasMany(Timesheet::class, 'user_id', 'id');
    }
}
