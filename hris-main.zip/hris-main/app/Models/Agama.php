<?php

namespace App\Models;

class Agama
{
    public static function get()
    {
        return [
            'Islam',
            'Kristen',
            'Katolik',
            'Hindu',
            'Budha',
            'Konghucu',
        ];
    }
}
