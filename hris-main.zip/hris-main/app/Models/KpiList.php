<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;

class KpiList extends Model
{
    use HasFactory;
    protected $table = 'kpi_list';
    protected $guarded = ['id', 'kpi_id', 'created_at', 'updated_at'];

    public function casts(): array
    {
        return [
            'kriteria' => 'array',
        ];
    }

    public function kpi()
    {
        return $this->belongsTo(Kpi::class);
    }

    public function group()
    {
        return $this->belongsTo(KpiGroup::class, 'kpi_group_id');
    }

    public function pegawai(): HasOne
    {
        return $this->hasOne(KpiListDetail::class, 'kpi_list_id');
    }
}
