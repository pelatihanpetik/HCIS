<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class NomorRekening extends Model
{
    use HasFactory;
    protected $table = 'nomor_rekening';
    protected $guarded = ['id', 'user_id'];
    public $timestamps = false;
}
