<?php

namespace App\Providers;

use App\Models\Pegawai;
use App\Models\Timesheet;
use App\Policies\PegawaiPolicy;
use App\Policies\TimesheetPolicy;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\Facades\Blade;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        Blade::directive('currency', function ($money) {
            return "<?php echo 'Rp ' .  number_format($money, 0, ',', '.'); ?>";
        });

        Paginator::useBootstrapFour();

        Gate::policy(Pegawai::class, PegawaiPolicy::class);
        Gate::policy(Timesheet::class, TimesheetPolicy::class);
    }
}
