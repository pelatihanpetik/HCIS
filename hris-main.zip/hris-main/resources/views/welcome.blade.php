<x-layouts.base>
    <x-slot:title>
        <h3 class="mb-0 font-weight-bold">Kenneth Osborne</h3>
        <p>Your last login: 21h ago from newzealand.</p>
    </x-slot>

    <x-slot:subtitle>
        <button type="button" class="btn btn-sm bg-white btn-icon-text border"><i
                class="typcn typcn-info-large-outline mr-2"></i>info</button>
    </x-slot>
</x-layouts.base>
