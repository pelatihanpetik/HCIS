@extends('kpi.layout')

@section('content')
    <div class="table-responsive">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama</th>
                    <th>Jabatan</th>
                    <th>TTD</th>
                    <th>Tanggal</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($pengesahan as $item)
                    <tr>
                        <td>{{ $loop->iteration }}</td>
                        <td>{{ $item->nama }}</td>
                        <td>{{ $item->jabatan }}</td>
                        <td>
                            @if ($item->ttd)
                                <img src="{{ route('file.index', ['path' => $item->ttd]) }}" alt="ttd" width="100">
                            @else
                                <span class="badge badge-danger">Belum diisi</span>
                            @endif
                        </td>
                        <td>
                            @if ($item->tanggal)
                                {{ $item->tanggal->isoFormat('D MMMM YYYY') }}
                            @else
                                <span class="badge badge-danger">Belum diisi</span>
                            @endif
                        </td>
                        <td>
                            <button class="btn btn-sm btn-success btn-edit" data-toggle="modal" data-target="#modalTTD"
                                type="button" data-ttd='@json($item)'
                                data-url="{{ route('kpi.ttd.update', [$kpi->id, $item->id]) }}">
                                Edit
                            </button>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>

    <div class="modal fade" id="modalTTD" tabindex="-1" aria-labelledby="modalTTDLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="modalTTDLabel">Jenis Jabatan</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form action="" method="post" enctype="multipart/form-data">
                    <div class="modal-body">
                        @csrf
                        @method('PUT')
                        <div class="form-group">
                            <label>Nama</label>
                            <input class="form-control form-control-sm @error('nama') is-invalid @enderror" name="nama"
                                value="{{ old('nama') }}" required autocomplete="off">
                            @error('nama')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label>Jabatan</label>
                            <input class="form-control form-control-sm @error('jabatan') is-invalid @enderror"
                                name="jabatan" value="{{ old('jabatan') }}" required autocomplete="off">
                            @error('jabatan')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label>Tanggal</label>
                            <input class="form-control form-control-sm @error('tanggal') is-invalid @enderror"
                                name="tanggal" value="{{ old('tanggal') }}" required autocomplete="off" type="date">
                            @error('tanggal')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label>TTD</label>
                            <input class="form-control form-control-sm @error('ttd') is-invalid @enderror" name="ttd"
                                required type="file" accept="image/*">
                            @error('ttd')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-secondary btn-sm">Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    @push('js')
        <script>
            $(document).on('click', '.btn-edit', function() {
                $('#modalTTD form').attr('action', $(this).data('url'));
                const data = $(this).data('ttd');
                $('#modalTTD input[name="nama"]').val(data.nama);
                $('#modalTTD input[name="jabatan"]').val(data.jabatan);
                $('#modalTTD input[name="tanggal"]').val(new Date(data.tanggal).toISOString().split('T')[0]);
            });
        </script>
    @endpush
@endsection
