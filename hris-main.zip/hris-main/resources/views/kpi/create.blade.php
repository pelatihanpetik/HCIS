<x-layouts.base>
    <x-slot:title>
        <h3>Tambah KPI</h3>
    </x-slot>
    <x-slot:subtitle>
        <a class="btn btn-sm bg-white btn-icon-text border" href="{{ route('kpi.index') }}">
            <i class="typcn typcn-chevron-left"></i>
            Kembali
        </a>
    </x-slot>

    <div class="card">
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <form action="{{ route('kpi.store') }}" method="post">
                        @csrf
                        <div class="form-group">
                            <label for="nama">Nama</label>
                            <input class="form-control form-control-sm @error('nama') is-invalid @enderror"
                                name="nama" value="{{ old('nama') }}" required autofocus autocomplete="off">
                            @error('nama')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label>Jabatan</label>
                            <select name="jabatan[]" class="form-control @error('jabatan') is-invalid @enderror"
                                multiple>
                                <option value="" hidden>Pilih jabatan</option>
                                @foreach ($jabatan as $item)
                                    <option value="{{ $item->id }}" @selected(in_array($item->id, old('jabatan', [])))>
                                        @if ($item->divisi_id)
                                            Divisi {{ $item->divisi->nama }}:
                                        @endif
                                        {{ $item->nama }} ({{ $item->jenis->nama }})
                                    </option>
                                @endforeach
                            </select>
                            @error('jabatan')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <button class="btn btn-primary">Submit</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</x-layouts.base>
