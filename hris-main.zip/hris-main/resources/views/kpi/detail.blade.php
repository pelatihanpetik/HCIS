@extends('kpi.layout')

@section('content')
    <h3 class="text-center">{{ $kpi->nama }}</h3>
    <div class="row">
        <div class="col-md-6">
            <ul class="list-group">
                <li class="list-group-item d-flex justify-between">
                    <strong>Nama Pegawai:</strong>&nbsp;
                    <span>{{ $kpiPegawai->pegawai->nama }}</span>
                </li>
                <li class="list-group-item d-flex justify-between">
                    <strong>Jabatan:</strong>&nbsp;<span>{{ $kpi->jabatan }}</span>
                </li>
                <li class="list-group-item d-flex justify-between">
                    <strong>Divisi:</strong>&nbsp;<span>{{ $kpi->divisi }}</span>
                </li>
            </ul>
        </div>
        <div class="col-12">
            @php
                $no = 'A';
                $totalBobot = 0;
            @endphp
            @foreach ($lists as $list)
                <h4 class="mt-3">{{ $no++ }}. {{ strtoupper($list->nama) }} (Bobot:
                    {{ $list->bobot }}%)</h4>
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>KPI</th>
                                <th>Kriteria Penilaian</th>
                                <th>Bobot</th>
                                <th>Nilai</th>
                                <th>Bobot Tercapai</th>
                            </tr>
                        </thead>
                        <tbody>
                            @php
                                $sum = [
                                    'bobot' => 0,
                                    'nilai' => 0,
                                    'bobot_tercapai' => 0,
                                ];
                            @endphp
                            @foreach ($list->lists as $item)
                                @php
                                    if ($item->pegawai) {
                                        $sum['bobot'] += $item->bobot;
                                        $sum['nilai'] += $item->pegawai->nilai;
                                        $sum['bobot_tercapai'] += $item->pegawai->bobot;
                                    }
                                @endphp
                                <tr>
                                    <td>{{ $loop->iteration }}</td>
                                    <td>{{ $item->teks }}</td>
                                    <td>
                                        <ol>
                                            @foreach ($item->kriteria as $kriteria)
                                                <li>{{ $kriteria }}</li>
                                            @endforeach
                                        </ol>
                                    </td>
                                    <td>{{ $item->bobot }}%</td>
                                    <td>{{ $item->pegawai->nilai ?? 0 }}</td>
                                    <td>{{ $item->pegawai->bobot ?? 0 }}%</td>
                                </tr>
                            @endforeach
                        </tbody>
                        <tfoot>
                            <tr>
                                <th colspan="3" class="text-right">Total</th>
                                <th>{{ $sum['bobot'] }}%</th>
                                <th>{{ $sum['nilai'] }}</th>
                                <th>{{ $sum['bobot_tercapai'] }}%</th>
                            </tr>
                        </tfoot>
                        @php
                            $totalBobot += $sum['bobot_tercapai'];
                        @endphp
                    </table>
                </div>
            @endforeach
            <h4 class="mt-3">{{ $no++ }}. SUMMARY OF PERFORMANCE APPRAISAL REVIEW</h4>
            <div class="table-responsive">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Aspek Penilaian</th>
                            <th>Bobot</th>
                            <th>Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($lists as $item)
                            <tr>
                                <td>{{ $loop->iteration }}</td>
                                <td>{{ $item->nama }}</td>
                                <td>{{ $item->bobot }}%</td>
                                <td>{{ $totalBobot }}%</td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
            <h4 class="mt-3">{{ $no++ }}. REKOMENDASI PERBAIKAN</h4>
            @if ($kpiPegawai->prb)
                <p>{{ $kpiPegawai->prb->keterangan }}: {{ $kpiPegawai->perbaikan ?? '-' }}</p>
            @else
                <p>-</p>
            @endif
            <h4 class="mt-3">{{ $no++ }}. REKOMENDASI AKHIR</h4>
            @if ($kpiPegawai->akhir)
                <p>{{ $kpiPegawai->akhir->keterangan }}: {{ $kpiPegawai->rekomendasi_akhir ?? '-' }}</p>
            @else
                <p>-</p>
            @endif
            <h4 class="mt-3">{{ $no++ }}. PENGESAHAN</h4>
            <div class="table-responsive">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama</th>
                            <th>Jabatan</th>
                            <th>TTD</th>
                            <th>Tanggal</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($kpi->pengesahan as $item)
                            <tr>
                                <td>{{ $loop->iteration }}</td>
                                <td>{{ $item->nama }}</td>
                                <td>{{ $item->jabatan }}</td>
                                <td>
                                    @if ($item->ttd)
                                        <img src="{{ route('file.index', ['path' => $item->ttd]) }}" alt="ttd"
                                            width="100">
                                    @else
                                        <span class="badge badge-danger">Belum diisi</span>
                                    @endif
                                </td>
                                <td>
                                    @if ($item->tanggal)
                                        {{ $item->tanggal->isoFormat('D MMMM YYYY') }}
                                    @else
                                        <span class="badge badge-danger">Belum diisi</span>
                                    @endif
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
@endsection
