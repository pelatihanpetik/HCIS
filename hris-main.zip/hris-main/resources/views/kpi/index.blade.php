<x-layouts.base>
    <x-slot:title>
        <h3>Daftar KPI</h3>
    </x-slot>
    <x-slot:subtitle>
        <a class="btn btn-sm bg-white btn-icon-text border" href="{{ route('kpi.create') }}">
            <i class="typcn typcn-plus"></i>
            Tambah data
        </a>
    </x-slot>

    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama</th>
                            <th>Jabatan</th>
                            <th>Divisi</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($kpi as $item)
                            <tr>
                                <td>
                                    {{ $kpi->firstItem() + $loop->index }}
                                </td>
                                <td>{{ $item->nama }}</td>
                                <td>{{ $item->jabatan }}</td>
                                <td>{{ $item->divisi }}</td>
                                <td>
                                    @if ($item->is_active == 1)
                                        <span class="badge badge-success">Aktif</span>
                                    @else
                                        <span class="badge badge-danger">Tidak aktif</span>
                                    @endif
                                </td>
                                <td>
                                    <a href="{{ route('kpi.edit', $item->id) }}" class="btn btn-sm btn-success">Edit</a>
                                    <button class="btn btn-sm btn-danger btn-delete"
                                        data-url="{{ route('kpi.destroy', $item->id) }}">Hapus</button>
                                    <a href="{{ route('kpi.show', $item->id) }}"
                                        class="btn btn-sm btn-secondary">Detail</a>
                                    <button class="btn btn-sm btn-info btn-duplicate"
                                        data-url="{{ route('kpi.duplicate', $item->id) }}">Duplikat</button>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>

            <div class="d-flex justify-content-end">
                {{ $kpi->links() }}
            </div>
        </div>
    </div>

    <div class="modal fade" id="modalDuplicate" tabindex="-1" aria-labelledby="modalDuplicateLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalDuplicateLabel">Apakah kamu yakin ?</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    Data akan diduplikasi, termasuk semua data yang terkait.
                </div>
                <div class="modal-footer">
                    <form action="#" method="post">
                        @csrf
                        <button class="btn btn-danger">Hapus</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    @push('js')
        <script>
            $(document).ready(function() {
                $('.btn-duplicate').on('click', function() {
                    const form = $('#modalDuplicate form');
                    form.attr('action', $(this).data('url'));
                    $('#modalDuplicate').modal('show');
                });
            });
        </script>
    @endpush
</x-layouts.base>
