@extends('kpi.layout')

@section('content')
    <form action="{{ route('kpi.rekomendasi.update', [$kpi->id, $kpiPegawai->pegawai_id]) }}" method="post">
        @csrf
        @method('PUT')
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label for="perbaikan">Rekomendasi Perbaikan</label>
                    <select name="perbaikan_id" class="form-control @error('perbaikan_id') is-invalid @enderror">
                        <option value="" hidden>Pilih jenis perbaikan</option>
                        @foreach ($rekomendasi->where('jenis', 'perbaikan') as $item)
                            <option value="{{ $item->id }}" @selected($item->id == old('perbaikan_id', $kpiPegawai->perbaikan_id))>
                                {{ $item->keterangan }}
                            </option>
                        @endforeach
                    </select>
                    @error('perbaikan_id')
                        <div class="invalid-feedback">
                            {{ $message }}
                        </div>
                    @enderror
                </div>
                <div class="form-group">
                    <label for="perbaikan">Keterangan</label>
                    <textarea class="form-control form-control-sm @error('perbaikan') is-invalid @enderror" name="perbaikan" required
                        autocomplete="off">{{ old('perbaikan', $kpiPegawai->perbaikan) }}</textarea>
                    @error('perbaikan')
                        <div class="invalid-feedback">
                            {{ $message }}
                        </div>
                    @enderror
                </div>
                <div class="form-group">
                    <label for="perbaikan">Rekomendasi Akhir</label>
                    <select name="rekomendasi_akhir_id"
                        class="form-control @error('rekomendasi_akhir_id') is-invalid @enderror">
                        <option value="" hidden>Pilih jenis perbaikan</option>
                        @foreach ($rekomendasi->where('jenis', 'akhir') as $item)
                            <option value="{{ $item->id }}" @selected($item->id == old('rekomendasi_akhir_id', $kpiPegawai->rekomendasi_akhir_id))>
                                {{ $item->keterangan }}
                            </option>
                        @endforeach
                    </select>
                    @error('rekomendasi_akhir_id')
                        <div class="invalid-feedback">
                            {{ $message }}
                        </div>
                    @enderror
                </div>
                <div class="form-group">
                    <label for="rekomendasi_akhir">Keterangan</label>
                    <textarea class="form-control form-control-sm @error('rekomendasi_akhir') is-invalid @enderror" name="rekomendasi_akhir"
                        required autocomplete="off">{{ old('rekomendasi_akhir', $kpiPegawai->rekomendasi_akhir) }}</textarea>
                    @error('rekomendasi_akhir')
                        <div class="invalid-feedback">
                            {{ $message }}
                        </div>
                    @enderror
                </div>
            </div>
        </div>
        <button class="btn btn-primary">Simpan</button>
    </form>
@endsection
