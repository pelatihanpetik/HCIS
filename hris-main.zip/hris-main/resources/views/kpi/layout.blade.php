<x-layouts.base>
    <x-slot:title>
        <h3 class="mb-0 font-weight-bold">{{ $kpi->nama }}</h3>
        <p>{{ $kpi->jabatan }} {{ $kpi->divisi ? '- Divisi ' . $kpi->divisi : '' }}</p>
    </x-slot>
    <x-slot:subtitle>
        <a class="btn btn-sm bg-white btn-icon-text border"
            href="{{ Auth::user()->isAdmin() ? route('kpi.index') : route('kpi-pegawai.index') }}">
            <i class="typcn typcn-chevron-left"></i>
            Kembali
        </a>
    </x-slot>

    <div class="card">
        <ul class="nav nav-tabs flex-nowrap" style="overflow-x: auto; overflow-y: hidden;">
            <li class="nav-item">
                <a class="nav-link @if ($tab == 'preview') active @endif"
                    href="{{ route('kpi.show', $kpi->id) }}">Preview</a>
            </li>
            <li class="nav-item">
                <a class="nav-link @if ($tab == 'list') active @endif"
                    href="{{ route('kpi.list.index', $kpi->id) }}">List</a>
            </li>
            <li class="nav-item">
                <a class="nav-link @if ($tab == 'pengesahan') active @endif"
                    href="{{ route('kpi.pengesahan.index', $kpi->id) }}">Pengesahan</a>
            </li>
        </ul>
        <div class="card-body">
            @yield('content')
        </div>
    </div>
</x-layouts.base>
