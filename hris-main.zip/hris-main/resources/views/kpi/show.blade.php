@extends('kpi.layout')

@section('content')
    <button class="btn btn-sm mt-n3 mb-3 btn-primary btn-icon-text border" data-toggle="modal" data-target="#modalPegawai"
        type="button">
        <i class="typcn typcn-plus"></i>
        Tambah data
    </button>
    <h3>{{ $kpi->nama }}</h3>
    <h5>{{ $kpi->jabatan }}</h5>
    <h5>Divisi: {{ $kpi->divisi }}</h5>
    <div class="table-responsive">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama</th>
                    <th>Bobot</th>
                    <th>Rekomendasi Perbaikan</th>
                    <th>Rekomendasi Akhir</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($kpi->details as $item)
                    <tr>
                        <td>{{ $loop->iteration }}</td>
                        <td>{{ $item->pegawai->nama }}</td>
                        <td>
                            {{ $item->lists->sum('bobot') }}%
                        </td>
                        @if ($item->prb)
                            <td>{{ $item->prb->keterangan }}: {{ $item->perbaikan }}</td>
                            <td>{{ $item->akhir->keterangan }}: {{ $item->rekomendasi_akhir }}</td>
                        @else
                            <td>-</td>
                            <td>-</td>
                        @endif
                        <td>
                            @if ($item->lists->count() == 0)
                                <span class="badge badge-danger">Belum diisi</span>
                            @else
                                <a href="{{ route('kpi.detail', [$kpi->id, $item->pegawai_id]) }}"
                                    class="btn btn-primary btn-sm">Detail</a>
                                <a href="{{ route('kpi.rekomendasi.index', [$kpi->id, $item->pegawai_id]) }}"
                                    class="btn btn-success btn-sm">Edit rekomendasi</a>
                                <a href="{{ route('kpi.ttd.index', [$kpi->id, $item->pegawai_id]) }}"
                                    class="btn btn-secondary btn-sm">Pengesahan</a>
                            @endif
                            <button class="btn btn-sm btn-danger btn-delete"
                                data-url="{{ route('kpi.delete-pegawai', [$kpi->id, $item->pegawai_id]) }}">Hapus</button>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>

    <div class="modal fade" id="modalPegawai" tabindex="-1" aria-labelledby="modalPegawaiLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="modalPegawaiLabel">Tambah Data</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form action="{{ route('kpi.add-pegawai', $kpi->id) }}" method="post">
                    <div class="modal-body">
                        @csrf
                        <input type="hidden" name="_method">
                        <div class="form-group">
                            <label>Nama Pegawai</label>
                            <select name="pegawai" class="form-control @error('pegawai') is-invalid @enderror">
                                <option value="" hidden>Pilih pegawai</option>
                                @foreach ($pegawai as $item)
                                    <option value="{{ $item->id }}" @selected($item->id == old('pegawai'))>{{ $item->nama }}
                                    </option>
                                @endforeach
                            </select>
                            @error('pegawai')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-secondary btn-sm">Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection
