@extends('pegawai.layout')

@section('content')
    <form action="{{ route('alamat.update', [$pegawai->id, $alamat->id]) }}" method="post">
        @csrf
        @method('PUT')
        <div class="row">
            <div class="form-group col-md-6">
                <label>Label</label>
                <input class="form-control form-control-sm @error('label') is-invalid @enderror" name="label"
                    value="{{ old('label', $alamat->label) }}" required autofocus autocomplete="off"
                    placeholder="Rumah/Kantor/dll">
                @error('label')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror
            </div>
            <div class="form-group col-md-6">
                <label>Provinsi</label>
                <select name="provinsi" class="form-control @error('provinsi') is-invalid @enderror">
                    <option value="" hidden>Pilih provinsi</option>
                    @foreach ($provinsi as $item)
                        <option value="{{ $item->nama }}" @selected($item->nama == old('provinsi', $alamat->provinsi))>{{ $item->nama }}</option>
                    @endforeach
                </select>
                @error('provinsi')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror
            </div>
            <div class="form-group col-md-6">
                <label>Kota/Kabupaten</label>
                <select name="kab_kota" class="form-control @error('kab_kota') is-invalid @enderror">
                    <option value="" hidden>Pilih Kota/Kabupaten</option>
                    @if (old('kab_kota', $alamat->kab_kota))
                        <option value="{{ old('kab_kota', $alamat->kab_kota) }}" selected>
                            {{ old('kab_kota', $alamat->kab_kota) }}</option>
                    @endif
                </select>
                @error('kab_kota')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror
            </div>
            <div class="form-group col-md-6">
                <label>Kecamatan</label>
                <select name="kecamatan" class="form-control @error('kecamatan') is-invalid @enderror">
                    <option value="" hidden>Pilih Kecamatan</option>
                    @if (old('kecamatan', $alamat->kecamatan))
                        <option value="{{ old('kecamatan', $alamat->kecamatan) }}" selected>
                            {{ old('kecamatan', $alamat->kecamatan) }}</option>
                    @endif
                </select>
                @error('kecamatan')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror
            </div>
            <div class="form-group col-md-6">
                <label>Kelurahan/Desa</label>
                <select name="kel_desa" class="form-control @error('kel_desa') is-invalid @enderror">
                    <option value="" hidden>Pilih Kelurahan/Desa</option>
                    @if (old('kel_desa', $alamat->kel_desa))
                        <option value="{{ old('kel_desa', $alamat->kel_desa) }}" selected>
                            {{ old('kel_desa', $alamat->kel_desa) }}</option>
                    @endif
                </select>
                @error('kel_desa')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror
            </div>
            <div class="form-group col-md-6">
                <label>RT/RW</label>
                <input class="form-control form-control-sm @error('rt_rw') is-invalid @enderror" name="rt_rw"
                    value="{{ old('rt_rw', $alamat->rt_rw) }}" autocomplete="off">
                @error('rt_rw')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror
            </div>
            <div class="form-group col-md-6">
                <label>Kode Pos</label>
                <input class="form-control form-control-sm @error('kode_pos') is-invalid @enderror" name="kode_pos"
                    value="{{ old('kode_pos', $alamat->kode_pos) }}" autocomplete="off">
                @error('kode_pos')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror
            </div>
            <div class="form-group col-md-6">
                <label>Faks</label>
                <input class="form-control form-control-sm @error('faks') is-invalid @enderror" name="faks"
                    value="{{ old('faks', $alamat->faks) }}" autocomplete="off">
                @error('faks')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror
            </div>
            <div class="form-group col-md-12">
                <label>Jalan</label>
                <textarea name="jalan" cols="5" class="form-control form-control-sm @error('jalan') is-invalid @enderror">{{ old('jalan', $alamat->jalan) }}</textarea>
                @error('jalan')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror
            </div>
        </div>
        <button class="btn btn-primary">Simpan</button>
    </form>
@endsection

@include('alamat.js-alamat')
