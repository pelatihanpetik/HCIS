@push('js')
    <script>
        $('select[name="provinsi"]').on('change', async function() {
            const kota = await fetch(`/api/kota?provinsi=${$(this).val()}`).then(res => res.json());
            $('select[name="kab_kota"]').html(
                '<option value="">-- Pilih Kota/Kabupaten --</option>');
            $('select[name="kecamatan"]').html(
                '<option value="">-- Pilih Kecamatan --</option>');
            $('select[name="kel_desa"]').html(
                '<option value="">-- Pilih Kelurahan/Desa --</option>');
            kota.data.forEach(item => {
                $('select[name="kab_kota"]').append(
                    `<option value="${item.nama}">${item.nama}</option>`
                );
            });
        });
        $('select[name="kab_kota"]').on('change', async function() {
            const kec = await fetch(`/api/kecamatan?kota=${$(this).val()}`).then(res => res.json());
            $('select[name="kecamatan"]').html(
                '<option value="">-- Pilih Kecamatan --</option>');
            $('select[name="kel_desa"]').html(
                '<option value="">-- Pilih Kelurahan/Desa --</option>');
            kec.data.forEach(item => {
                $('select[name="kecamatan"]').append(
                    `<option value="${item.nama}">${item.nama}</option>`
                );
            });
        });
        $('select[name="kecamatan"]').on('change', async function() {
            const kec = await fetch(`/api/desa?kecamatan=${$(this).val()}`).then(res => res.json());
            $('select[name="kel_desa"]').html(
                '<option value="">-- Pilih Kelurahan/Desa --</option>');
            kec.data.forEach(item => {
                $('select[name="kel_desa"]').append(
                    `<option value="${item.nama}">${item.nama}</option>`
                );
            });
        });
    </script>
@endpush
