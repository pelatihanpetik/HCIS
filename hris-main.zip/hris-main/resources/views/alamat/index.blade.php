@extends('pegawai.layout')

@section('content')
    <a class="btn btn-primary btn-sm mt-n3 mb-3" href="{{ route('alamat.create', $pegawai->id) }}">
        Tambah data
    </a>

    <div class="table-responsive">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Label</th>
                    <th>Provinsi</th>
                    <th>Kota/Kabupaten</th>
                    <th>Kecamatan</th>
                    <th>Kelurahan/Desa</th>
                    <th>RT/RW</th>
                    <th>Kode Pos</th>
                    <th>Faks</th>
                    <th>Jalan</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($pegawai->alamat as $i => $item)
                    <tr>
                        <td>
                            {{ $i + 1 }}
                        </td>
                        <td>{{ $item->label }}</td>
                        <td>{{ $item->provinsi }}</td>
                        <td>{{ $item->kab_kota }}</td>
                        <td>{{ $item->kecamatan }}</td>
                        <td>{{ $item->kel_desa }}</td>
                        <td>{{ $item->rt_rw }}</td>
                        <td>{{ $item->kode_pos }}</td>
                        <td>{{ $item->faks }}</td>
                        <td>{{ $item->jalan }}</td>
                        <td>
                            <a href="{{ route('alamat.edit', [$pegawai->id, $item->id]) }}"
                                class="btn btn-sm btn-success">Edit</a>
                            <button class="btn btn-sm btn-danger btn-delete"
                                data-url="{{ route('alamat.destroy', [$pegawai->id, $item->id]) }}">Hapus</button>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
@endsection
