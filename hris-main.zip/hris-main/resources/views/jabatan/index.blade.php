<x-layouts.base>
    <x-slot:title>
        <h3>Daftar Jabatan</h3>
    </x-slot>
    <x-slot:subtitle>
        <a class="btn btn-sm bg-white btn-icon-text border" href="{{ route('jabatan.create') }}">
            <i class="typcn typcn-plus"></i>
            Tambah data
        </a>
    </x-slot>

    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Level</th>
                            <th>Nama</th>
                            <th>Divisi</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($jabatan as $i => $item)
                            <tr>
                                <td>
                                    {{ $i + 1 }}
                                </td>
                                <td>{{ $item->jenis->nama }}</td>
                                <td>{{ $item->nama }}</td>
                                <td>{{ $item->divisi->nama ?? '-' }}</td>
                                <td>
                                    <a href="{{ route('jabatan.edit', $item->id) }}"
                                        class="btn btn-sm btn-success">Edit</a>
                                    <button class="btn btn-sm btn-danger btn-delete"
                                        data-url="{{ route('jabatan.destroy', $item->id) }}">Hapus</button>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</x-layouts.base>
