<x-layouts.base>
    <x-slot:title>
        <h3>Edit Jabatan</h3>
    </x-slot>
    <x-slot:subtitle>
        <a class="btn btn-sm bg-white btn-icon-text border" href="{{ route('jabatan.index') }}">
            <i class="typcn typcn-chevron-left"></i>
            Kembali
        </a>
    </x-slot>

    <div class="card">
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <form action="{{ route('jabatan.update', $jabatan->id) }}" method="post">
                        @csrf
                        @method('put')
                        @if ($jabatan->level > 1)
                            <div class="form-group">
                                <label>Divisi</label>
                                <select name="divisi" class="form-control @error('divisi') is-invalid @enderror">
                                    <option value="" hidden>Pilih divisi jabatan</option>
                                    @foreach ($divisi as $item)
                                        <option value="{{ $item->id }}" @selected($item->id == old('divisi', $jabatan->divisi_id))>
                                            {{ $item->nama }}
                                        </option>
                                    @endforeach
                                </select>
                                @error('divisi')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                @enderror
                            </div>
                        @endif
                        <div class="form-group">
                            <label>Nama jabatan</label>
                            <input class="form-control form-control-sm @error('nama') is-invalid @enderror"
                                name="nama" value="{{ old('nama', $jabatan->nama) }}" required autocomplete="off">
                            @error('nama')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <button class="btn btn-primary">Simpan</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</x-layouts.base>
