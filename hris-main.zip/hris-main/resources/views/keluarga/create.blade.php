@extends('pegawai.layout')

@section('content')
    <form action="{{ route('keluarga.store', $pegawai->id) }}" method="post" enctype="multipart/form-data">
        @csrf
        <div class="row">
            <div class="col-md-6 form-group">
                <label for="nik">NIK</label>
                <input class="form-control form-control-sm @error('nik') is-invalid @enderror" name="nik"
                    value="{{ old('nik') }}" autofocus autocomplete="off" inputmode="numeric">
                @error('nik')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror
            </div>
            <div class="form-group col-md-6">
                <label for="nama">Nama</label>
                <input class="form-control form-control-sm @error('nama') is-invalid @enderror" name="nama"
                    value="{{ old('nama') }}" required autocomplete="off">
                @error('nama')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror
            </div>
            <div class="col-md-6 form-group">
                <label for="tempat_lahir">Tempat Lahir</label>
                <input class="form-control form-control-sm @error('tempat_lahir') is-invalid @enderror" name="tempat_lahir"
                    value="{{ old('tempat_lahir') }}">
                @error('tempat_lahir')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror
            </div>
            <div class="col-md-6 form-group">
                <label for="tanggal_lahir">Tanggal Lahir</label>
                <input class="form-control form-control-sm @error('tanggal_lahir') is-invalid @enderror"
                    name="tanggal_lahir" value="{{ old('tanggal_lahir') }}" autocomplete="off" type="date">
                @error('tanggal_lahir')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label for="agama">Agama</label>
                    <select name="agama" class="form-control">
                        <option value="" hidden>Pilih Agama</option>
                        @foreach ($agama as $item)
                            <option value="{{ $item }}" @selected(old('agama') == $item)>
                                {{ $item }}</option>
                        @endforeach
                    </select>
                    @error('agama')
                        <div class="invalid-feedback">
                            {{ $message }}
                        </div>
                    @enderror
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label for="status">Status</label>
                    <select name="status" class="form-control">
                        <option value="" hidden>Pilih Status</option>
                        @foreach ($status as $item)
                            <option value="{{ $item }}" @selected(old('status') == $item)>
                                {{ $item }}</option>
                        @endforeach
                    </select>
                    @error('status')
                        <div class="invalid-feedback">
                            {{ $message }}
                        </div>
                    @enderror
                </div>
            </div>
            <div class="form-group col-md-6">
                <label for="jenis_kelamin">Jenis Kelamin</label>
                <div class="form-check @error('jenis_kelamin') is-invalid @enderror">
                    <label class="form-check-label">
                        <input type="radio" class="form-check-input" name="jenis_kelamin" value="L"
                            @checked(old('jenis_kelamin', 'L') == 'L')>
                        Laki - Laki
                        <i class="input-helper"></i>
                    </label>
                </div>
                <div class="form-check @error('jenis_kelamin') is-invalid @enderror">
                    <label class="form-check-label">
                        <input type="radio" class="form-check-input" name="jenis_kelamin" value="P"
                            @checked(old('jenis_kelamin', 'L') == 'P')>
                        Perempuan
                        <i class="input-helper"></i>
                    </label>
                </div>
                @error('jenis_kelamin')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror
            </div>
        </div>
        <button class="btn btn-primary">Simpan</button>
    </form>
@endsection
