@extends('pegawai.layout')

@section('content')
    <a class="btn btn-primary btn-sm mt-n3 mb-3" href="{{ route('keluarga.create', $pegawai->id) }}">
        Tambah data
    </a>

    <div class="table-responsive">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>No</th>
                    <th>NIK</th>
                    <th>Nama</th>
                    <th>Jenis Kelamin</th>
                    <th>Tempat Lahir</th>
                    <th>Tanggal Lahir</th>
                    <th>Agama</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($pegawai->keluarga as $i => $item)
                    <tr>
                        <td>{{ $i + 1 }}</td>
                        <td>{{ $item->nik }}</td>
                        <td>{{ $item->nama }}</td>
                        <td>{{ $item->jenis_kelamin }}</td>
                        <td>{{ $item->tempat_lahir }}</td>
                        <td>{{ $item->tanggal_lahir->isoFormat('DD MMMM YYYY') }}</td>
                        <td>{{ $item->agama }}</td>
                        <td>{{ $item->status }}</td>
                        <td>
                            <a href="{{ route('keluarga.edit', [$pegawai->id, $item->id]) }}"
                                class="btn btn-sm btn-success">Edit</a>
                            <button class="btn btn-sm btn-danger btn-delete"
                                data-url="{{ route('keluarga.destroy', [$pegawai->id, $item->id]) }}">Hapus</button>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
@endsection
