<x-layouts.base>
    <x-slot:title>
        <h3>Tambah Pegawai</h3>
    </x-slot>
    <x-slot:subtitle>
        <a class="btn btn-sm bg-white btn-icon-text border" href="{{ route('pegawai.index') }}">
            <i class="typcn typcn-chevron-left"></i>
            Kembali
        </a>
    </x-slot>

    <div class="card">
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <form action="{{ route('pegawai.store') }}" method="post">
                        @csrf
                        <div class="form-group">
                            <label for="nama">Nama</label>
                            <input class="form-control @error('nama') is-invalid @enderror" name="nama"
                                value="{{ old('nama') }}" required autofocus autocomplete="off">
                            @error('nama')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" class="form-control @error('email') is-invalid @enderror"
                                id="email" placeholder="Email..." name="email" value="{{ old('email') }}"
                                required autocomplete="off">
                            @error('email')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="password">Password</label>
                            <input type="password"
                                class="form-control @if ($errors->updatePassword->get('password')) is-invalid @endif" id="password"
                                name="password" required>
                            @error('password')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="jk">Jenis Kelamin</label>
                            <div class="form-check @error('jk') is-invalid @enderror">
                                <label class="form-check-label">
                                    <input type="radio" class="form-check-input" name="jk" value="L"
                                        @checked(old('jk', 'L') == 'L')>
                                    Laki - Laki
                                    <i class="input-helper"></i>
                                </label>
                            </div>
                            <div class="form-check @error('jk') is-invalid @enderror">
                                <label class="form-check-label">
                                    <input type="radio" class="form-check-input" name="jk" value="P"
                                        @checked(old('jk', 'L') == 'P')>
                                    Perempuan
                                    <i class="input-helper"></i>
                                </label>
                            </div>
                            @error('jk')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <button class="btn btn-primary">Simpan</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</x-layouts.base>
