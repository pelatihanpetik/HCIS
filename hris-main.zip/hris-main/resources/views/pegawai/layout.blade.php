<x-layouts.base>
    <x-slot:title>
        <h3>{{ $pegawai->nama }}</h3>
    </x-slot>
    @if (Auth::user()->isAdmin())
        <x-slot:subtitle>
            <a class="btn btn-sm bg-white btn-icon-text border" href="{{ route('pegawai.index') }}">
                <i class="typcn typcn-chevron-left"></i>
                Kembali
            </a>
        </x-slot>
    @endif

    <div class="card">
        <ul class="nav nav-tabs flex-nowrap" style="overflow-x: auto; overflow-y: hidden;">
            <li class="nav-item">
                <a class="nav-link @if ($tab == 'biodata') active @endif"
                    href="{{ route('pegawai.show', $pegawai->id) }}">Biodata</a>
            </li>
            <li class="nav-item">
                <a class="nav-link @if ($tab == 'alamat') active @endif"
                    href="{{ route('alamat.index', $pegawai->id) }}">Alamat</a>
            </li>
            <li class="nav-item">
                <a class="nav-link @if ($tab == 'berkas') active @endif"
                    href="{{ route('berkas.index', $pegawai->id) }}">Berkas</a>
            </li>
            <li class="nav-item">
                <a class="nav-link @if ($tab == 'kontrak') active @endif"
                    href="{{ route('kontrak.index', $pegawai->id) }}">Kontrak</a>
            </li>
            <li class="nav-item">
                <a class="nav-link @if ($tab == 'keluarga') active @endif"
                    href="{{ route('keluarga.index', $pegawai->id) }}">Keluarga</a>
            </li>
            <li class="nav-item">
                <a class="nav-link @if ($tab == 'pendidikan') active @endif"
                    href="{{ route('pendidikan.index', $pegawai->id) }}">Pendidikan</a>
            </li>
            <li class="nav-item">
                <a class="nav-link @if ($tab == 'pelatihan') active @endif"
                    href="{{ route('pelatihan.index', $pegawai->id) }}">Pelatihan</a>
            </li>
        </ul>
        <div class="card-body">
            @yield('content')
        </div>
    </div>
</x-layouts.base>
