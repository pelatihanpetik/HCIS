<x-layouts.base>
    <x-slot:title>
        <h3>Edit Pegawai</h3>
    </x-slot>
    <x-slot:subtitle>
        <a class="btn btn-sm bg-white btn-icon-text border" href="{{ route('pegawai.show', $pegawai->id) }}">
            <i class="typcn typcn-chevron-left"></i>
            Kembali
        </a>
    </x-slot>

    <div class="card">
        <div class="card-body">
            <form action="{{ route('pegawai.update', $pegawai->id) }}" method="post">
                @csrf
                @method('put')
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="nama">Nama</label>
                            <input class="form-control @error('nama') is-invalid @enderror" name="nama"
                                value="{{ old('nama', $pegawai->nama) }}" required autocomplete="off">
                            @error('nama')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="jenis_kelamin">Jenis Kelamin</label>
                            <div class="form-check @error('jenis_kelamin') is-invalid @enderror">
                                <label class="form-check-label">
                                    <input type="radio" class="form-check-input" name="jenis_kelamin" value="L"
                                        @checked(old('jenis_kelamin', $pegawai->jenis_kelamin ?? 'L') == 'L')>
                                    Laki - Laki
                                    <i class="input-helper"></i>
                                </label>
                            </div>
                            <div class="form-check @error('jenis_kelamin') is-invalid @enderror">
                                <label class="form-check-label">
                                    <input type="radio" class="form-check-input" name="jenis_kelamin" value="P"
                                        @checked(old('jenis_kelamin', $pegawai->jenis_kelamin) == 'P')>
                                    Perempuan
                                    <i class="input-helper"></i>
                                </label>
                            </div>
                            @error('jenis_kelamin')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="tempat_lahir">Tempat Lahir</label>
                            <input class="form-control @error('tempat_lahir') is-invalid @enderror" name="tempat_lahir"
                                value="{{ old('tempat_lahir', $pegawai->tempat_lahir) }}">
                            @error('tempat_lahir')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="tanggal_lahir">Tanggal Lahir</label>
                            <input class="form-control @error('tanggal_lahir') is-invalid @enderror"
                                name="tanggal_lahir"
                                value="{{ old('tanggal_lahir', $pegawai->tanggal_lahir ? $pegawai->tanggal_lahir->format('Y-m-d') : '') }}"
                                autocomplete="off" type="date">
                            @error('tanggal_lahir')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="no_hp">No HP</label>
                            <input class="form-control @error('no_hp') is-invalid @enderror" name="no_hp"
                                value="{{ old('no_hp', $pegawai->no_hp) }}" autocomplete="off" inputmode="numeric">
                            @error('no_hp')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" class="form-control @error('email') is-invalid @enderror"
                                name="email" value="{{ old('email', $pegawai->user->email) }}" required
                                autocomplete="off">
                            @error('email')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="nik">NIK</label>
                            <input class="form-control @error('nik') is-invalid @enderror" name="nik"
                                value="{{ old('nik', $pegawai->nik) }}" autocomplete="off" inputmode="numeric">
                            @error('nik')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="nomor_kk">Nomor KK</label>
                            <input class="form-control @error('nomor_kk') is-invalid @enderror" name="nomor_kk"
                                value="{{ old('nomor_kk', $pegawai->nomor_kk) }}" autocomplete="off"
                                inputmode="numeric">
                            @error('nomor_kk')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="npwp">NPWP</label>
                            <input class="form-control @error('npwp') is-invalid @enderror" name="npwp"
                                value="{{ old('npwp', $pegawai->npwp) }}" autocomplete="off" inputmode="numeric">
                            @error('npwp')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="nomor_anggota_bpjs">Nomor Anggota BPJS</label>
                            <input class="form-control @error('nomor_anggota_bpjs') is-invalid @enderror"
                                name="nomor_anggota_bpjs"
                                value="{{ old('nomor_anggota_bpjs', $pegawai->nomor_anggota_bpjs) }}"
                                autocomplete="off" inputmode="numeric">
                            @error('nomor_anggota_bpjs')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="agama">Agama</label>
                            <select name="agama" class="form-control">
                                <option value="" hidden>Pilih Agama</option>
                                @foreach ($agama as $item)
                                    <option value="{{ $item }}" @selected(old('agama', $pegawai->agama) == $item)>
                                        {{ $item }}</option>
                                @endforeach
                            </select>
                            @error('agama')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="status_kawin">Status Kawin</label>
                            <select name="status_kawin" class="form-control">
                                <option value="" hidden>Pilih Status Kawin</option>
                                @foreach ($kawin as $key => $item)
                                    <option value="{{ $item }}" @selected(old('status_kawin', $pegawai->status_kawin) == $item)>
                                        {{ $item }}</option>
                                @endforeach
                            </select>
                            @error('status_kawin')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                    </div>
                </div>
                <button class="btn btn-primary">Simpan</button>
            </form>
        </div>
    </div>
</x-layouts.base>
