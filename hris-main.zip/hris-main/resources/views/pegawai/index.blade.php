<x-layouts.base>
    <x-slot:title>
        <h3>Daftar Pegawai</h3>
    </x-slot>
    <x-slot:subtitle>
        <a class="btn btn-sm bg-white btn-icon-text border" href="{{ route('pegawai.create') }}">
            <i class="typcn typcn-plus"></i>
            Tambah data
        </a>
    </x-slot>

    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>NIK</th>
                            <th>Nama</th>
                            <th>No. HP</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($pegawai as $item)
                            <tr>
                                <td>
                                    {{ $pegawai->firstItem() + $loop->index }}
                                </td>
                                <td>{{ $item->nik }}</td>
                                <td>{{ $item->nama }}</td>
                                <td>{{ $item->no_hp }}</td>
                                <td>
                                    <a href="{{ route('pegawai.edit', $item->id) }}"
                                        class="btn btn-sm btn-success">Edit</a>
                                    <button class="btn btn-sm btn-danger btn-delete"
                                        data-url="{{ route('pegawai.destroy', $item->id) }}">Hapus</button>
                                    <a href="{{ route('pegawai.show', $item->id) }}"
                                        class="btn btn-sm btn-secondary">Detail</a>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>

            <div class="d-flex justify-content-end">
                {{ $pegawai->links() }}
            </div>
        </div>
    </div>
</x-layouts.base>
