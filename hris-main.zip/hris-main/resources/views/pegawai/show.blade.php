@extends('pegawai.layout')

@section('content')
    <a href="{{ route('pegawai.edit', $pegawai->id) }}" class="btn btn-sm btn-success mt-n3 mb-3">
        Edit
    </a>
    <div class="row mb-3">
        <div class="col-lg-4 col-md-6 border-bottom mb-2">
            Nama
            <h4 class="font-weight-bold">{{ $pegawai->nama }}</h4>
        </div>
        <div class="col-lg-4 col-md-6 border-bottom mb-2">
            No HP
            <h4 class="font-weight-bold">{{ $pegawai->no_hp ?? '-' }}</h4>
        </div>
        <div class="col-lg-4 col-md-6 border-bottom mb-2">
            Email
            <h4 class="font-weight-bold">{{ $pegawai->user->email ?? '-' }}</h4>
        </div>
        <div class="col-lg-4 col-md-6 border-bottom mb-2">
            NIK
            <h4 class="font-weight-bold">{{ $pegawai->nik ?? '-' }}</h4>
        </div>
        <div class="col-lg-4 col-md-6 border-bottom mb-2">
            Nomor KK
            <h4 class="font-weight-bold">{{ $pegawai->nomor_kk ?? '-' }}</h4>
        </div>
        <div class="col-lg-4 col-md-6 border-bottom mb-2">
            Jenis Kelamin
            <h4 class="font-weight-bold">{{ $pegawai->jenis_kelamin ?? '-' }}</h4>
        </div>
        <div class="col-lg-4 col-md-6 border-bottom mb-2">
            Tempat Lahir
            <h4 class="font-weight-bold">{{ $pegawai->tempat_lahir ?? '-' }}</h4>
        </div>
        <div class="col-lg-4 col-md-6 border-bottom mb-2">
            Tanggal Lahir
            <h4 class="font-weight-bold">
                {{ $pegawai->tanggal_lahir ? $pegawai->tanggal_lahir->isoFormat('DD MMMM YYYY') : '-' }}</h4>
        </div>
        <div class="col-lg-4 col-md-6 border-bottom mb-2">
            NPWP
            <h4 class="font-weight-bold">{{ $pegawai->npwp ?? '-' }}</h4>
        </div>
        <div class="col-lg-4 col-md-6 border-bottom mb-2">
            Agama
            <h4 class="font-weight-bold">{{ $pegawai->agama ?? '-' }}</h4>
        </div>
        <div class="col-lg-4 col-md-6 border-bottom mb-2">
            Nomor Anggota BPJS
            <h4 class="font-weight-bold">{{ $pegawai->nomor_anggota_bpjs ?? '-' }}</h4>
        </div>
        <div class="col-lg-4 col-md-6 border-bottom mb-2">
            Status Pernikahan
            <h4 class="font-weight-bold">{{ $pegawai->status_kawin ?? '-' }}</h4>
        </div>
    </div>

    <div class="row">
        <div class="col-md-6">
            @if ($pegawai->posisi->count() === 0)
                @if (Auth::user()->isAdmin())
                    <button id="btn-create" class="btn btn-sm btn-primary" data-toggle="modal" data-target="#jabatanModal"
                        type="button">
                        Atur jabatan
                    </button>
                @endif
            @else
                @foreach ($pegawai->posisi as $item)
                    @if (Auth::user()->isAdmin())
                        <button class="btn-edit btn btn-sm btn-success" data-toggle="modal" data-target="#jabatanModal"
                            type="button" data-url="{{ route('posisi.update', [$pegawai->id, $item->id]) }}"
                            data-id="{{ $item->id }}">
                            Ubah jabatan
                        </button>
                        <button class="btn btn-sm btn-danger btn-delete"
                            data-url="{{ route('posisi.destroy', [$pegawai->id, $item->id]) }}">Hapus</button>
                    @endif
                    <div class="mt-2">
                        Posisi Jabatan
                        <h4 class="font-weight-bold">
                            @if ($item->divisi_id)
                                Divisi {{ $item->divisi->nama }}:
                            @endif
                            {{ $item->nama }} ({{ $item->jenis->nama }})
                        </h4>
                    </div>
                @endforeach
            @endif

            @if (Auth::user()->isAdmin())
                <div class="modal fade" id="jabatanModal" tabindex="-1" aria-labelledby="modalJenisLabel"
                    aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h4 class="modal-title" id="modalJenisLabel">Divisi</h4>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <form action="{{ route('divisi.store') }}" method="post">
                                <div class="modal-body">
                                    @csrf
                                    <input type="hidden" name="_method">
                                    <div class="form-group">
                                        <label for="posisi">Posisi jabatan</label>
                                        <select name="posisi" class="form-control">
                                            <option value="" hidden>Pilih posisi</option>
                                            @foreach ($jabatan as $item)
                                                <option value="{{ $item->id }}" @selected(old('posisi') == $item->id)>
                                                    @if ($item->divisi_id)
                                                        Divisi {{ $item->divisi->nama }}:
                                                    @endif
                                                    {{ $item->nama }} ({{ $item->jenis->nama }})
                                                </option>
                                            @endforeach
                                        </select>
                                        @error('posisi')
                                            <div class="invalid-feedback">
                                                {{ $message }}
                                            </div>
                                        @enderror
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button class="btn btn-secondary btn-sm">Simpan</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            @endif
        </div>
    </div>

    @push('js')
        <script>
            $(document).on('click', '#btn-create', function() {
                $('#jabatanModal select[name="posisi"]').val('');
                $('#jabatanModal form').attr('action', "{{ route('posisi.store', $pegawai->id) }}");
                $('#jabatanModal input[name="_method"]').val('');
            });
            $(document).on('click', '.btn-edit', function() {
                $('#jabatanModal select[name="posisi"]').val($(this).data('id'));
                $('#jabatanModal form').attr('action', $(this).data('url'));
                $('#jabatanModal input[name="_method"]').val('PUT');
            });
        </script>
    @endpush
@endsection
