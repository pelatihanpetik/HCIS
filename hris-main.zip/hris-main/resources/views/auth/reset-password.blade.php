<x-guest-layout>
    <form method="POST" action="{{ route('password.store') }}">
        @csrf

        <!-- Password Reset Token -->
        <input type="hidden" name="token" value="{{ $request->route('token') }}">

        <!-- Email Address -->
        <div class="form-group">
            <label for="email">Email</label>
            <input type="email" class="form-control @error('email') is-invalid @enderror" id="email"
                placeholder="Email..." name="email" value="{{ old('email', $request->email) }}" required autofocus
                autocomplete="username">
            @if ($errors->get('email'))
                <div class="invalid-feedback">
                    @foreach ((array) $errors->get('email') as $message)
                        {{ $message }},
                    @endforeach
                </div>
            @endif
        </div>
        <div class="form-group">
            <label for="password">Password</label>
            <input type="password" class="form-control" id="password" name="password" required
                autocomplete="new-password">

            @if ($errors->get('password'))
                <div class="invalid-feedback">
                    @foreach ((array) $errors->get('password') as $message)
                        {{ $message }},
                    @endforeach
                </div>
            @endif
        </div>
        <div class="form-group">
            <label for="password_confirmation">Confirm Password</label>
            <input type="password" class="form-control" id="password_confirmation" name="password_confirmation" required
                autocomplete="new-password">

            @if ($errors->get('password_confirmation'))
                <div class="invalid-feedback">
                    @foreach ((array) $errors->get('password_confirmation') as $message)
                        {{ $message }},
                    @endforeach
                </div>
            @endif
        </div>

        <button class="btn btn-primary">
            {{ __('Reset Password') }}
        </button>
    </form>
</x-guest-layout>
