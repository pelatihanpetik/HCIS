<x-guest-layout>
    <p>
        {{ __('Forgot your password? No problem. Just let us know your email address and we will email you a password reset link that will allow you to choose a new one.') }}
    </p>
    <form method="POST" action="{{ route('password.email') }}">
        @csrf

        <!-- Email Address -->
        <div class="form-group">
            <label for="email">Email</label>
            <input type="email" class="form-control @error('email') is-invalid @enderror" id="email"
                placeholder="Email..." name="email" value="{{ old('email') }}" required autofocus
                autocomplete="username">
            @if ($errors->get('email'))
                <div class="invalid-feedback">
                    @foreach ((array) $errors->get('email') as $message)
                        {{ $message }},
                    @endforeach
                </div>
            @endif
        </div>

        <button class="btn btn-primary">
            {{ __('Email Password Reset Link') }}
        </button>
    </form>
</x-guest-layout>
