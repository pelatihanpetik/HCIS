<x-guest-layout>
    <!-- Session Status -->
    <h4>Hello! let's get started</h4>
    <h6 class="font-weight-light">Sign in to continue.</h6>
    <form method="POST" action="{{ route('login') }}">
        @csrf
        <div class="form-group">
            <label for="email">Email</label>
            <input type="email" class="form-control @error('email') is-invalid @enderror" id="email"
                placeholder="Email..." name="email" value="{{ old('email') }}" required autofocus
                autocomplete="username">
            @if ($errors->get('email'))
                <div class="invalid-feedback">
                    @foreach ((array) $errors->get('email') as $message)
                        {{ $message }},
                    @endforeach
                </div>
            @endif
        </div>
        <div class="form-group">
            <label for="password">Password</label>
            <input type="password" class="form-control" id="password" name="password" required
                autocomplete="current-password">

            @if ($errors->get('password'))
                <div class="invalid-feedback">
                    @foreach ((array) $errors->get('password') as $message)
                        {{ $message }},
                    @endforeach
                </div>
            @endif
        </div>
        <div class="mt-3">
            <button class="btn btn-block btn-primary font-weight-medium auth-form-btn">SIGN
                IN</button>
        </div>
        <div class="my-2 d-flex justify-content-between align-items-center">
            <div class="form-check form-check-flat form-check-primary">
                <label class="form-check-label">
                    <input type="checkbox" class="form-check-input" name="remember">
                    Keep me signed in
                    <i class="input-helper"></i></label>
            </div>
            @if (Route::has('password.request'))
                <a href="{{ route('password.request') }}" class="auth-link text-black">Forgot password?</a>
            @endif
        </div>
    </form>
</x-guest-layout>
