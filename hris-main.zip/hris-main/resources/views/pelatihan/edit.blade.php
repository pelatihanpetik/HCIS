@extends('pegawai.layout')

@section('content')
    <form action="{{ route('pelatihan.update', [$pegawai->id, $pelatihan->id]) }}" method="post"
        enctype="multipart/form-data">
        @csrf
        @method('PUT')
        <div class="row">
            <div class="form-group col-md-6">
                <label for="nama">Nama</label>
                <input class="form-control form-control-sm @error('nama') is-invalid @enderror" name="nama"
                    value="{{ old('nama', $pelatihan->nama) }}" required autofocus autocomplete="off">
                @error('nama')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror
            </div>
            <div class="form-group col-md-6">
                <label for="penyelenggara">Penyelenggara</label>
                <input class="form-control form-control-sm @error('penyelenggara') is-invalid @enderror"
                    name="penyelenggara" value="{{ old('penyelenggara', $pelatihan->penyelenggara) }}" required
                    autocomplete="off">
                @error('penyelenggara')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror
            </div>
            <div class="col-md-6 form-group">
                <label for="tanggal_mulai">Tanggal Mulai</label>
                <input class="form-control form-control-sm @error('tanggal_mulai') is-invalid @enderror"
                    name="tanggal_mulai" value="{{ old('tanggal_mulai', $pelatihan->tanggal_mulai->format('Y-m-d')) }}"
                    autocomplete="off" type="date">
                @error('tanggal_mulai')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror
            </div>
            <div class="col-md-6 form-group">
                <label for="tanggal_selesai">Tanggal Selesai</label>
                <input class="form-control form-control-sm @error('tanggal_selesai') is-invalid @enderror"
                    name="tanggal_selesai"
                    value="{{ old('tanggal_selesai', $pelatihan->tanggal_selesai ? $pelatihan->tanggal_selesai->format('Y-m-d') : '') }}"
                    autocomplete="off" type="date">
                @error('tanggal_selesai')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror
            </div>
            <div class="form-group col-md-6">
                <label for="sertifikat">Link Bukti</label>
                <input class="form-control form-control-sm @error('sertifikat') is-invalid @enderror" name="sertifikat"
                    value="{{ old('sertifikat', $pelatihan->sertifikat) }}" autocomplete="off">
                @error('sertifikat')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror
            </div>
        </div>
        <button class="btn btn-primary">Simpan</button>
    </form>
@endsection
