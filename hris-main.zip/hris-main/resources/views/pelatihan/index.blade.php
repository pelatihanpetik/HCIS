@extends('pegawai.layout')

@section('content')
    <a class="btn btn-primary btn-sm mt-n3 mb-3" href="{{ route('pelatihan.create', $pegawai->id) }}">
        Tambah data
    </a>

    <div class="table-responsive">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama</th>
                    <th>Penyelenggara</th>
                    <th>Tanggal Mulai</th>
                    <th>Tanggal Selesai</th>
                    <th>Link Bukti</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($pegawai->pelatihan as $i => $item)
                    <tr>
                        <td>{{ $i + 1 }}</td>
                        <td>{{ $item->nama }}</td>
                        <td>{{ $item->penyelenggara }}</td>
                        <td>{{ $item->tanggal_mulai->isoFormat('DD MMMM YYYY') }}</td>
                        <td>{{ $item->tanggal_selesai ? $item->tanggal_selesai->isoFormat('DD MMMM YYYY') : 'Sekarang' }}
                        <td>
                            @if ($item->sertifikat)
                                <a href="{{ $item->sertifikat }}" target="_blank">Lihat</a>
                            @else
                                -
                            @endif
                        </td>
                        </td>
                        <td>
                            <a href="{{ route('pelatihan.edit', [$pegawai->id, $item->id]) }}"
                                class="btn btn-sm btn-success">Edit</a>
                            <button class="btn btn-sm btn-danger btn-delete"
                                data-url="{{ route('pelatihan.destroy', [$pegawai->id, $item->id]) }}">Hapus</button>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
@endsection
