@extends('kpi.layout')

@section('content')
    <a class="btn btn-sm btn-primary mt-n3" href="{{ route('kpi.list.create', $kpi->id) }}">
        Tambah data
    </a>
    @foreach ($lists as $key => $list)
        <h4 class="mt-3">{{ $key }}</h4>
        <div class="table-responsive">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>KPI</th>
                        <th>Kriteria Penilaian</th>
                        <th>Bobot</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($list as $item)
                        <tr>
                            <td>{{ $loop->iteration }}</td>
                            <td>{{ $item->teks }}</td>
                            <td>
                                <ol>
                                    @foreach ($item->kriteria as $kriteria)
                                        <li>{{ $kriteria }}</li>
                                    @endforeach
                                </ol>
                            </td>
                            <td>{{ $item->bobot }}%</td>
                            <td>
                                <a href="{{ route('kpi.list.edit', [$kpi->id, $item->id]) }}"
                                    class="btn btn-sm btn-success">Edit</a>
                                <button class="btn btn-sm btn-danger btn-delete"
                                    data-url="{{ route('kpi.list.destroy', [$kpi->id, $item->id]) }}">Hapus</button>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    @endforeach
@endsection
