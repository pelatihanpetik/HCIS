@extends('kpi.layout')

@section('content')
    <div class="row">
        <div class="col-md-6">
            <form action="{{ route('kpi.list.update', [$kpi->id, $list->id]) }}" method="post">
                @csrf
                @method('put')
                <div class="form-group">
                    <label>Kategori</label>
                    <select name="group" class="form-control @error('group') is-invalid @enderror">
                        @foreach ($group as $item)
                            <option value="{{ $item->id }}" @selected($item->id == old('group', $list->kpi_group_id))>{{ $item->nama }}
                            </option>
                        @endforeach
                    </select>
                    @error('group')
                        <div class="invalid-feedback">
                            {{ $message }}
                        </div>
                    @enderror
                </div>
                <div class="form-group">
                    <label for="teks">KPI</label>
                    <textarea class="form-control form-control-sm @error('teks') is-invalid @enderror" name="teks" rows="3">{{ old('teks', $list->teks) }}</textarea>
                    @error('teks')
                        <div class="invalid-feedback">
                            {{ $message }}
                        </div>
                    @enderror
                </div>
                <div class="form-group">
                    <label for="bobot">Bobot</label>
                    <input class="form-control form-control-sm @error('bobot') is-invalid @enderror" name="bobot"
                        value="{{ old('bobot', $list->bobot) }}" required type="number" autocomplete="off">
                    @error('bobot')
                        <div class="invalid-feedback">
                            {{ $message }}
                        </div>
                    @enderror
                </div>
                <div class="form-group">
                    <label for="kriteria">Kriteria Penilaian</label>
                    @foreach ($list->kriteria as $key => $item)
                        @php
                            $value = old('kriteria') ? old('kriteria')[$key] : $item;
                        @endphp
                        <div class="d-flex mb-1 align-items-stretch">
                            <div style="background-color: #f0f0f0;width: 30px;"
                                class="d-flex justify-content-center align-items-center">
                                {{ $key }}
                            </div>
                            <input class="form-control form-control-sm" name="kriteria[]" value="{{ $value }}"
                                autocomplete="off">
                        </div>
                        @error('kriteria.' . $key)
                            <small class="text-danger">
                                Kriteria Penilaian {{ $key + 1 }} harus diisi
                            </small>
                        @enderror
                    @endforeach
                </div>
                <button class="btn btn-primary">Simpan</button>
            </form>
        </div>
    </div>
@endsection
