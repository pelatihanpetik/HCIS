@extends('kpi.layout')

@section('content')
    <div class="row">
        <div class="col-md-6">
            <form action="{{ route('kpi.list.store', $kpi->id) }}" method="post">
                @csrf
                <div class="form-group">
                    <label>Kategori</label>
                    <select name="group" class="form-control @error('group') is-invalid @enderror">
                        @foreach ($group as $item)
                            <option value="{{ $item->id }}" @selected($item->id == old('group'))>{{ $item->nama }}
                            </option>
                        @endforeach
                    </select>
                    @error('group')
                        <div class="invalid-feedback">
                            {{ $message }}
                        </div>
                    @enderror
                </div>
                <div class="form-group">
                    <label for="teks">KPI</label>
                    <textarea class="form-control form-control-sm @error('teks') is-invalid @enderror" name="teks" rows="3">{{ old('teks') }}</textarea>
                    @error('teks')
                        <div class="invalid-feedback">
                            {{ $message }}
                        </div>
                    @enderror
                </div>
                <div class="form-group">
                    <label for="bobot">Bobot</label>
                    <input class="form-control form-control-sm @error('bobot') is-invalid @enderror" name="bobot"
                        value="{{ old('bobot') }}" required type="number" autocomplete="off">
                    @error('bobot')
                        <div class="invalid-feedback">
                            {{ $message }}
                        </div>
                    @enderror
                </div>
                <div class="form-group">
                    <label for="kriteria">Kriteria Penilaian</label>
                    @foreach ($point as $item)
                        @php
                            $value = old('kriteria')[$loop->index] ?? '';
                        @endphp
                        <div class="d-flex mb-1 align-items-stretch">
                            <div style="background-color: #f0f0f0;width: 30px;"
                                class="d-flex justify-content-center align-items-center">
                                {{ $item }}
                            </div>
                            <input class="form-control form-control-sm" name="kriteria[]" value="{{ $value }}"
                                autocomplete="off">
                        </div>
                        @error('kriteria.' . $loop->index)
                            <small class="text-danger">
                                Kriteria Penilaian {{ $loop->index + 1 }} harus diisi
                            </small>
                        @enderror
                    @endforeach
                </div>
                <button class="btn btn-primary">Simpan</button>
            </form>
        </div>
    </div>
@endsection
