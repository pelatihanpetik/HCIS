<x-layouts.base>
    <x-slot:title>
        <h3>Setting Pengesahan KPI</h3>
    </x-slot>
    <x-slot:subtitle>
        <a class="btn btn-sm bg-white btn-icon-text border" href="{{ route('pengesahan.index') }}">
            <i class="typcn typcn-chevron-left"></i>
            Kembali
        </a>
    </x-slot>

    <div class="card">
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <form action="{{ route('pengesahan.update', $pengesahan->id) }}" method="post">
                        @csrf
                        @method('PUT')
                        <div class="form-group">
                            <label>Jenis Jabatan</label>
                            <select name="jenis" class="form-control @error('jenis') is-invalid @enderror">
                                <option value="" hidden>Pilih jenis jabatan</option>
                                @foreach ($jenis as $item)
                                    <option value="{{ $item->id }}" @selected($item->id == old('jenis', $pengesahan->jabatan_id))>
                                        {{ $item->nama }}
                                    </option>
                                @endforeach
                            </select>
                            @error('jenis')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="jabatan">Jabatan</label>
                            <input class="form-control form-control-sm @error('jabatan') is-invalid @enderror"
                                name="jabatan" value="{{ old('jabatan', $pengesahan->jabatan) }}" required
                                autocomplete="off">
                            @error('jabatan')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="nama">Nama</label>
                            <input class="form-control form-control-sm @error('nama') is-invalid @enderror"
                                name="nama" value="{{ old('nama', $pengesahan->nama) }}" required autocomplete="off">
                            @error('nama')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <button class="btn btn-primary">Simpan</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</x-layouts.base>
