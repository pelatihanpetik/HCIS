@extends('kpi.layout')

@section('content')
    <div class="row">
        <div class="col-md-6">
            <form action="{{ route('kpi.pengesahan.store', $kpi->id) }}" method="post">
                @csrf
                <div class="form-group">
                    <label>Jabatan</label>
                    <select name="jabatan" class="form-control @error('jabatan') is-invalid @enderror">
                        <option value="" hidden>Pilih jabatan</option>
                        @foreach ($jabatan as $item)
                            <option value="{{ $item->id }}" @selected($item->id == old('jabatan'))>
                                @if ($item->divisi_id)
                                    Divisi {{ $item->divisi->nama }}:
                                @endif
                                {{ $item->nama }} ({{ $item->jenis->nama }})
                            </option>
                        @endforeach
                    </select>
                    @error('jabatan')
                        <div class="invalid-feedback">
                            {{ $message }}
                        </div>
                    @enderror
                </div>
                <button class="btn btn-primary btn-sm">Simpan</button>
            </form>
        </div>
    </div>
@endsection
