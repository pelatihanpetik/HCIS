<x-layouts.base>
    <x-slot:title>
        <h3>Setting Pengesahan KPI</h3>
    </x-slot>
    <x-slot:subtitle>
        <button id="btn-create" class="btn btn-sm bg-white btn-icon-text border" data-toggle="modal"
            data-target="#modalJenis" type="button">
            <i class="typcn typcn-plus"></i>
            Tambah data
        </button>
    </x-slot>

    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Jabatan</th>
                            <th>Nama</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($pengesahan as $i => $item)
                            <tr>
                                <td>{{ $i + 1 }}</td>
                                <td>{{ $item->jabatan }}</td>
                                <td>{{ $item->nama }}</td>
                                <td>
                                    <a class="btn btn-sm btn-success btn-edit"
                                        href="{{ route('pengesahan.edit', $item->id) }}">
                                        Edit
                                    </a>
                                    <button class="btn btn-sm btn-danger btn-delete"
                                        data-url="{{ route('pengesahan.destroy', $item->id) }}">Hapus</button>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <!-- Modal -->
    <div class="modal fade" id="modalJenis" tabindex="-1" aria-labelledby="modalJenisLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="modalJenisLabel">Jenis Jabatan</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form action="{{ route('pengesahan.store') }}" method="post">
                    <div class="modal-body">
                        @csrf
                        <div class="form-group">
                            <label>Jenis Jabatan</label>
                            <select name="jenis" class="form-control @error('jenis') is-invalid @enderror">
                                <option value="" hidden>Pilih jenis jabatan</option>
                                @foreach ($jenis as $item)
                                    <option value="{{ $item->id }}" @selected($item->id == old('jenis'))>
                                        {{ $item->nama }}
                                    </option>
                                @endforeach
                            </select>
                            @error('jenis')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-secondary btn-sm">Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    @push('js')
        <script>
            $(document).on('click', '#btn-create', function() {
                $('#modalJenis select[name="jenis"]').val('');
                $('#modalJenis input[name="urutan"]').val('');
            });
            $(document).on('click', '.btn-edit', function() {
                $('#modalJenis select[name="jenis"]').val($(this).data('jenis'));
                $('#modalJenis input[name="urutan"]').val($(this).data('urutan'));
            });
        </script>
    @endpush
</x-layouts.base>
