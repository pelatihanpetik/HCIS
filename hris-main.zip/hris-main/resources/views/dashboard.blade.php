<x-layouts.base>
    <x-slot:title>
        <h3 class="mb-0 font-weight-bold">{{ __('Dashboard') }}</h3>
    </x-slot>
</x-layouts.base>
