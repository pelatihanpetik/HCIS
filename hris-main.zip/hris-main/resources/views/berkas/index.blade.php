@extends('pegawai.layout')

@section('content')
    <a class="btn btn-primary btn-sm mt-n3 mb-3" href="{{ route('berkas.create', $pegawai->id) }}">
        Tambah data
    </a>

    <div class="table-responsive">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Jenis Berkas</th>
                    <th>Nama</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($pegawai->berkas as $i => $item)
                    <tr>
                        <td>
                            {{ $i + 1 }}
                        </td>
                        <td>{{ $item->jenis }}</td>
                        <td>{{ $item->nama }}</td>
                        <td>
                            <a class="btn btn-sm btn-success" href="{{ route('berkas.edit', [$pegawai->id, $item->id]) }}">
                                Edit
                            </a>
                            <a href="{{ route('file.index', ['path' => $item->file]) }}" target="_blank"
                                class="btn btn-sm btn-secondary">Lihat</a>
                            <button class="btn btn-sm btn-danger btn-delete"
                                data-url="{{ route('berkas.destroy', [$pegawai->id, $item->id]) }}">Hapus</button>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>

    <div class="modal fade" id="modalBerkas" tabindex="-1" aria-labelledby="modalBerkasLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="modalBerkasLabel">Edit Berkas</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form action="" method="post" enctype="multipart/form-data">
                    <div class="modal-body">
                        @csrf
                        @method('PUT')
                        <div class="form-group">
                            <label>Nama</label>
                            <input class="form-control form-control-sm @error('nama') is-invalid @enderror" name="nama"
                                value="{{ old('nama') }}" required autocomplete="off">
                            @error('nama')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label>File</label>
                            <input class="form-control form-control-sm @error('file') is-invalid @enderror" name="file"
                                required type="file" accept=".pdf,image/*">
                            @error('file')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-secondary btn-sm">Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    @push('js')
        <script>
            $(document).on('click', '.btn-edit', function() {
                $('#modalBerkas form').attr('action', $(this).data('url'));
                $('#modalBerkas input[name="nama"]').val($(this).data('nama'));
            });
        </script>
    @endpush
@endsection
