@extends('pegawai.layout')

@section('content')
    <form action="{{ route('berkas.update', [$pegawai->id, $berkas->id]) }}" method="post" enctype="multipart/form-data">
        @csrf
        @method('PUT')
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label>Jenis Berkas</label>
                    <select name="jenis" class="form-control @error('jenis') is-invalid @enderror">
                        <option value="" hidden>Pilih jenis</option>
                        @foreach ($jenis as $item)
                            <option value="{{ $item->id }}" @selected($item->id == old('jenis', $berkas->jenis_berkas_id))>{{ $item->nama }}</option>
                        @endforeach
                    </select>
                    @error('jenis')
                        <div class="invalid-feedback">
                            {{ $message }}
                        </div>
                    @enderror
                </div>
                <div class="form-group">
                    <label>Nama</label>
                    <input class="form-control form-control-sm @error('nama') is-invalid @enderror" name="nama"
                        value="{{ old('nama', $berkas->nama) }}" required autocomplete="off">
                    @error('nama')
                        <div class="invalid-feedback">
                            {{ $message }}
                        </div>
                    @enderror
                </div>
                <div class="form-group">
                    <label>File</label>
                    <input class="form-control form-control-sm @error('file') is-invalid @enderror" name="file"
                        type="file" accept=".pdf,image/*">
                    @error('file')
                        <div class="invalid-feedback">
                            {{ $message }}
                        </div>
                    @enderror
                </div>
            </div>
        </div>
        <button class="btn btn-primary">Simpan</button>
    </form>
@endsection
