@props(['title' => '', 'subtitle' => ''])
<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>{{ config('app.name') }}</title>
    <!-- base:css -->
    @vite(['resources/css/app.css'])
    <link rel="shortcut icon" href="/images/logo.png" />
</head>

<body>
    <div class="container-scroller">
        <!-- partial:partials/_navbar.html -->
        <nav class="navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
            <div class="text-center navbar-brand-wrapper d-flex align-items-center justify-content-center">
                <a class="navbar-brand brand-logo" href="/"><img src="/images/logo.png" alt="logo" /></a>
                <a class="navbar-brand brand-logo-mini" href="/"><img src="/images/logo.png" alt="logo" /></a>
                <button class="navbar-toggler navbar-toggler align-self-center d-none d-lg-flex" type="button"
                    data-toggle="minimize">
                    <span class="typcn typcn-th-menu"></span>
                </button>
            </div>
            <div class="navbar-menu-wrapper d-flex align-items-center justify-content-end">
                <ul class="navbar-nav navbar-nav-right">
                    <li class="nav-item nav-profile dropdown">
                        <a class="nav-link dropdown-toggle  pl-0 pr-0" href="#" data-toggle="dropdown"
                            id="profileDropdown">
                            <i class="typcn typcn-user-outline mr-0"></i>
                            <span class="nav-profile-name">{{ Auth::user()->nama }}</span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right navbar-dropdown"
                            aria-labelledby="profileDropdown">
                            @if (Auth::user()->roles->count() > 1)
                                @foreach (Auth::user()->roles as $item)
                                    <form method="POST" action="{{ route('user.role', $item->simbol) }}">
                                        @csrf
                                        @method('PUT')
                                        <a class="dropdown-item" href="#"
                                            onclick="event.preventDefault();
                                                    this.closest('form').submit();">
                                            <i class="typcn typcn-user text-primary"></i>
                                            {{ $item->nama }}
                                        </a>
                                    </form>
                                @endforeach
                                <div class="dropdown-divider"></div>
                            @endif
                            <a class="dropdown-item" href="{{ route('profile.edit') }}">
                                <i class="typcn typcn-lock-closed text-primary"></i>
                                Ubah Password
                            </a>
                            <div class="dropdown-divider"></div>
                            <form method="POST" action="{{ route('logout') }}">
                                @csrf
                                <a class="dropdown-item" href="{{ route('logout') }}"
                                    onclick="event.preventDefault();
                                                this.closest('form').submit();">
                                    <i class="typcn typcn-power text-primary"></i>
                                    Logout
                                </a>
                            </form>
                        </div>
                    </li>
                </ul>
                <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button"
                    data-toggle="offcanvas">
                    <span class="typcn typcn-th-menu"></span>
                </button>
            </div>
        </nav>
        <!-- partial -->
        <div class="container-fluid page-body-wrapper">
            <nav class="sidebar sidebar-offcanvas" id="sidebar">
                <ul class="nav">
                    <li class="nav-item">
                        <div class="d-flex sidebar-profile">
                            <div class="sidebar-profile-image">
                                <img src="/images/faces/face1.jpg" alt="image">
                                <span class="sidebar-status-indicator"></span>
                            </div>
                            <div class="sidebar-profile-name">
                                <p class="sidebar-name">
                                    {{ Auth::user()->nama }}
                                </p>
                                <p class="sidebar-designation">
                                    Welcome
                                </p>
                            </div>
                        </div>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="{{ route('dashboard') }}">
                            <i class="typcn typcn-device-desktop menu-icon"></i>
                            <span class="menu-title">Dashboard</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="{{ route('kpi.index') }}">
                            <i class="typcn typcn-document-text menu-icon"></i>
                            <span class="menu-title">KPI</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" data-toggle="collapse" href="#timesheet-nav" aria-expanded="false"
                            aria-controls="timesheet-nav">
                            <i class="typcn typcn-folder menu-icon"></i>
                            <span class="menu-title">Timesheet</span>
                            <i class="menu-arrow"></i>
                        </a>
                        <div class="collapse" id="timesheet-nav">
                            <ul class="nav flex-column sub-menu">
                                <li class="nav-item">
                                    <a class="nav-link" href="{{ route('timesheet.index') }}">Isi Data</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="{{ route('timesheet.report') }}">Rekapan</a>
                                </li>
                            </ul>
                        </div>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link"
                            href="{{ Auth::user()->role == 'admin' ? route('pegawai.index') : route('pegawai.show', Auth::id()) }}">
                            <i class="typcn typcn-user-outline menu-icon"></i>
                            <span class="menu-title">Pegawai</span>
                        </a>
                    </li>
                    @if (Auth::user()->role == 'admin')
                        <li class="nav-item">
                            <a class="nav-link" href="{{ route('user.index') }}">
                                <i class="typcn typcn-user menu-icon"></i>
                                <span class="menu-title">User</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" data-toggle="collapse" href="#tables" aria-expanded="false"
                                aria-controls="tables">
                                <i class="typcn typcn-folder menu-icon"></i>
                                <span class="menu-title">Master Data</span>
                                <i class="menu-arrow"></i>
                            </a>
                            <div class="collapse" id="tables">
                                <ul class="nav flex-column sub-menu">
                                    <li class="nav-item">
                                        <a class="nav-link" href="{{ route('jenis-file.index') }}">Jenis Berkas</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="{{ route('jenis-jabatan.index') }}">Jenis
                                            Jabatan</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="{{ route('jabatan.index') }}">Jabatan</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="{{ route('divisi.index') }}">Divisi</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="{{ route('pengesahan.index') }}">Pengesahan</a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                    @endif
                </ul>
            </nav>
            <!-- partial -->
            <div class="main-panel">
                <div class="content-wrapper">
                    <div class="row mb-3 justify-content-between align-items-center">
                        <div class="col-auto">
                            {{ $title }}
                        </div>
                        <div class="col-auto">
                            <div class="d-flex align-items-center justify-content-md-end">
                                {{ $subtitle }}
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12">
                            {{ $slot }}
                        </div>
                    </div>
                </div>
                <!-- content-wrapper ends -->
                <!-- partial:partials/_footer.html -->
                <footer class="footer">
                    <div class="d-sm-flex justify-content-center justify-content-sm-between">
                        <span class="text-center text-sm-left d-block d-sm-inline-block">Copyright © <a
                                href="https://www.bootstrapdash.com/" target="_blank">bootstrapdash.com</a>
                            2020</span>
                        <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">Free <a
                                href="https://www.bootstrapdash.com/" target="_blank">Bootstrap dashboard
                            </a>templates from
                            Bootstrapdash.com</span>
                    </div>
                </footer>
                <!-- partial -->
            </div>
            <!-- main-panel ends -->
        </div>
        <!-- page-body-wrapper ends -->
    </div>

    <div class="modal fade" id="modalDelete" tabindex="-1" aria-labelledby="modalDeleteLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalDeleteLabel">Apakah kamu yakin ?</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    Data yang dihapus tidak bisa dikembalikan
                </div>
                <div class="modal-footer">
                    <form action="#" method="post">
                        @csrf
                        @method('delete')
                        <button class="btn btn-danger">Hapus</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- container-scroller -->
    <!-- base:js -->
    <script src="/js/vendor.bundle.base.js"></script>
    @vite(['resources/js/app.js'])
    @include('sweetalert::alert', ['cdn' => 'https://cdn.jsdelivr.net/npm/sweetalert2@9'])

    <script>
        $(document).ready(function() {
            $('.btn-delete').on('click', function() {
                const form = $('#modalDelete form');
                form.attr('action', $(this).data('url'));
                $('#modalDelete').modal('show');
            });
        });
    </script>
    @stack('js')
</body>

</html>
