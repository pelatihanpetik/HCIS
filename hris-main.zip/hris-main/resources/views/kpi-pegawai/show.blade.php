<x-layouts.base>
    <x-slot:title>
        <h3 class="mb-0 font-weight-bold">{{ $kpi->kpi->nama }}</h3>
        <p>{{ $kpi->kpi->jabatan }} {{ $kpi->kpi->divisi ? '- Divisi ' . $kpi->kpi->divisi : '' }}</p>
    </x-slot>
    <x-slot:subtitle>
        <a class="btn btn-sm bg-white btn-icon-text border" href="{{ route('kpi-pegawai.index') }}">
            <i class="typcn typcn-chevron-left"></i>
            Kembali
        </a>
    </x-slot>

    <div class="card">
        <div class="card-body">
            <div class="row">
                <div class="col-12">
                    @php
                        $no = 'A';
                        $totalBobot = 0;
                    @endphp
                    @foreach ($lists as $list)
                        <h4 class="mt-3">{{ $no++ }}. {{ strtoupper($list->nama) }} (Bobot:
                            {{ $list->bobot }}%)</h4>
                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>KPI</th>
                                        <th>Kriteria Penilaian</th>
                                        <th>Bobot</th>
                                        <th>Nilai</th>
                                        <th>Bobot Tercapai</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @php
                                        $sum = [
                                            'bobot' => 0,
                                            'nilai' => 0,
                                            'bobot_tercapai' => 0,
                                        ];
                                    @endphp
                                    @foreach ($list->lists as $item)
                                        @php
                                            if ($item->pegawai) {
                                                $sum['bobot'] += $item->bobot;
                                                $sum['nilai'] += $item->pegawai->nilai;
                                                $sum['bobot_tercapai'] += $item->pegawai->bobot;
                                            }
                                        @endphp
                                        <tr>
                                            <td>{{ $loop->iteration }}</td>
                                            <td>{{ $item->teks }}</td>
                                            <td>
                                                <ol>
                                                    @foreach ($item->kriteria as $kriteria)
                                                        <li>{{ $kriteria }}</li>
                                                    @endforeach
                                                </ol>
                                            </td>
                                            <td>{{ $item->bobot }}%</td>
                                            <td>{{ $item->pegawai->nilai ?? 0 }}</td>
                                            <td>{{ $item->pegawai->bobot ?? 0 }}%</td>
                                        </tr>
                                    @endforeach
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <th colspan="3" class="text-right">Total</th>
                                        <th>{{ $sum['bobot'] }}%</th>
                                        <th>{{ $sum['nilai'] }}</th>
                                        <th>{{ $sum['bobot_tercapai'] }}%</th>
                                    </tr>
                                </tfoot>
                                @php
                                    $totalBobot += $sum['bobot_tercapai'];
                                @endphp
                            </table>
                        </div>
                    @endforeach
                    <h4 class="mt-3">{{ $no++ }}. SUMMARY OF PERFORMANCE APPRAISAL REVIEW</h4>
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Aspek Penilaian</th>
                                    <th>Bobot</th>
                                    <th>Total</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($lists as $item)
                                    <tr>
                                        <td>{{ $loop->iteration }}</td>
                                        <td>{{ $item->nama }}</td>
                                        <td>{{ $item->bobot }}%</td>
                                        <td>{{ $totalBobot }}%</td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                    <h4 class="mt-3">{{ $no++ }}. REKOMENDASI PERBAIKAN</h4>
                    @if ($kpi->prb)
                        <p>{{ $kpi->prb->keterangan }}: {{ $kpi->perbaikan ?? '-' }}</p>
                    @else
                        <p>-</p>
                    @endif
                    <h4 class="mt-3">{{ $no++ }}. REKOMENDASI AKHIR</h4>
                    @if ($kpi->akhir)
                        <p>{{ $kpi->akhir->keterangan }}: {{ $kpi->rekomendasi_akhir ?? '-' }}</p>
                    @else
                        <p>-</p>
                    @endif
                    <h4 class="mt-3">{{ $no++ }}. PENGESAHAN</h4>
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Nama</th>
                                    <th>Jabatan</th>
                                    <th>TTD</th>
                                    <th>Tanggal</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($pengesahan as $item)
                                    <tr>
                                        <td>{{ $loop->iteration }}</td>
                                        <td>{{ $item->nama }}</td>
                                        <td>{{ $item->jabatan }}</td>
                                        <td>
                                            @if ($item->ttd)
                                                <img src="{{ route('file.index', ['path' => $item->ttd]) }}"
                                                    alt="ttd" width="100">
                                            @else
                                                <span class="badge badge-danger">Belum diisi</span>
                                            @endif
                                        </td>
                                        <td>
                                            @if ($item->tanggal)
                                                {{ $item->tanggal->isoFormat('D MMMM YYYY') }}
                                            @else
                                                <span class="badge badge-danger">Belum diisi</span>
                                            @endif
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</x-layouts.base>
