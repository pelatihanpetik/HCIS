<x-layouts.base>
    <x-slot:title>
        <h3 class="mb-0 font-weight-bold">{{ $kpi->kpi->nama }}</h3>
        <p>{{ $kpi->kpi->jabatan }} {{ $kpi->kpi->divisi ? '- Divisi ' . $kpi->kpi->divisi : '' }}</p>
    </x-slot>
    <x-slot:subtitle>
        <a class="btn btn-sm bg-white btn-icon-text border" href="{{ route('kpi-pegawai.index') }}">
            <i class="typcn typcn-chevron-left"></i>
            Kembali
        </a>
    </x-slot>

    <div class="card">
        <div class="card-body">
            @php
                $no = 'A';
            @endphp
            <form action="{{ route('kpi-pegawai.store', $kpi->kpi_id) }}" method="post">
                @csrf
                @foreach ($lists as $list)
                    <h4 class="mt-3">{{ $no++ }}. {{ strtoupper($list->nama) }} (Bobot: {{ $list->bobot }}%)
                    </h4>
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>KPI</th>
                                    <th>Kriteria Penilaian</th>
                                    <th>Bobot</th>
                                    <th>Nilai</th>
                                    <th>Bobot Tercapai</th>
                                </tr>
                            </thead>
                            <tbody>
                                @php
                                    $sum = [
                                        'bobot' => 0,
                                        'nilai' => 0,
                                        'bobot_tercapai' => 0,
                                    ];
                                @endphp
                                @foreach ($list->lists as $item)
                                    @php
                                        $sum['bobot'] += $item->bobot;
                                        $sum['nilai'] += $item->pegawai->nilai;
                                        $sum['bobot_tercapai'] += $item->pegawai->bobot;
                                    @endphp
                                    <tr>
                                        <td>{{ $loop->iteration }}</td>
                                        <td>{{ $item->teks }}</td>
                                        <td>
                                            <ol>
                                                @foreach ($item->kriteria as $kriteria)
                                                    <li>{{ $kriteria }}</li>
                                                @endforeach
                                            </ol>
                                        </td>
                                        <td>{{ $item->bobot }}%</td>
                                        <td>
                                            <select style="width: 75px;" name="nilai_{{ $item->pegawai->id }}"
                                                class="form-control form-control-sm @error('nilai_' . $item->pegawai->id) is-invalid @enderror"
                                                required>
                                                <option value="0">Pilih</option>
                                                @foreach ([1, 2, 3, 4, 5] as $val)
                                                    <option value="{{ $val }}" @selected(old('nilai_' . $item->pegawai->id, $item->pegawai->nilai))>
                                                        {{ $val }}</option>
                                                @endforeach
                                            </select>
                                            @error('nilai_' . $item->pegawai->id)
                                                <div class="invalid-feedback">
                                                    {{ $message }}
                                                </div>
                                            @enderror
                                        </td>
                                        <td>
                                            {{ $item->pegawai->bobot }}%
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th colspan="3" class="text-right">Total</th>
                                    <th>{{ $sum['bobot'] }}%</th>
                                    <th>{{ $sum['nilai'] }}</th>
                                    <th>{{ $sum['bobot_tercapai'] }}%</th>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                @endforeach
                <button class="btn btn-primary mt-3">Simpan</button>
            </form>
        </div>
    </div>
</x-layouts.base>
