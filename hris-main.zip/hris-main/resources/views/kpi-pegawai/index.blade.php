<x-layouts.base>
    <x-slot:title>
        <h3>Daftar KPI</h3>
    </x-slot>

    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama</th>
                            <th>Jabatan</th>
                            <th>Divisi</th>
                            <th>Bobot</th>
                            <th>Perbaikan</th>
                            <th>Rekomendasi Akhir</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($kpi as $item)
                            <tr>
                                <td>
                                    {{ $loop->iteration }}
                                </td>
                                <td>{{ $item->kpi->nama }}</td>
                                <td>{{ $item->kpi->jabatan }}</td>
                                <td>{{ $item->kpi->divisi }}</td>
                                <td>{{ $item->lists_sum_bobot }}%</td>
                                @if ($item->prb)
                                    <td>{{ $item->prb->keterangan }}: {{ $item->perbaikan }}</td>
                                    <td>{{ $item->akhir->keterangan }}: {{ $item->rekomendasi_akhir }}</td>
                                @else
                                    <td>-</td>
                                    <td>-</td>
                                @endif
                                <td>
                                    @if ($item->kpi->is_active == 1)
                                        <span class="badge badge-success">Aktif</span>
                                    @else
                                        <span class="badge badge-danger">Tidak aktif</span>
                                    @endif
                                </td>
                                <td>
                                    @if ($item->kpi->is_active == 1)
                                        <a href="{{ route('kpi-pegawai.create', $item->kpi_id) }}"
                                            class="btn btn-sm btn-primary">
                                            Isi data
                                        </a>
                                    @endif
                                    <a href="{{ route('kpi.detail', [$item->kpi_id, Auth::id()]) }}"
                                        class="btn btn-sm btn-secondary">Detail</a>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</x-layouts.base>
