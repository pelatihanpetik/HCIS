<x-layouts.base>
    <x-slot:title>
        <h3>Daftar Divisi</h3>
    </x-slot>
    <x-slot:subtitle>
        <button id="btn-create" class="btn btn-sm bg-white btn-icon-text border" data-toggle="modal"
            data-target="#modalJenis" type="button">
            <i class="typcn typcn-plus"></i>
            Tambah data
        </button>
    </x-slot>

    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($divisi as $i => $item)
                            <tr>
                                <td>{{ $i + 1 }}</td>
                                <td>{{ $item->nama }}</td>
                                <td>
                                    <button class="btn btn-sm btn-success btn-edit" data-toggle="modal"
                                        data-target="#modalJenis" type="button"
                                        data-url="{{ route('divisi.update', $item->id) }}"
                                        data-nama="{{ $item->nama }}">
                                        Edit
                                    </button>
                                    <button class="btn btn-sm btn-danger btn-delete"
                                        data-url="{{ route('divisi.destroy', $item->id) }}">Hapus</button>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <!-- Modal -->
    <div class="modal fade" id="modalJenis" tabindex="-1" aria-labelledby="modalJenisLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="modalJenisLabel">Divisi</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form action="{{ route('divisi.store') }}" method="post">
                    <div class="modal-body">
                        @csrf
                        <input type="hidden" name="_method">
                        <div class="form-group">
                            <label>Divisi</label>
                            <input class="form-control form-control-sm @error('nama') is-invalid @enderror"
                                name="nama" value="{{ old('nama') }}" required autofocus autocomplete="off">
                            @error('nama')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-secondary btn-sm">Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    @push('js')
        <script>
            $(document).on('click', '#btn-create', function() {
                $('#modalJenis input[name="nama"]').val('');
                $('#modalJenis form').attr('action', "{{ route('divisi.store') }}");
                $('#modalJenis input[name="_method"]').val('');
            });
            $(document).on('click', '.btn-edit', function() {
                $('#modalJenis input[name="nama"]').val($(this).data('nama'));
                $('#modalJenis form').attr('action', $(this).data('url'));
                $('#modalJenis input[name="_method"]').val('PUT');
            });
        </script>
    @endpush
</x-layouts.base>
