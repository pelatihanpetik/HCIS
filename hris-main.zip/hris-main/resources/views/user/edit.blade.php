<x-layouts.base>
    <x-slot:title>
        <h3>Tambah User</h3>
    </x-slot>
    <x-slot:subtitle>
        <a class="btn btn-sm bg-white btn-icon-text border" href="{{ route('user.index') }}">
            <i class="typcn typcn-chevron-left"></i>
            Kembali
        </a>
    </x-slot>

    <div class="card">
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <form action="{{ route('user.update', $user) }}" method="post">
                        @csrf
                        @method('put')
                        <div class="form-group">
                            <label for="nama">Nama</label>
                            <input class="form-control @error('nama') is-invalid @enderror" name="nama"
                                value="{{ old('nama', $user->nama) }}" required autofocus autocomplete="off">
                            @error('nama')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" class="form-control @error('email') is-invalid @enderror"
                                id="email" placeholder="Email..." name="email"
                                value="{{ old('email', $user->email) }}" required autocomplete="off">
                            @error('email')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-group">
                            @foreach ($roles as $item)
                                <div class="form-check">
                                    <label class="form-check-label">
                                        <input type="checkbox" class="form-check-input" name="roles[]"
                                            value="{{ $item->simbol }}" @checked(in_array($item->simbol, old('roles', $user->roles->pluck('simbol')->toArray())))>
                                        {{ $item->nama }}
                                        <i class="input-helper"></i></label>
                                </div>
                            @endforeach
                        </div>
                        <button class="btn btn-primary">Simpan</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</x-layouts.base>
