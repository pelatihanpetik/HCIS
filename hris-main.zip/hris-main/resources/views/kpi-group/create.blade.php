<x-layouts.base>
    <x-slot:title>
        <h3>Tambah KPI Group</h3>
    </x-slot>
    <x-slot:subtitle>
        <a class="btn btn-sm bg-white btn-icon-text border" href="{{ route('kpi-group.index') }}">
            <i class="typcn typcn-chevron-left"></i>
            Kembali
        </a>
    </x-slot>

    <div class="card">
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <form action="{{ route('kpi-group.store') }}" method="post">
                        @csrf
                        <div class="form-group">
                            <label for="nama">Nama</label>
                            <input class="form-control form-control-sm @error('nama') is-invalid @enderror"
                                name="nama" value="{{ old('nama') }}" required autofocus autocomplete="off">
                            @error('nama')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label for="bobot">Bobot</label>
                            <input class="form-control form-control-sm @error('bobot') is-invalid @enderror"
                                name="bobot" value="{{ old('bobot') }}" required type="number" autocomplete="off">
                            @error('bobot')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <button class="btn btn-primary">Submit</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</x-layouts.base>
