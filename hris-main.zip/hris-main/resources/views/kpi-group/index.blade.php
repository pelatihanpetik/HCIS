<x-layouts.base>
    <x-slot:title>
        <h3>Daftar KPI</h3>
    </x-slot>
    <x-slot:subtitle>
        <a class="btn btn-sm bg-white btn-icon-text border" href="{{ route('kpi-group.create') }}">
            <i class="typcn typcn-plus"></i>
            Tambah data
        </a>
    </x-slot>

    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama</th>
                            <th>Bobot</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($group as $i => $item)
                            <tr>
                                <td>
                                    {{ $i + 1 }}
                                </td>
                                <td>{{ $item->nama }}</td>
                                <td>{{ $item->bobot }}%</td>
                                <td>
                                    <a href="{{ route('kpi-group.edit', $item->id) }}"
                                        class="btn btn-sm btn-success">Edit</a>
                                    <button class="btn btn-sm btn-danger btn-delete"
                                        data-url="{{ route('kpi-group.destroy', $item->id) }}">Hapus</button>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</x-layouts.base>
