@extends('pegawai.layout')

@section('content')
    <form action="{{ route('pendidikan.update', [$pegawai->id, $pendidikan->id]) }}" method="post">
        @csrf
        @method('PUT')
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label for="tingkat">Tingkat</label>
                    <select name="tingkat" class="form-control">
                        <option value="" hidden>Pilih Tingkat</option>
                        @foreach ($tingkat as $item)
                            <option value="{{ $item }}" @selected(old('tingkat', $pendidikan->tingkat) == $item)>
                                {{ $item }}</option>
                        @endforeach
                    </select>
                    @error('tingkat')
                        <div class="invalid-feedback">
                            {{ $message }}
                        </div>
                    @enderror
                </div>
            </div>
            <div class="form-group col-md-6">
                <label for="sekolah">Sekolah</label>
                <input class="form-control form-control-sm @error('sekolah') is-invalid @enderror" name="sekolah"
                    value="{{ old('sekolah', $pendidikan->sekolah) }}" required autocomplete="off">
                @error('sekolah')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror
            </div>
            <div class="form-group col-md-6">
                <label for="jurusan">Jurusan</label>
                <input class="form-control form-control-sm @error('jurusan') is-invalid @enderror" name="jurusan"
                    value="{{ old('jurusan', $pendidikan->jurusan) }}" required autocomplete="off">
                @error('jurusan')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror
            </div>
            <div class="col-md-6 form-group">
                <label for="tanggal_mulai">Tanggal Mulai</label>
                <input class="form-control form-control-sm @error('tanggal_mulai') is-invalid @enderror"
                    name="tanggal_mulai" value="{{ old('tanggal_mulai', $pendidikan->tanggal_mulai->format('Y-m-d')) }}"
                    autocomplete="off" type="date">
                @error('tanggal_mulai')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror
            </div>
            <div class="col-md-6 form-group">
                <label for="tanggal_selesai">Tanggal Selesai</label>
                <input class="form-control form-control-sm @error('tanggal_selesai') is-invalid @enderror"
                    name="tanggal_selesai"
                    value="{{ old('tanggal_selesai', $pendidikan->tanggal_selesai ? $pendidikan->tanggal_selesai->format('Y-m-d') : '') }}"
                    autocomplete="off" type="date">
                @error('tanggal_selesai')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror
            </div>
        </div>
        <button class="btn btn-primary">Simpan</button>
    </form>
@endsection
