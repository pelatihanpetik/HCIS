@extends('pegawai.layout')

@section('content')
    <a class="btn btn-primary btn-sm mt-n3 mb-3" href="{{ route('pendidikan.create', $pegawai->id) }}">
        Tambah data
    </a>

    <div class="table-responsive">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Tingkat</th>
                    <th>Sekolah</th>
                    <th>Jurusan</th>
                    <th>Tanggal Mulai</th>
                    <th>Tanggal Selesai</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($pegawai->pendidikan as $i => $item)
                    <tr>
                        <td>{{ $i + 1 }}</td>
                        <td>{{ $item->tingkat }}</td>
                        <td>{{ $item->sekolah }}</td>
                        <td>{{ $item->jurusan }}</td>
                        <td>{{ $item->tanggal_mulai->isoFormat('DD MMMM YYYY') }}</td>
                        <td>{{ $item->tanggal_selesai ? $item->tanggal_selesai->isoFormat('DD MMMM YYYY') : 'Sekarang' }}
                        </td>
                        <td>
                            <a href="{{ route('pendidikan.edit', [$pegawai->id, $item->id]) }}"
                                class="btn btn-sm btn-success">Edit</a>
                            <button class="btn btn-sm btn-danger btn-delete"
                                data-url="{{ route('pendidikan.destroy', [$pegawai->id, $item->id]) }}">Hapus</button>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
@endsection
