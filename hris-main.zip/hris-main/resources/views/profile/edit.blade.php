<x-layouts.base>
    <x-slot:title>
        <h3 class="mb-0 font-weight-bold">Profil</h3>
    </x-slot>

    <div class="row">
        <div class="col-md-6">
            <div class="card mb-3">
                <div class="card-body">
                    @include('profile.partials.update-password-form')
                </div>
            </div>
        </div>
    </div>
</x-layouts.base>
