<section>
    <h4 class="card-title">Update Password</h4>
    <p>Ensure your account is using a long, random password to stay secure.</p>

    <form method="post" action="{{ route('password.update') }}">
        @csrf
        @method('put')
        <div class="form-group">
            <label for="update_password_current_password">Current Password</label>
            <input type="password" class="form-control @if ($errors->updatePassword->get('current_password')) is-invalid @endif"
                id="update_password_current_password" name="current_password" required>
            @if ($errors->updatePassword->get('current_password'))
                <div class="invalid-feedback">
                    @foreach ((array) $errors->updatePassword->get('current_password') as $message)
                        {{ $message }},
                    @endforeach
                </div>
            @endif
        </div>
        <div class="form-group">
            <label for="update_password_password">New Password</label>
            <input type="password" class="form-control @if ($errors->updatePassword->get('password')) is-invalid @endif"
                id="update_password_password" name="password" required>
            @if ($errors->updatePassword->get('password'))
                <div class="invalid-feedback">
                    @foreach ((array) $errors->updatePassword->get('password') as $message)
                        {{ $message }},
                    @endforeach
                </div>
            @endif
        </div>
        <div class="form-group">
            <label for="password_confirmation">Confirm Password</label>
            <input type="password" class="form-control @if ($errors->updatePassword->get('password_confirmation')) is-invalid @endif"
                id="password_confirmation" name="password_confirmation" required>
            @if ($errors->updatePassword->get('password_confirmation'))
                <div class="invalid-feedback">
                    @foreach ((array) $errors->updatePassword->get('password_confirmation') as $message)
                        {{ $message }},
                    @endforeach
                </div>
            @endif
        </div>
        <button class="btn btn-primary">Save</button>
    </form>
</section>
