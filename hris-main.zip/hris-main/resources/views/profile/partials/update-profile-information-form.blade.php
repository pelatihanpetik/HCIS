<section>
    <h4 class="card-title">Profile Information</h4>
    <p>Update your account's profile information and email address.</p>
    <form method="post" action="{{ route('profile.update') }}" class="mt-6 space-y-6">
        @csrf
        @method('patch')
        <div class="form-group">
            <label for="nama">Name</label>
            <input class="form-control @error('nama') is-invalid @enderror" name="nama"
                value="{{ old('nama', $user->nama) }}" required autofocus autocomplete="username">
            @error('nama')
                <div class="invalid-feedback">
                    {{ $message }}
                </div>
            @enderror
        </div>
        <div class="form-group">
            <label for="email">Email</label>
            <input type="email" class="form-control @error('email') is-invalid @enderror" id="email"
                placeholder="Email..." name="email" value="{{ old('email', $user->email) }}" required autofocus
                autocomplete="username">
            @error('email')
                <div class="invalid-feedback">
                    {{ $message }}
                </div>
            @enderror
        </div>

        <button class="btn btn-primary">Save</button>
    </form>
</section>
