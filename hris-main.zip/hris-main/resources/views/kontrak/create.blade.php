@extends('pegawai.layout')

@section('content')
    <form action="{{ route('kontrak.store', $pegawai->id) }}" method="post" enctype="multipart/form-data">
        @csrf
        <div class="row">
            <div class="form-group col-md-12">
                <label>Nomor</label>
                <input class="form-control form-control-sm @error('nomor') is-invalid @enderror" name="nomor"
                    value="{{ old('nomor') }}" autocomplete="off">
                @error('nomor')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror
            </div>
            <div class="form-group col-md-6">
                <label>Tanggal berlaku</label>
                <input class="form-control form-control-sm @error('tanggal_dari') is-invalid @enderror" name="tanggal_dari"
                    value="{{ old('tanggal_dari') }}" autocomplete="off" type="date">
                @error('tanggal_dari')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror
            </div>
            <div class="form-group col-md-6">
                <label>Sampai</label>
                <input class="form-control form-control-sm @error('tanggal_sampai') is-invalid @enderror"
                    name="tanggal_sampai" value="{{ old('tanggal_sampai') }}" autocomplete="off" type="date">
                @error('tanggal_sampai')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror
            </div>
            <div class="form-group col-md-6">
                <label>Hal</label>
                <input class="form-control form-control-sm @error('hal') is-invalid @enderror" name="hal"
                    value="{{ old('hal') }}">
                @error('hal')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror
            </div>
            <div class="form-group col-md-6">
                <label>Penghasilan</label>
                <input class="form-control form-control-sm @error('penghasilan') is-invalid @enderror" name="penghasilan"
                    value="{{ old('penghasilan') }}" type="number">
                @error('penghasilan')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                @enderror
            </div>
        </div>
        <button class="btn btn-primary">Simpan</button>
    </form>
@endsection
