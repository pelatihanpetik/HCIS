@extends('pegawai.layout')

@section('content')
    <a class="btn btn-primary btn-sm mt-n3 mb-3" href="{{ route('kontrak.create', $pegawai->id) }}">
        Tambah data
    </a>

    <div class="table-responsive mb-4">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Nomor</th>
                    <th>Tanggal surat</th>
                    <th>Berlaku sampai</th>
                    <th>Hal</th>
                    <th>Penghasilan</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($pegawai->kontrak as $i => $item)
                    <tr>
                        <td>{{ $item->nomor }}</td>
                        <td>{{ $item->tanggal_dari->isoFormat('DD MMMM YYYY') }}</td>
                        <td>{{ $item->tanggal_sampai ? $item->tanggal_sampai->isoFormat('DD MMMM YYYY') : 'Sekarang' }}</td>
                        <td>{{ $item->hal }}</td>
                        <td>@currency($item->penghasilan)</td>
                        <td>
                            <a href="{{ route('kontrak.edit', [$pegawai->id, $item->id]) }}"
                                class="btn btn-sm btn-success">Edit</a>
                            <button class="btn btn-sm btn-danger btn-delete"
                                data-url="{{ route('kontrak.destroy', [$pegawai->id, $item->id]) }}">Hapus</button>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>

    <hr>
    <h4>Nomor Rekening</h4>
    <button id="btn-create" class="btn btn-sm btn-primary mb-3" data-toggle="modal" data-target="#rekeningModal"
        type="button">
        Tambah data
    </button>
    <div class="table-responsive">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Bank</th>
                    <th>Nomor</th>
                    <th>Atas Nama</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($pegawai->rekening as $i => $item)
                    <tr>
                        <td>{{ $i + 1 }}</td>
                        <td>{{ $item->bank }}</td>
                        <td>{{ $item->nomor }}</td>
                        <td>{{ $item->nama }}</td>
                        <td>
                            <button class="btn btn-sm btn-success btn-edit" data-toggle="modal" data-target="#rekeningModal"
                                type="button" data-url="{{ route('rekening.update', [$pegawai->id, $item->id]) }}"
                                data-nama="{{ $item->nama }}" data-bank="{{ $item->bank }}"
                                data-nomor="{{ $item->nomor }}">
                                Edit
                            </button>
                            <button class="btn btn-sm btn-danger btn-delete"
                                data-url="{{ route('rekening.destroy', [$pegawai->id, $item->id]) }}">Hapus</button>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>

    <div class="modal fade" id="rekeningModal" tabindex="-1" aria-labelledby="modalJenisLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="modalJenisLabel">Nomor Rekening</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form action="{{ route('jenis-jabatan.store') }}" method="post">
                    <div class="modal-body">
                        @csrf
                        <input type="hidden" name="_method">
                        <div class="form-group">
                            <label>Bank</label>
                            <input class="form-control form-control-sm @error('bank') is-invalid @enderror" name="bank"
                                value="{{ old('bank') }}" required autofocus autocomplete="off">
                            @error('bank')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label>Nomor</label>
                            <input class="form-control form-control-sm @error('nomor') is-invalid @enderror" name="nomor"
                                value="{{ old('nomor') }}" required autocomplete="off">
                            @error('nomor')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        <div class="form-group">
                            <label>Atas Nama</label>
                            <input class="form-control form-control-sm @error('nama') is-invalid @enderror" name="nama"
                                value="{{ old('nama') }}" required autocomplete="off">
                            @error('nama')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-secondary btn-sm">Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    @push('js')
        <script>
            $(document).on('click', '#btn-create', function() {
                $('#rekeningModal input[name="nama"]').val('');
                $('#rekeningModal input[name="bank"]').val('');
                $('#rekeningModal input[name="nomor"]').val('');
                $('#rekeningModal form').attr('action', "{{ route('rekening.store', $pegawai->id) }}");
                $('#rekeningModal input[name="_method"]').val('');
            });
            $(document).on('click', '.btn-edit', function() {
                $('#rekeningModal input[name="nama"]').val($(this).data('nama'));
                $('#rekeningModal input[name="bank"]').val($(this).data('bank'));
                $('#rekeningModal input[name="nomor"]').val($(this).data('nomor'));
                $('#rekeningModal form').attr('action', $(this).data('url'));
                $('#rekeningModal input[name="_method"]').val('PUT');
            });
        </script>
    @endpush
@endsection
