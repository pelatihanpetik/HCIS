<x-layouts.base>
    <x-slot:title>
        <h3 class="mb-0 font-weight-bold">Timesheet</h3>
    </x-slot>
    <x-slot:subtitle>
        <a class="btn btn-sm bg-white btn-icon-text border" href="{{ route('timesheet.create') }}">
            <i class="typcn typcn-plus"></i>
            Tambah data
        </a>
    </x-slot>

    <div class="card">
        <div class="card-body">
            <form action="" method="get">
                <div class="row">
                    <div class="col-md-6">
                        <input type="month" name="month" class="form-control mb-3"
                            value="{{ request('month', date('Y-m')) }}">
                    </div>
                    <div class="col-md-6">
                        <button type="submit" class="btn btn-primary mb-3">Tampilkan</button>
                    </div>
                </div>
            </form>
            <div class="table-responsive">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Tanggal</th>
                            <th>Projek</th>
                            <th>Task</th>
                            <th>Durasi</th>
                            <th>Aksi</th>
                            <th>Kendala</th>
                            <th>Solusi</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($timesheets as $row)
                            @php
                                $sum = 0;
                            @endphp
                            @foreach ($row as $item)
                                @php
                                    $sum += $item->duration;
                                @endphp
                                <tr>
                                    @if ($loop->first)
                                        <td rowspan="{{ count($row) }}">
                                            {{ $item->date->locale('id')->isoFormat('dddd, DD MMMM YYYY') }}
                                        </td>
                                    @endif
                                    <td>{{ $item->project }}</td>
                                    <td style="white-space:normal;">{!! $item->task !!}</td>
                                    <td>{{ \Carbon\CarbonInterval::minutes($item->duration)->locale('id')->cascade()->forHumans() }}
                                    </td>
                                    <td>
                                        @can('update', $item)
                                            <a href="{{ route('timesheet.edit', $item->id) }}"
                                                class="btn btn-sm btn-success">Edit</a>
                                        @endcan
                                        @can('delete', $item)
                                            <button class="btn btn-sm btn-danger btn-delete"
                                                data-url="{{ route('timesheet.destroy', $item->id) }}">Hapus</button>
                                        @endcan
                                    </td>
                                    <td style="white-space:normal;">{!! $item->trouble !!}</td>
                                    <td style="white-space:normal;">{!! $item->solution !!}</td>
                                </tr>
                            @endforeach
                            <tr>
                                <th colspan="3">Total</th>
                                <th colspan="4">
                                    {{ \Carbon\CarbonInterval::minutes($sum)->locale('id')->cascade()->forHumans() }}
                                </th>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</x-layouts.base>
