<x-layouts.base>
    <x-slot:title>
        <h3 class="mb-0 font-weight-bold">Laporan Timesheet</h3>
    </x-slot>

    <div class="card">
        <div class="card-body">
            <form action="{{ route('timesheet.report') }}" method="get">
                <div class="row">
                    <div class="col-md-6">
                        <input type="month" name="month" class="form-control mb-3" value="{{ $month }}">
                    </div>
                    <div class="col-md-6">
                        <button type="submit" class="btn btn-primary mb-3">Tampilkan</button>
                    </div>
                </div>
            </form>
            <div class="table-responsive">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama</th>
                            <th>Status</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($report as $item)
                            <tr>
                                <td>{{ $loop->iteration }}</td>
                                <td>{{ $item->nama }}</td>
                                <td>
                                    @if ($weekdays == $item->timesheet_count)
                                        <span class="badge badge-success">Lengkap</span>
                                    @else
                                        <span class="badge badge-danger">Belum Lengkap (kurang
                                            {{ $weekdays - $item->timesheet_count }} hari)</span>
                                    @endif
                                </td>
                                <td>
                                    @can('timesheet', $item)
                                        <a href="{{ route('timesheet.report.detail', [$item->id, 'month' => $month]) }}"
                                            class="btn btn-primary btn-sm">
                                            Detail
                                        </a>
                                    @endcan
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</x-layouts.base>
