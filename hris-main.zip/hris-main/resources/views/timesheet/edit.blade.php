<x-layouts.base>
    <x-slot:title>
        <h3>Edit Timesheet</h3>
    </x-slot>
    <x-slot:subtitle>
        <a class="btn btn-sm bg-white btn-icon-text border" href="{{ route('timesheet.index') }}">
            <i class="typcn typcn-chevron-left"></i>
            Kembali
        </a>
    </x-slot>

    <div class="card">
        <div class="card-body">
            <form action="{{ route('timesheet.update', $timesheet->id) }}" method="post">
                @csrf
                @method('PUT')
                <div class="row">
                    <div class="col-md-6 form-group">
                        <label for="date">Tanggal</label>
                        <input class="form-control @error('date') is-invalid @enderror" name="date"
                            value="{{ old('date', $timesheet->date->format('Y-m-d')) }}" required autofocus
                            autocomplete="off" type="date">
                        @error('date')
                            <div class="invalid-feedback">
                                {{ $message }}
                            </div>
                        @enderror
                    </div>
                    <div class="col-md-6 form-group">
                        <label for="duration">Durasi (menit)</label>
                        <input class="form-control @error('duration') is-invalid @enderror" name="duration"
                            value="{{ old('duration', $timesheet->duration) }}" type="number" min="1">
                        @error('duration')
                            <div class="invalid-feedback">
                                {{ $message }}
                            </div>
                        @enderror
                    </div>
                    <div class="col-12 form-group">
                        <label for="project">Projek</label>
                        <input class="form-control @error('project') is-invalid @enderror" name="project"
                            value="{{ old('project', $timesheet->project) }}">
                        @error('project')
                            <div class="invalid-feedback">
                                {{ $message }}
                            </div>
                        @enderror
                    </div>
                    <div class="col-12 form-group">
                        <label for="task">Task</label>
                        <textarea name="task" class="form-control @error('task') is-invalid @enderror" rows="10">{{ old('task', $timesheet->task) }}</textarea>
                        @error('task')
                            <div class="invalid-feedback">
                                {{ $message }}
                            </div>
                        @enderror
                    </div>
                    <div class="col-md-6 form-group">
                        <label for="trouble">Kendala</label>
                        <textarea name="trouble" class="form-control @error('trouble') is-invalid @enderror" rows="5">{{ old('trouble', $timesheet->trouble) }}</textarea>
                        @error('trouble')
                            <div class="invalid-feedback">
                                {{ $message }}
                            </div>
                        @enderror
                    </div>
                    <div class="col-md-6 form-group">
                        <label for="solution">Solusi</label>
                        <textarea name="solution" class="form-control @error('solution') is-invalid @enderror" rows="5">{{ old('solution', $timesheet->solution) }}</textarea>
                        @error('solution')
                            <div class="invalid-feedback">
                                {{ $message }}
                            </div>
                        @enderror
                    </div>
                </div>
                <button class="btn btn-primary">Simpan</button>
            </form>
        </div>
    </div>
</x-layouts.base>
