<x-layouts.base>
    <x-slot:title>
        <h3 class="m-0">Dashboard</h3>
        <p>Daftar progress KPI</p>
    </x-slot>

    @php
        $chart = [];
    @endphp
    <div class="row">
        @foreach ($progress as $item)
            @php
                $chart[] = [
                    'id' => 'chart-' . $item->id,
                    'progress' => $item->lists_sum_bobot ? $item->lists_sum_bobot / 100 : 0,
                ];
            @endphp
            <div class="col-md-3">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title mb-3">{{ $item->kpi->nama }}</h4>
                        <div id="{{ 'chart-' . $item->id }}" class="progressbar-js-circle rounded p-3 position-relative">
                        </div>
                        <ul class="session-by-channel-legend">
                            <li>
                                <div>Nama</div>
                                <div class="font-weight-bold">{{ $item->pegawai->nama }}</div>
                            </li>
                            <li>
                                <div>Jabatan</div>
                                <div class="font-weight-bold">{{ $item->kpi->jabatan }}</div>
                            </li>
                            <li>
                                <div>Divisi</div>
                                <div class="font-weight-bold">{{ $item->kpi->divisi }}</div>
                            </li>
                        </ul>
                        @if (!$item->lists_sum_bobot)
                            <span class="badge badge-danger btn-block mt-3">Belum ada data</span>
                        @endif
                        @if ($item->pegawai_id == Auth::user()->id)
                            <a href="{{ route('kpi-pegawai.create', $item->kpi_id) }}"
                                class="btn btn-sm btn-primary btn-block mt-3">Isi data</a>
                        @endif
                        @if (Auth::user()->role == 'karyawan' && $posisi->level === 3)
                            <a href="{{ route('kpi.detail', [$item->kpi_id, Auth::id()]) }}"
                                class="btn btn-sm btn-primary btn-block mt-3">Detail</a>
                        @else
                            <a href="{{ route('kpi.detail', [$item->kpi_id, $item->pegawai_id]) }}"
                                class="btn btn-sm btn-primary btn-block mt-3">Detail</a>
                        @endif
                    </div>
                </div>
            </div>
        @endforeach
    </div>

    @push('js')
        <script src="{{ asset('js/progressbar.min.js') }}"></script>
        @include('dashboard.chart-progress', ['chart' => $chart])
    @endpush
</x-layouts.base>
