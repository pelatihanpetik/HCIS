@props(['chart' => []])

<script>
    function circleProgress(selector, data) {
        if ($(selector).length) {
            const bar = new ProgressBar.Circle(selector, {
                color: '#001737',
                // This has to be the same size as the maximum width to
                // prevent clipping
                strokeWidth: 10,
                trailWidth: 10,
                easing: 'easeInOut',
                duration: 1400,
                text: {
                    autoStyleContainer: false
                },
                from: {
                    color: '#2617c9',
                    width: 10
                },
                to: {
                    color: '#2617c9',
                    width: 10
                },
                // Set default step function for all animate calls
                step: function(state, circle) {
                    circle.path.setAttribute('stroke', state.color);
                    circle.path.setAttribute('stroke-width', state.width);

                    const value = `
                    <p class="text-center mb-0">Progress</p><div class="text-center">${Math.round(circle.value() * 1000) / 10}%</div>
                    `;
                    if (value === 0) {
                        circle.setText('');
                    } else {
                        circle.setText(value);
                    }

                }
            });

            bar.text.style.fontSize = '1.875rem';
            bar.text.style.fontWeight = '700';
            bar.animate(data);
        }
    }
    $(document).ready(function() {
        const chart = @json($chart);
        chart.forEach(item => {
            circleProgress('#' + item.id, item.progress);
        });
    });
</script>
