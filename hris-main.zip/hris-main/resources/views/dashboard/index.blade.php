<x-layouts.base>
    <x-slot:title>
        <h3 class="m-0">Dashboard</h3>
        <p>Pencapaian KPI</p>
    </x-slot>

    @isset($lembaga)
        <div class="row">
            @php
                $chart[] = [
                    'id' => 'chart-lembaga',
                    'progress' => !empty($lembaga['bobot_tercapai']) ? $lembaga['bobot_tercapai'] / 100 : 0,
                ];
            @endphp
            <div class="col-md-3">
                <div class="card h-100">
                    <div class="card-body">
                        <h4 class="card-title mb-3">Capaian Lembaga</h4>
                        <div id="chart-lembaga" class="progressbar-js-circle rounded p-3 position-relative">
                        </div>
                    </div>
                </div>
            </div>
            @foreach ($divisi as $i => $item)
                @php
                    $chart[] = [
                        'id' => 'chart-' . $i . $item->id,
                        'progress' => !empty($item->bobot_tercapai) ? $item->bobot_tercapai / $item->pegawai / 100 : 0,
                    ];
                @endphp
                <div class="col-md-3">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title mb-3">{{ $item->nama }}</h4>
                            <div id="{{ 'chart-' . $i . $item->id }}"
                                class="progressbar-js-circle rounded p-3 position-relative">
                            </div>
                            @if ($item->level != 1)
                                <a href="{{ route('dashboard.show', $item->id) }}"
                                    class="btn btn-sm btn-primary btn-block mt-3">Detail</a>
                            @endif
                        </div>
                    </div>
                </div>
            @endforeach
        </div>

        @push('js')
            <script src="{{ asset('js/progressbar.min.js') }}"></script>
            @include('dashboard.chart-progress', ['chart' => $chart])
        @endpush
    @endisset
</x-layouts.base>
