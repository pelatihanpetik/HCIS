<?php

use App\Http\Controllers\AlamatController;
use App\Http\Controllers\BerkasController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\DivisiController;
use App\Http\Controllers\FileController;
use App\Http\Controllers\JabatanController;
use App\Http\Controllers\JenisBerkasController;
use App\Http\Controllers\JenisJabatanController;
use App\Http\Controllers\KeluargaController;
use App\Http\Controllers\KontrakController;
use App\Http\Controllers\KpiController;
use App\Http\Controllers\KpiListController;
use App\Http\Controllers\KpiGroupController;
use App\Http\Controllers\KpiPegawaiController;
use App\Http\Controllers\KpiPengesahanController;
use App\Http\Controllers\KpiPengesahanSettingController;
use App\Http\Controllers\KpiRekomendasiController;
use App\Http\Controllers\KpiTtdController;
use App\Http\Controllers\PegawaiController;
use App\Http\Controllers\PelatihanController;
use App\Http\Controllers\PendidikanController;
use App\Http\Controllers\PosisiController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\RekeningController;
use App\Http\Controllers\TimesheetController;
use App\Http\Controllers\UserController;
use App\Http\Resources\WilayahResource;
use App\Models\Wilayah;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\URL;

if (config('app.env') === 'production') {
    #reverse proxy
    $proxy_url    = getenv('PROXY_URL');
    $proxy_schema = getenv('PROXY_SCHEMA');

    if (!empty($proxy_url)) {
        URL::forceRootUrl($proxy_url);
    }

    if (!empty($proxy_schema)) {
        URL::forceScheme($proxy_schema);
    }
}

Route::get('/', function () {
    return to_route('dashboard');
});


Route::middleware(['auth', 'verified'])->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');

    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');
    Route::get('/dashboard/{id}/detail', [DashboardController::class, 'show'])->name('dashboard.show');

    Route::resource('user', UserController::class);
    Route::put('user/{role}/role', [UserController::class, 'changeRole'])->name('user.role');
    Route::prefix('pegawai/{pegawai}')->middleware('can:view,pegawai')->group(function () {
        Route::get('/', [PegawaiController::class, 'show'])->name('pegawai.show');
        Route::get('edit', [PegawaiController::class, 'edit'])->name('pegawai.edit');
        Route::put('/', [PegawaiController::class, 'update'])->name('pegawai.update');
        Route::prefix('alamat')->controller(AlamatController::class)->group(function () {
            Route::get('/', 'index')->name('alamat.index');
            Route::get('create', 'create')->name('alamat.create');
            Route::post('/', 'store')->name('alamat.store');
            Route::get('{alamat}', 'edit')->name('alamat.edit');
            Route::put('{alamat}', 'update')->name('alamat.update');
            Route::delete('{id}', 'destroy')->name('alamat.destroy');
        });
        Route::prefix('berkas')->controller(BerkasController::class)->group(function () {
            Route::get('/', 'index')->name('berkas.index');
            Route::get('create', 'create')->name('berkas.create');
            Route::post('/', 'store')->name('berkas.store');
            Route::get('{berkas}/edit', 'edit')->name('berkas.edit');
            Route::put('{berkas}', 'update')->name('berkas.update');
            Route::delete('{berkas}', 'destroy')->name('berkas.destroy');
        });
        Route::prefix('kontrak')->controller(KontrakController::class)->group(function () {
            Route::get('/', 'index')->name('kontrak.index');
            Route::get('create', 'create')->name('kontrak.create');
            Route::post('/', 'store')->name('kontrak.store');
            Route::get('{kontrak}', 'edit')->name('kontrak.edit');
            Route::put('{kontrak}', 'update')->name('kontrak.update');
            Route::delete('{kontrak}', 'destroy')->name('kontrak.destroy');
        });
        Route::prefix('keluarga')->controller(KeluargaController::class)->group(function () {
            Route::get('/', 'index')->name('keluarga.index');
            Route::get('create', 'create')->name('keluarga.create');
            Route::post('/', 'store')->name('keluarga.store');
            Route::get('{keluarga}', 'edit')->name('keluarga.edit');
            Route::put('{keluarga}', 'update')->name('keluarga.update');
            Route::delete('{keluarga}', 'destroy')->name('keluarga.destroy');
        });
        Route::prefix('pendidikan')->controller(PendidikanController::class)->group(function () {
            Route::get('/', 'index')->name('pendidikan.index');
            Route::get('create', 'create')->name('pendidikan.create');
            Route::post('/', 'store')->name('pendidikan.store');
            Route::get('{pendidikan}', 'edit')->name('pendidikan.edit');
            Route::put('{pendidikan}', 'update')->name('pendidikan.update');
            Route::delete('{pendidikan}', 'destroy')->name('pendidikan.destroy');
        });
        Route::prefix('pelatihan')->controller(PelatihanController::class)->group(function () {
            Route::get('/', 'index')->name('pelatihan.index');
            Route::get('create', 'create')->name('pelatihan.create');
            Route::post('/', 'store')->name('pelatihan.store');
            Route::get('{pelatihan}', 'edit')->name('pelatihan.edit');
            Route::put('{pelatihan}', 'update')->name('pelatihan.update');
            Route::delete('{pelatihan}', 'destroy')->name('pelatihan.destroy');
        });
        Route::prefix('rekening')->controller(RekeningController::class)->group(function () {
            Route::post('/', 'store')->name('rekening.store');
            Route::put('{rekening}', 'update')->name('rekening.update');
            Route::delete('{rekening}', 'destroy')->name('rekening.destroy');
        });
    });

    Route::get('kpi-pegawai', [KpiPegawaiController::class, 'index'])->name('kpi-pegawai.index');
    Route::get('kpi-pegawai/{kpi}', [KpiPegawaiController::class, 'show'])->name('kpi-pegawai.show');
    Route::get('kpi-pegawai/{id}/isi', [KpiPegawaiController::class, 'create'])->name('kpi-pegawai.create');
    Route::post('kpi-pegawai/{id}/isi', [KpiPegawaiController::class, 'store'])->name('kpi-pegawai.store');

    Route::post('kpi/{kpi}/duplikat', [KpiController::class, 'duplicate'])->name('kpi.duplicate')
        ->whereNumber('kpi');
    Route::get('kpi/{id}/{pegawai}', [KpiController::class, 'detail'])->name('kpi.detail')
        ->whereNumber('id')
        ->whereNumber('pegawai');
    Route::post('kpi/{kpi}/pegawai', [KpiController::class, 'addPegawai'])
        ->whereNumber('kpi')
        ->name('kpi.add-pegawai');
    Route::delete('kpi/{kpi}/{pegawai}', [KpiController::class, 'removePegawai'])
        ->whereNumber('kpi')
        ->name('kpi.delete-pegawai');
    Route::resource('pengesahan', KpiPengesahanSettingController::class)
        ->except(['show']);
    Route::prefix('kpi/{kpi}/list')->controller(KpiListController::class)->group(function () {
        Route::get('/', 'index')->name('kpi.list.index');
        Route::get('create', 'create')->name('kpi.list.create');
        Route::post('/', 'store')->name('kpi.list.store');
        Route::get('{list}', 'edit')->name('kpi.list.edit');
        Route::put('{list}', 'update')->name('kpi.list.update');
        Route::delete('{id}', 'destroy')->name('kpi.list.destroy');
    });
    Route::prefix('kpi/{kpi}/pengesahan')->controller(KpiPengesahanController::class)->group(function () {
        Route::get('/', 'index')->name('kpi.pengesahan.index');
        Route::get('create', 'create')->name('kpi.pengesahan.create');
        Route::post('/', 'store')->name('kpi.pengesahan.store');
        Route::get('{pengesahan}', 'edit')->name('kpi.pengesahan.edit');
        Route::put('{pengesahan}', 'update')->name('kpi.pengesahan.update');
        Route::delete('{pengesahan}', 'destroy')->name('kpi.pengesahan.destroy');
    });
    Route::prefix('kpi/{id}/rekomendasi')->controller(KpiRekomendasiController::class)->group(function () {
        Route::get('{pegawai}', 'index')->name('kpi.rekomendasi.index');
        Route::put('{pegawai}', 'update')->name('kpi.rekomendasi.update');
    });
    Route::prefix('kpi/{id}/ttd')->controller(KpiTtdController::class)->group(function () {
        Route::get('{pegawai}', 'index')->name('kpi.ttd.index');
        Route::put('{ttd}', 'update')->name('kpi.ttd.update');
    });
    Route::resource('kpi', KpiController::class)
        ->whereNumber('kpi')
        ->except(['show']);
    Route::get('kpi/{kpi}', [KpiController::class, 'show'])->name('kpi.show')
        ->whereNumber('kpi');
    Route::get('file', [FileController::class, 'index'])->name('file.index');
    Route::middleware('role:admin')->group(function () {
        Route::get('pegawai', [PegawaiController::class, 'index'])->name('pegawai.index');
        Route::get('pegawai/create', [PegawaiController::class, 'create'])->name('pegawai.create');
        Route::post('pegawai', [PegawaiController::class, 'store'])->name('pegawai.store');
        Route::delete('pegawai/{pegawai}', [PegawaiController::class, 'destroy'])->name('pegawai.destroy');
        Route::prefix('pegawai/{pegawai}/posisi')->controller(PosisiController::class)->group(function () {
            Route::post('/', 'store')->name('posisi.store');
            Route::put('{posisi}', 'update')->name('posisi.update');
            Route::delete('{posisi}', 'destroy')->name('posisi.destroy');
        });
        Route::resource('kpi-group', KpiGroupController::class)
            ->except(['show'])
            ->parameter('kpi-group', 'group');
        Route::resource('jenis-file', JenisBerkasController::class)
            ->except(['show', 'edit', 'create'])
            ->parameters(['jenis-file' => 'jenis']);
        Route::resource('divisi', DivisiController::class)
            ->except(['show', 'edit', 'create']);
        Route::resource('jenis-jabatan', JenisJabatanController::class)
            ->except(['show', 'edit', 'create']);
        Route::resource('jabatan', JabatanController::class)->except(['show']);
    });

    Route::prefix('api')->group(function () {
        Route::get('kota', function (Request $request) {
            return WilayahResource::collection(
                Wilayah::where('provinsi', $request->provinsi)
                    ->selectRaw('DISTINCT(kota) as nama')
                    ->get()
            );
        })->name('api.kota');
        Route::get('kecamatan', function (Request $request) {
            return WilayahResource::collection(
                Wilayah::where('kota', $request->kota)
                    ->selectRaw('DISTINCT(kecamatan) as nama')
                    ->get()
            );
        })->name('api.kecamatan');
        Route::get('desa', function (Request $request) {
            return WilayahResource::collection(
                Wilayah::where('kecamatan', $request->kecamatan)
                    ->selectRaw('DISTINCT(desa) as nama')
                    ->get()
            );
            return WilayahResource::collection(Wilayah::where('kode', 'like', $kecamatan . '%')->where('jenis', 'desa')->select('nama')->get());
        })->name('api.desa');
    });

    Route::resource('timesheet', TimesheetController::class)->except(['show']);
    Route::prefix('timesheet')->group(function () {
        Route::get('report', [TimesheetController::class, 'report'])->name('timesheet.report');
        Route::get('report/{id}', [TimesheetController::class, 'reportDetail'])->name('timesheet.report.detail');
    });
});

require __DIR__ . '/auth.php';
